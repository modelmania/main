%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Project: Portfolio Risk Diversification
% Name: Changwei Xiong, 12/08/2009
% 
% The program is based on Meucci's paper and code.
%
% The code has been fully rewritten and implemented 
% to my favor. The first dataset ("Data.mat") is Meucci's data  
% used in his paper. The second dataset is selected from SP500  
% and its constituents stock monthly prices.
%
%(C) Copyright 2009, Changwei Xiong (axcw@hotmail.com)
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function PortfolioRiskDiversification
    clc
    close all
    clear all

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %
    % toggle the switches to choose the dataset and constraints,
    %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if 0 % select dataset 
        load returns.csv 
        load mktcaps.csv
        S = cov(returns);
        %mu = 0.5 * sqrt(diag(S));
        mu = mean(returns)';
        wb = 0.0*mean(mktcaps)'/sum(mean(mktcaps));
    else
        load Data % load the "Data.mat" file
        S = S;
        mu = Mu;
        wb = w_b;
    end

    % total number of assets
    N = length(mu);
    % equally weighted portfolio - benchmark
    w0 = ones(N,1)/N - wb;


    if 0 % select portfolio constraints
        % long-only constraint
        PCS.A = -eye(N); % A*w<=b ==> A*(w-wb)<=b-A*wb
        PCS.b = -PCS.A*wb;
        % budget constraint
        PCS.Aeq = ones(1,N); % Aeq*w = beq
        PCS.beq = 1 - PCS.Aeq*wb;
    else
        % long-short constraint
        PCS.A = [eye(N); -eye(N)]; % A*w<=b ==> A*(w-wb)<=b-A*wb
        PCS.b = [ones(N,1); 0.1*ones(N,1)] - PCS.A*wb;
        % budget constrain
        PCS.Aeq = ones(1,N); % Aeq*w = beq
        PCS.beq = 1 - PCS.Aeq*wb;
    end


    if 0 % select rebalancing constraints
        % budget constraint and trading suspension for first 3 stocks
        RCS = [ones(1,N)];%; eye(3,N)];
    else
        % no constraint
        RCS = [];
    end

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    [E, L, G] = PrinComp(S, RCS);
    MakePlots(E, L, w0);

    w = MeanDivEffFrontier(G, mu, w0, PCS);
    MakePlots(E, L, w(:,1));
    MakePlots(E, L, w(:,end));
end


function w = Ptfl_at_MaxRet(mu, PCS)
    % find w : max(mu'*w)|(A*x<=b & Aeq*x = beq) 
    w = linprog(-mu, PCS.A, PCS.b, PCS.Aeq, PCS.beq);
end


function w = Ptfl_at_MaxEnt(G, w0, PCS)
    % find min of negative entropy == find max of entropy
    w = fmincon(@NegativeEntropy, w0, ...
                PCS.A, PCS.b, PCS.Aeq, PCS.beq, ...
                [],[],[],...
                optimset('Algorithm','active-set', ...
                         'MaxFunEvals',10000, ...
                         'TolFun',1e-15, ...
                         'TolCon',1e-15, ...
                         'TolX'  ,1e-15));

    % embedded, compute negative entropy
    function negEnt = NegativeEntropy(w)
        v = G*w;
        varcon = v.*v;
        p = max(1e-10, varcon/sum(varcon));
        negEnt = p'*log(p);
    end
end


function w = MeanDivEffFrontier(G, mu, w0, PCS)
    RmaxRet = mu' * Ptfl_at_MaxRet(mu, PCS);
    RmaxEnt = mu' * Ptfl_at_MaxEnt(G, w0, PCS);

    % mean-diversification efficient frontier
    NP = 60;
    ret = linspace(RmaxEnt, RmaxRet, NP);
    %ret = ret(2:end-1);% remove the two extremas
    %ret = linspace(RmaxEnt, 0.9*(RmaxRet-RmaxEnt)+RmaxEnt, NP);
    NP = length(ret);

    Nent = zeros(NP,1);
    w = zeros(length(mu), NP);
    for i = 1:NP
        pcs = PCS;
        pcs.Aeq=[pcs.Aeq; mu'];
        pcs.beq=[pcs.beq; ret(i)];    
        w(:,i) = Ptfl_at_MaxEnt(G, w0, pcs);      
        Nent(i) = EntropyExponential(G, w(:,i));
    end

    fontsize = 12;
    linewidth = 2;
    markersize = 10;
    figure;
    hold on;
    plot(Nent, ret, 'o', ...
        'LineWidth',linewidth,...
        'MarkerEdgeColor','k',...
        'MarkerFaceColor','g',...
        'MarkerSize',markersize);
    set(gca,'FontSize',fontsize);
    ylabel('Expected Return','FontSize',fontsize);
    xlabel('N_{Ent}','FontSize',fontsize);
    title('Mean-Diversification Efficient Frontier','FontSize',fontsize);
    grid on;

    ret = mu'*w0;
    Nent = EntropyExponential(G, w0)
    plot(Nent, ret, 'o', ...
        'LineWidth',linewidth,...
        'MarkerEdgeColor','k',...
        'MarkerFaceColor','r',...
        'MarkerSize',markersize);
end

function Nent = EntropyExponential(G, w)
    s = G*w;
    p = max(1e-10, (s.*s)/(s'*s));
    Nent = exp(-p'*log(p));
end


function [E, L, G] = PrinComp(S, A)
    if nargin==1 || isempty(A)
        [E, L] = eig(S);
        E = fliplr(E);
        L = flipud(diag(L));
        G = diag(sqrt(L))/E;
    else
        [K, N] = size(A);
        E = [];
        B = A;
        for n = 1:N-K
            if n > 1
                B = [A; E'*S];
            end
            E = [E getFirstPrinComp(S, B)];
        end

        for n = N-K+1:N
            B = E'*S;
            E = [E getFirstPrinComp(S, B)];
        end
        % swap order
        E=[E(:,N-K+1:N) E(:,1:N-K)];
        L = diag(E'*S*E);
        [E, L] = SortPrinComp(E, L);
        G = diag(sqrt(L))/E;
        G = G(K+1:N, :);
    end
end


%compute the first principal component
function e = getFirstPrinComp(S, B)
    P = eye(size(S,1));
    if rank(B)>0
        P = P - B'/(B*B')*B;
    end
    [E, L] = eig(P*S*P');
    [m, i]=max(diag(L));
    e=E(:,i);
end


function [E_, L_] = SortPrinComp(E, L)
    % sort in descending order
    L_ = sort(L, 'descend');
    E_ = zeros(size(E,1));
    for i = 1:length(L)
        E_(:,i) = E(:, L==L_(i));
    end
end


function MakePlots(E, L, w)
    width = 0.6;
    fontsize = 11;

    %[E, L] = SortPrinComp(E, L);
    Xn = 1:size(E,1);

    %relative exposures to the principal portfolios
    figure;
    hold on;
    wt = E\w;
    subplot(4,1,1);
    bar(Xn, wt, width, 'k');
    set(gca,'FontSize',fontsize);
    xlim([min(Xn)-0.5, max(Xn)+0.5]);
    title('Relative Exposures to Principal Portfolios (weights)','fontsize',fontsize);
    grid on;

    %Volatilities of principal portfolios
    subplot(4,1,2);
    bar(Xn, sqrt(L), width, 'k');
    set(gca,'FontSize',fontsize);
    xlim([min(Xn)-0.5, max(Xn)+0.5]);
    title('Volatilities of Principal Portfolios (eigenvalues)','fontsize',fontsize);
    grid on;

    %variance concentration
    V = wt.^2.*L;

    var = sum(V);
    std = sqrt(var);
    %volatility/tracking error concentration curve
    subplot(4,1,3);
    bar(Xn, V/std, width, 'k');
    set(gca,'FontSize',fontsize);
    xlim([min(Xn)-0.5, max(Xn)+0.5]);
    title('Tracking Error Concentration','fontsize',fontsize);
    grid on;

    subplot(4,1,4);
    bar(Xn, V/var, width, 'k');
    set(gca,'FontSize',fontsize);
    xlim([min(Xn)-0.5, max(Xn)+0.5]);
    %xlabel('X axis = Principal Portfolio Number','fontsize',fontsize);
    title('Relative Diversification Distribution','fontsize',fontsize);
    grid on;
end