Since this is a small project, I put the class definition and declaration in the same source file for simplicity. This is definitely not a good practice for a big project, to be noted!


Source code:
FEM.h - Implementation of the Heston FEM algorithm
Utility.h - Utility classes/functions for numerical computing
VecMat.h - An efficient vector/matrix implementation extended from gsl_vector and gsl_matrix classes
xlExports.cpp - Excel interface for CPP functioheadersns


To compile the code, you'll need to have Visual Studio 2017 or later (https://visualstudio.microsoft.com/), community version is free and works perfectly. 
In addition, you will need to have the following libraries (the full pack (64-bit version only) can be downloaded from my website: http://www.cs.utah.edu/~cxiong/):
1. Header-only boost library (https://www.boost.org/)
2. Excel XLL Software Development Kit (https://docs.microsoft.com/en-us/office/client-developer/excel/welcome-to-the-excel-software-development-kit)
3. XLKit - Modern C++ Wrapper for the Excel XLL SDK (https://github.com/e4lam/xlkit)
4. GNU Scientific Library (https://github.com/ampl/gsl/)


Excel Spreadsheet:
HestonFEM.xls - Excel spreadsheets that demonstrate the implemented FEM pricer
HestonFEM.dll - Pre-complied 64-bit DLL file to be loaded in Excel (by "drag and drop"). You have to run it with a 64-bit version Excel. 