/*
*  Created on: March 10, 2019
*  Last modified on: August 8, 2020
*  Author: Changwei Xiong
*
*  Copyright (C) 2019 - 2020, Changwei Xiong,
*  axcw@hotmail.com, <https://modelmania.github.io/main/>
*
*  Licence: Revised BSD License <https://en.wikipedia.org/wiki/BSD_licenses>
*/

/*
https://en.wikipedia.org/wiki/Microsoft_Visual_C++
MSVC++ 9.0   _MSC_VER == 1500 (Visual Studio 2008 version 9.0)
MSVC++ 10.0  _MSC_VER == 1600 (Visual Studio 2010 version 10.0)
MSVC++ 11.0  _MSC_VER == 1700 (Visual Studio 2012 version 11.0)
MSVC++ 12.0  _MSC_VER == 1800 (Visual Studio 2013 version 12.0)
MSVC++ 14.0  _MSC_VER == 1900 (Visual Studio 2015 version 14.0)
MSVC++ 14.1  _MSC_VER == 1910 (Visual Studio 2017 version 15.0)
MSVC++ 14.12 _MSC_VER == 1912 (Visual Studio 2017 version 15.5)
MSVC++ 14.24 _MSC_VER == 1924 (Visual Studio 2019 Version 16.4)
*/

#pragma once

#include "VecMat.h"
#include <gsl/gsl_eigen.h>
#include <gsl/gsl_roots.h>
#include <gsl/gsl_spline.h>
#include <gsl/gsl_spline2d.h>
#include <gsl/gsl_multiroots.h>
#include <gsl/gsl_integration.h>
#include <gsl/gsl_cdf.h>
#include <gsl/gsl_randist.h>
#include <boost/math/tools/roots.hpp>
#include <map>
#include <set>
#include <valarray>

namespace Xiong {
    class ENUM {
      public:
        enum class INTERP { LINEAR, CSPLINE, AKIMA, STEFFEN };
        enum class EVALUATE { VALUE, DERIV, DERIV2 };
        enum class CONSTRAINT { NONE, LBOUND, UBOUND, RANGE };
        enum class DELTA { SPOTPIPS, FWDPIPS, SPOTPCT, FWDPCT };
        enum class ATM { ATMF, ATMDNS };
        enum class BOUNDARY { DIRICHLET, NEUMANN, CONVEXITY, ZEROGAMMA };
    };


    // ------------- x0 ----------- x1 ------------------- x2 ---------------
    //      y0       y0      y1     y1          y2         y2        y2
    //  y0:(-inf,x0]     y1:(x0,x1]        y2:(x1,x2]          y2:(x2,+inf)
    //
    // std::lower_bound: Returns an iterator pointing to the first element in the range [FIRST, LAST) not less than
    // (i.e. greater or equal to) the value, or LAST if no such element is found
    class PiecewiseFlat {
        SharedVector xv, yv;
      public:
        PiecewiseFlat() {}
        PiecewiseFlat(SharedVector const& xv_, SharedVector const& yv_) : xv(xv_), yv(yv_) { }

        double eval(double x) const { return yv[PiecewiseFlat::index(x, xv)]; }
        SharedVector eval(SharedVector const& x) const { return x.map([&](double v) {return eval(v); }); }

        // if v < x[0] return 0; if v > x[n] return n; if x[i-1] < v <= x[i] return i
        static size_t index(double x, SharedVector const& xv) { return std::lower_bound(xv.begin(), xv.end() - 1, x) - xv.begin(); }
    };


    class Interp1D {
        bool m_flat_extrap;
        gsl_spline* p_interp;
        gsl_interp_accel* p_accel;
        Interp1D(Interp1D const&) = delete;  // prevent copying
        Interp1D& operator=(Interp1D const&) = delete;
      public:
        Interp1D() { p_interp = nullptr; p_accel = nullptr; }
        ~Interp1D() { gsl_spline_free(p_interp); gsl_interp_accel_free(p_accel); }
        Interp1D(SharedVector const& xv, SharedVector const& yv, bool flat_extrap = false, ENUM::INTERP kind = ENUM::INTERP::LINEAR) {
            assert(xv.size() == yv.size() && gsl_vector_ispos(&diff(xv).gsl()));
            m_flat_extrap = flat_extrap;

            gsl_interp_type const* gsl_interp;
            if(kind == ENUM::INTERP::LINEAR)       gsl_interp = gsl_interp_linear;
            else if(kind == ENUM::INTERP::CSPLINE) gsl_interp = gsl_interp_cspline;
            else if(kind == ENUM::INTERP::AKIMA)   gsl_interp = gsl_interp_akima;
            else if(kind == ENUM::INTERP::STEFFEN) gsl_interp = gsl_interp_steffen;
            else THROW("invalid 1D interpolation type");

            p_interp = gsl_spline_alloc(gsl_interp, xv.size());
            p_accel = gsl_interp_accel_alloc();
            gsl_spline_init(p_interp, xv.gsl().data, yv.gsl().data, xv.size());
        }

        double eval(double x, ENUM::EVALUATE kind = ENUM::EVALUATE::VALUE) const {
            if(m_flat_extrap) {
                x = std::max(x, p_interp->interp->xmin);
                x = std::min(x, p_interp->interp->xmax);
            }
            switch(kind) {
                case ENUM::EVALUATE::VALUE:
                    return gsl_spline_eval(p_interp, x, p_accel);
                case ENUM::EVALUATE::DERIV:
                    return gsl_spline_eval_deriv(p_interp, x, p_accel);
                case ENUM::EVALUATE::DERIV2:
                    return gsl_spline_eval_deriv2(p_interp, x, p_accel);
                default:
                    THROW("invalid interpolation value type");
            }
        }
        SharedVector eval(const SharedVector& x, ENUM::EVALUATE kind = ENUM::EVALUATE::VALUE) const {
            return x.map([&](double v) {return eval(v, kind); });
        }
    };


    class Interp2D {
        bool m_flat_extrap;
        gsl_spline2d* p_interp2d;
        gsl_interp_accel* p_row_accel;
        gsl_interp_accel* p_col_accel;
        Interp2D(Interp2D const&) = delete;   // prevent copying
        Interp2D& operator=(Interp2D const&) = delete;
      public:
        Interp2D() {
            p_interp2d = nullptr;
            p_row_accel = nullptr;
            p_col_accel = nullptr;
        }
        ~Interp2D() {
            gsl_spline2d_free(p_interp2d);
            gsl_interp_accel_free(p_row_accel);
            gsl_interp_accel_free(p_col_accel);
        }
        Interp2D(SharedVector const& rows, SharedVector const& cols, SharedMatrix const& zm,
                 bool flat_extrap = false, ENUM::INTERP kind = ENUM::INTERP::LINEAR) {
            size_t num_rows = rows.size();
            size_t num_cols = cols.size();
            assert(num_rows == zm.size1() && num_cols == zm.size2());
            SharedVector tmp(num_rows * num_cols);
            m_flat_extrap = flat_extrap;
            if(kind == ENUM::INTERP::LINEAR)
                p_interp2d = gsl_spline2d_alloc(gsl_interp2d_bilinear, num_rows, num_cols);
            else if(kind == ENUM::INTERP::CSPLINE)
                p_interp2d = gsl_spline2d_alloc(gsl_interp2d_bicubic, num_rows, num_cols);
            else
                THROW("invalid 2D interpolation type");
            p_row_accel = gsl_interp_accel_alloc();
            p_col_accel = gsl_interp_accel_alloc();
            for(size_t i = 0; i < num_rows; i++)
                for(size_t j = 0; j < num_cols; j++)
                    gsl_spline2d_set(p_interp2d, tmp.gsl().data, i, j, zm(i, j));
            gsl_spline2d_init(p_interp2d, rows.gsl().data, cols.gsl().data, tmp.gsl().data, num_rows, num_cols);
        }

        double eval(double x, double y) const {
            if(m_flat_extrap) {
                x = std::max(x, p_interp2d->interp_object.xmin);
                x = std::min(x, p_interp2d->interp_object.xmax);
                y = std::max(y, p_interp2d->interp_object.ymin);
                y = std::min(y, p_interp2d->interp_object.ymax);
            }
            return gsl_spline2d_eval(p_interp2d, x, y, p_row_accel, p_col_accel);
        }
        SharedVector eval(double x, SharedVector const& y) const { return y.map([&](double v) {return eval(x, v); }); }
        SharedVector eval(SharedVector const& x, double y) const { return x.map([&](double v) {return eval(v, y); }); }
        SharedMatrix eval(SharedVector const& x, SharedVector const& y) const {
            SharedMatrix r(x.size(), y.size());
            for(auto i : irange(x.size())) for(auto j : irange(y.size()))
                    r(i, j) = eval(x[i], y[j]);
            return r;
        }
    };


    class UnivariateFunction {
      public:
        // f(x) is monotonic in the half of the real axis containing guess.
        // The value of the inital guess must have the same sign as the root.
        // the function will never cross the origin when searching for the root.
        template<typename FN>
        static double boost_uni_root_one_sided(FN& fn, double guess, double tol = 1e-12, bool increasing = true) {
            boost::math::tools::eps_tolerance<double> tolerance(std::fabs(std::log(tol) / std::log(2.)));
            boost::uintmax_t max_iter = 100;
            std::pair<double, double> result = boost::math::tools::bracket_and_solve_root(fn, guess, 2., increasing, tolerance, max_iter);
            return (result.first + result.second) / 2;
        }

        template<typename FN>
        static std::pair<double, double> boost_uni_minima(FN& fn, double lo, double hi) { /// Bounded
            return boost::math::tools::brent_find_minima(fn, lo, hi, std::numeric_limits<double>::digits - 3);
        }

        template<typename FN>
        static double gsl_uni_root(FN& fn, double lo, double hi, const double tol = 1e-12) { /// Bounded
            gsl_root_fsolver* p_solver = gsl_root_fsolver_alloc(gsl_root_fsolver_brent);
            gsl_root_fsolver_set(p_solver, &gsl_uni_func<FN>(fn), lo, hi);
            int status = GSL_CONTINUE;
            for(int i = 0; status == GSL_CONTINUE && i < 100; i++) {    // max iter 100
                if(gsl_root_fsolver_iterate(p_solver) != GSL_SUCCESS)
                    break;
                lo = gsl_root_fsolver_x_lower(p_solver);
                hi = gsl_root_fsolver_x_upper(p_solver);
                status = gsl_root_test_interval(lo, hi, tol, tol);// abs. tol. and rel. tol.
            }
            gsl_root_fsolver_free(p_solver);
            if(status != GSL_SUCCESS)
                THROW(std::string(gsl_strerror(status)));
            return (lo + hi) / 2;
        }

        // integrate fn from a to b using n sampling points by gauss-legendre quadrature
        // weight_function = 1
        template<typename FN>
        static double gsl_gauss_legendre(FN& fn, int n, double a, double b) {
            gsl_integration_fixed_workspace* w = gsl_integration_fixed_alloc(gsl_integration_fixed_legendre, n, a, b, 0, 0);
            double result;
            gsl_integration_fixed(&gsl_uni_func<FN>(fn), &result, w);
            gsl_integration_fixed_free(w);
            return result;
        }

        // integrate fn from a to +inf using n sampling points by gauss-laguerre quadrature
        // weight_function = (x-a)^alpha * exp(-b*(x-a)) in (a, +inf) for gauss-laguerre, with b = 1 and alpha = 0
        template<typename FN>
        static double gsl_gauss_laguerre(FN& fn, int n = 80, double a = 0) {
            auto fn_ = [&](double x) {return fn(x) * exp(x - a); };
            gsl_integration_fixed_workspace* w = gsl_integration_fixed_alloc(gsl_integration_fixed_laguerre, n, a, 1, 0, 0);
            double result;
            gsl_integration_fixed(&gsl_uni_func<decltype(fn_)>(fn_), &result, w);
            gsl_integration_fixed_free(w);
            return result;
        }

      private:
        template<typename FN>
        class gsl_uni_func : public gsl_function {
            using self_t = gsl_uni_func;
            FN const& func;
            static double call(double x, void* params) { return static_cast<self_t*>(params)->func(x); }
          public:
            self_t(FN const& func_) : func(func_) { function = &self_t::call; params = this; }
        };
    };


    class MultivariateFunction {
      public:
        // gsl_multiroot_fsolver_hybrids: https://www.gnu.org/software/gsl/doc/html/multiroots.html
        // This is a modified version of Powell's Hybrid method as implemented in the HYBRJ algorithm in MINPACK.
        // The Hybrid algorithm retains the fast convergence of Newton�s method but will also reduce the residual when Newton�s method is unreliable.
        // This version of the Hybrid algorithm replaces calls to the Jacobian function by its finite difference approximation.
        template<typename FN>
        static SharedVector gsl_multi_root(FN& fn, SharedVector x, double const tol = 1e-10,
                                           ENUM::CONSTRAINT constr = ENUM::CONSTRAINT::NONE, SharedVector a = SharedVector(), SharedVector b = SharedVector()) {
            size_t n = x.size();
            SimulatedConstraint transform(constr, a, b);
            gsl_multiroot_fsolver* p_solver = gsl_multiroot_fsolver_alloc(gsl_multiroot_fsolver_hybrids, n);
            gsl_multiroot_fsolver_set(p_solver, &gsl_multifunc_root<FN>(fn, n, transform), &transform.forward(x).gsl());
            int status = GSL_CONTINUE;
            for(int i = 0; status == GSL_CONTINUE && i < 200; i++) {                // max iter 100
                if(gsl_multiroot_fsolver_iterate(p_solver) != GSL_SUCCESS)
                    break;
                status = gsl_multiroot_test_residual(p_solver->f, tol);
            }
            if(status != GSL_SUCCESS)
                THROW(std::string(gsl_strerror(status)));
            SharedVector res = transform.backward(SharedVector(*p_solver->x));
            gsl_multiroot_fsolver_free(p_solver);
            return res;
        }

        // Simplex algorithm of Nelder and Mead: https://www.gnu.org/software/gsl/doc/html/multimin.html
        // gsl_multimin_fminimizer_nmsimplex2rand is a new O(N) operations implementation using a randomly-oriented set of basis vectors
        // The minimizer-specific characteristic size of simplex is calculated as the RMS distance of each vertex from the center
        template<typename FN>
        static SharedVector gsl_multi_minima_simplex(FN& fn, SharedVector x, double const tol = 1e-5,
                ENUM::CONSTRAINT constr = ENUM::CONSTRAINT::NONE, SharedVector a = SharedVector(), SharedVector b = SharedVector()) {
            size_t n = x.size();
            SimulatedConstraint transform(constr, a, b);
            gsl_multimin_fminimizer* p_solver = gsl_multimin_fminimizer_alloc(gsl_multimin_fminimizer_nmsimplex2rand, n);
            gsl_multimin_fminimizer_set(p_solver, &gsl_multifunc_min<FN>(fn, n, transform), &transform.forward(x).gsl(), &SharedVector(n, 0.05).gsl());
            int status = GSL_CONTINUE;
            for(int i = 0; status == GSL_CONTINUE && i < 200; i++) {
                if(gsl_multimin_fminimizer_iterate(p_solver) != GSL_SUCCESS)
                    break;
                status = gsl_multimin_test_size(p_solver->size, tol);
            }
            if(status != GSL_SUCCESS)
                THROW(std::string(gsl_strerror(status)));
            SharedVector res = transform.backward(SharedVector(*p_solver->x));
            gsl_multimin_fminimizer_free(p_solver);
            return res;
        }

        // https://www.gnu.org/software/gsl/doc/html/multimin.html
        // gsl_multimin_fdfminimizer_vector_bfgs2 with finite difference derivative
        template<typename FN>
        static SharedVector gsl_multi_minima_bfgs2(FN& fn, SharedVector x, const double tol = 1e-3,
                ENUM::CONSTRAINT constr = ENUM::CONSTRAINT::NONE, SharedVector a = SharedVector(), SharedVector b = SharedVector()) {
            size_t n = x.size();
            SimulatedConstraint transform(constr, a, b);
            gsl_multimin_fdfminimizer* p_solver = gsl_multimin_fdfminimizer_alloc(gsl_multimin_fdfminimizer_vector_bfgs2, n);
            gsl_multimin_fdfminimizer_set(p_solver, &gsl_multifunc_min_fdf<FN>(fn, n, transform), &transform.forward(x).gsl(), 0.01, 0.1);
            int status = GSL_CONTINUE;
            for(int i = 0; status == GSL_CONTINUE && i < 200; i++) {
                if(gsl_multimin_fdfminimizer_iterate(p_solver) != GSL_SUCCESS)
                    break;
                status = gsl_multimin_test_gradient(p_solver->gradient, tol);
            }
            if(status != GSL_SUCCESS)
                THROW(std::string(gsl_strerror(status)));
            SharedVector res = transform.backward(SharedVector(*p_solver->x));
            gsl_multimin_fdfminimizer_free(p_solver);
            return res;
        }

      private:
        class SimulatedConstraint {
            ENUM::CONSTRAINT constr;
            SharedVector lbound;
            SharedVector ubound;
            SharedVector length; // only used for ENUM::CONSTRAINT::RANGE

          public:
            SimulatedConstraint(ENUM::CONSTRAINT constr_ = ENUM::CONSTRAINT::NONE, SharedVector& lbound_ = SharedVector(), SharedVector& ubound_ = SharedVector()) {
                constr = constr_;
                lbound = lbound_;
                ubound = ubound_;
                if(constr_ == ENUM::CONSTRAINT::RANGE) length = ubound_ - lbound_;
            }

            SharedVector forward(SharedVector const& x) const {  // simulate constraints
                switch(constr) {
                    case ENUM::CONSTRAINT::NONE:   return x;
                    case ENUM::CONSTRAINT::LBOUND: return sqrt(x - lbound);
                    case ENUM::CONSTRAINT::UBOUND: return sqrt(ubound - x);
                    case ENUM::CONSTRAINT::RANGE:  return atanh((x - lbound) / length * 2 - 1);
                }
            }

            SharedVector backward(SharedVector const& y) const {  // simulate constraints
                switch(constr) {
                    case ENUM::CONSTRAINT::NONE:   return y;
                    case ENUM::CONSTRAINT::LBOUND: return lbound + y * y;
                    case ENUM::CONSTRAINT::UBOUND: return ubound - y * y;
                    case ENUM::CONSTRAINT::RANGE:  return lbound + length * (tanh(y) + 1) / 2;
                }
            }
        };

        template<typename FN>
        class gsl_multifunc_root : public gsl_multiroot_function {
            using self_t = gsl_multifunc_root;
            FN const& fn;
            SimulatedConstraint const& transform;
            static int f_(gsl_vector const* x, void* params, gsl_vector* fval) {
                SharedVector res = static_cast<self_t*>(params)->fn(static_cast<self_t*>(params)->transform.backward(SharedVector(*x)));
                gsl_vector_memcpy(fval, &res.gsl());
                return GSL_SUCCESS;
            }
          public:
            self_t(FN const& function, size_t num_params, SimulatedConstraint const& transform_)
                : fn(function), transform(transform_) {
                f = &self_t::f_;
                n = num_params;
                params = this;
            }
        };

        template<typename FN>
        class gsl_multifunc_min : public gsl_multimin_function {
            using self_t = gsl_multifunc_min;
            FN const& fn;
            SimulatedConstraint const& transform;
            static double f_(gsl_vector const* x, void* params) {
                self_t const* p = static_cast<self_t*>(params);
                return p->fn(p->transform.backward(SharedVector(*x)));
            }
          public:
            self_t(FN const& function, size_t num_params, SimulatedConstraint const& transform_)
                : fn(function), transform(transform_) {
                f = &self_t::f_;
                n = num_params;
                params = this;
            }
        };

        template<typename FN>
        class gsl_multifunc_min_fdf : public gsl_multimin_function_fdf {
            using self_t = gsl_multifunc_min_fdf;
            FN const& fn;
            SimulatedConstraint const& transform;
            double func(SharedVector const& x) {
                return fn(transform.backward(x));
            }
            static double f_(gsl_vector const* x, void* params) {
                return static_cast<self_t*>(params)->func(SharedVector(*x));
            }
            static void df_(gsl_vector const* x_, void* params, gsl_vector* df) {
                SharedVector x = SharedVector(*x_);
                double f0 = static_cast<self_t*>(params)->func(x);
                for(int i = 0; i < x.size(); i++) {
                    double dx = fabs(x[i]) * GSL_SQRT_DBL_EPSILON;
                    if(dx == 0) dx = GSL_SQRT_DBL_EPSILON;
                    x[i] += dx;
                    double f1 = static_cast<self_t*>(params)->func(x);
                    x[i] -= dx;
                    gsl_vector_set(df, i, (f1 - f0) / dx);
                }
            }
            static void fdf_(gsl_vector const* x, void* params, double* f, gsl_vector* df) {
                *f = f_(x, params);
                df_(x, params, df);
            }

          public:
            self_t(FN const& function, size_t num_params, SimulatedConstraint const& transform_)
                : fn(function), transform(transform_) {
                f = &self_t::f_;
                df = &self_t::df_;
                fdf = &self_t::fdf_;
                n = num_params;
                params = this;
            }
        };
    };


    class TridiagonalMatrix : public SharedVector {
        using self_t = TridiagonalMatrix;
        using base_t = SharedVector;
        template <typename T> using vec_t = VectorExpression<T>;

        self_t(base_t const& v) { base_t::operator=(v); } // shared_ptr shallow copy
      public:
        self_t(size_t size = 0) : base_t(size * 3, 0.0) {} // must be initialized to zeros
        self_t clone() const { return base_t::clone(); }
        size_t size() const { return base_t::size() / 3; }

        self_t operator+(self_t const& m) { return base_t::operator+(m); }
        self_t operator-(self_t const& m) { return base_t::operator-(m); }

        // Add to main diagonal, in-place addition
        template <typename T> // T := scalar or vector
        self_t& add_diag(T const& v) { range(size(), size() * 2) += v; return *this; }

        // handling the term d(x*p)/ds as in forward equation, x is a known vector
        // this function converts differencing D*(x*p) to equivalent G = D*x, e.g. D*Diag(x)
        // since differencing also applies to x, we assume x is linearly extrapolated to ghost points
        template <typename T> // T := vector
        self_t right_scale(VectorExpression<T> const& x) {
            size_t n = size();
            assert(n == x.size());
            self_t r = clone();
            r[0] *= 2 * x[0] - x[1]; //for left ghost point: x(-1) = x[0] - (x[1] - x[0]) = 2*x[0] - x[1]
            r.range(1, n) *= x.range(0, -1);
            r.range(n, n * 2) *= x;
            r.range(n * 2, -1) *= x.range(1);
            r(-1) *= 2 * x(-1) - x(-2); // for right ghost point: x[m+1] = x[m] + (x[m] - x[m-1]) = 2*x[m] - x[m-1]
            return r;
        }

        // handling the term x*dv/ds as in backward equation, x is a known vector
        // this function converts differencing x*D*v to equivalent G = x*D, e.g. Diag(x)*D
        // no need for ghost points as differencing does not apply to x
        template <typename T> // T := scalar or vector
        self_t left_scale(T const& x) {
            self_t r = clone();
            size_t n = size();
            r.range(0, n) *= x;
            r.range(n, n * 2) *= x;
            r.range(n * 2) *= x;
            return r;
        }

        void set_row(int row, double ldiag, double diag, double udiag) {
            // row = -1 means the last row
            int n = size();
            if(row < 0)  row += n;
            (*this)[row] = ldiag;
            (*this)[row + n] = diag;
            (*this)[row + n * 2] = udiag;
        }

        //template <ENUM::STEP> friend class BoundaryCondition;
        friend class BoundaryCondition;
    };

    class BoundaryCondition {
        using bc_t = ENUM::BOUNDARY;
        using tdm_t = TridiagonalMatrix;
        template <typename T> using vec_t = VectorExpression<T>;

        bc_t lower_bc, upper_bc;
        double h0, hm;
        size_t n, m;

        double const* a;
        double const* b;
        double const* c;
        double b0, c0, am, bm, w0, wm;
        std::valarray<double> t;

        void initiate(tdm_t const& tdm) {
            assert(tdm.size() == n);
            a = tdm.gsl().data;
            b = a + n;
            c = b + n;

            switch(lower_bc) {
                case bc_t::DIRICHLET:
                    b0 = 1; c0 = 0; w0 = 0; break;
                case bc_t::NEUMANN:
                    b0 = b[0]; c0 = a[0] + c[0]; w0 = -2 * a[0] * h0; break;
                case bc_t::CONVEXITY:
                    b0 = 2 * a[0] + b[0]; c0 = c[0] - a[0]; w0 = a[0] * h0 * h0; break;
                case bc_t::ZEROGAMMA:
                    b0 = b[0] + 4 / (h0 + 2) * a[0]; c0 = c[0] + (h0 - 2) / (h0 + 2) * a[0]; w0 = 0; break;
                default: THROW("invalid lower boundary condition");
            }
            switch(upper_bc) {
                case bc_t::DIRICHLET:
                    am = 0; bm = 1; wm = 0; break;
                case bc_t::NEUMANN:
                    am = a[m] + c[m]; bm = b[m]; wm = 2 * c[m] * hm; break;
                case bc_t::CONVEXITY:
                    am = a[m] - c[m]; bm = b[m] + 2 * c[m]; wm = c[m] * hm * hm; break;
                case bc_t::ZEROGAMMA:
                    am = a[m] + (hm + 2) / (hm - 2) * c[m]; bm = b[m] - 4 / (hm - 2) * c[m]; wm = 0; break;
                default: THROW("invalid upper boundary condition");
            }
        }

      public:
        BoundaryCondition() {}
        BoundaryCondition(SharedVector const& grid, bc_t lower_bc_, bc_t upper_bc_)
            : n(grid.size()), m(n - 1), t(n) {
            lower_bc = lower_bc_;
            upper_bc = upper_bc_;
            h0 = grid[1] - grid[0];
            hm = grid(-1) - grid(-2);
        }

        template<typename T> SharedVector map(tdm_t const& tdm, vec_t<T> const& v, double f0 = 0, double fm = 0) { SharedVector r(v.size()); apply(tdm, v, r, f0, fm); return r; }
        template<typename A> void apply(tdm_t const& tdm, vec_t<A>& v, double f0 = 0, double fm = 0) { apply(tdm, v, v, f0, fm); }
        template<typename A, typename B> void apply(tdm_t const& tdm, vec_t<A> const& x_, vec_t<B>& y_, double f0 = 0, double fm = 0) { // A, B := Vector; matrix vector multiplication
            initiate(tdm);
            auto x = x_.begin();
            auto y = y_.begin();
            double z0 = lower_bc == bc_t::DIRICHLET ? f0 - x[0] : w0 * f0;
            double zm = upper_bc == bc_t::DIRICHLET ? fm - x[m] : wm * fm;

            double p = x[0], q;
            y[0] = z0 + b0 * p + c0 * x[1]; // R * U + S
            for(size_t i = 1; i < m; i++) {
                q = x[i];// p, q are for in-place multiplication, e.g. &x == &y
                y[i] = a[i] * p + b[i] * x[i] + c[i] * x[i + 1];
                p = q;
            }
            y[m] = am * p + bm * x[m] + zm;
            //y[0] = b[0] * x[0] + c[0] * x[1];
            //for(size_t i = 1;; i < n - 1; i++)
            //    y[i] = a[i] * x[i - 1] + b[i] * x[i] + c[i] * x[i + 1];
            //y[m] = a[m] * x[m - 1] + b[m] * x[m];
        }

        template<typename A> void solve(tdm_t const& tdm, vec_t<A>& v, double f0 = 0, double fm = 0) { solve(tdm, v, v, f0, fm); }
        template<typename A, typename B> void solve(tdm_t const& tdm, vec_t<A> const& x_, vec_t<B>& y_, double f0 = 0, double fm = 0) { // A, B := Vector; inversion of linear system
            initiate(tdm);
            auto x = x_.begin();
            auto y = y_.begin();
            double z0 = lower_bc == bc_t::DIRICHLET ? x[0] - f0 : w0 * f0;
            double zm = upper_bc == bc_t::DIRICHLET ? x[m] - fm : wm * fm;

            t[0] = c0 / b0;
            y[0] = (x[0] - z0) / b0;
            for(size_t i = 1; i < m; i++) {
                double tmp = b[i] - a[i] * t[i - 1];
                t[i] = c[i] / tmp;
                y[i] = (x[i] - a[i] * y[i - 1]) / tmp;
            }
            y[m] = (x[m] - zm - am * y[m - 1]) / (bm - am * t[m - 1]);
            for(int i = m - 1; i >= 0; i--)
                y[i] -= t[i] * y[i + 1];
            //t[0] = c[0] / b[0];
            //y[0] = x[0] / b[0];
            //for(size_t i = 1; i < n; i++) {
            //    double tmp = b[i] - a[i] * t[i - 1];
            //    t[i] = c[i] / tmp;
            //    y[i] = (x[i] - a[i] * y[i - 1]) / tmp;
            //}
            //for(int i = n - 2; i >= 0; i--)
            //    y[i] -= t[i] * y[i + 1];
        }
    };


    class Grid {
      public:
        // size n means there are in total n segments or (n+1) points.
        static SharedVector uniform(double a, double b, size_t size) {
            SharedVector grid(size + 1);
            for(int i = 0; i <= size; i++)
                grid[i] = double(size - i) / size * a + double(i) / size * b;  // "a + i * (b - a) / size" may introduce rounding errors at two ends
            return grid;
        }

        // 1. Grid around keys will have denser points. The keys may not fall right onto the grid.
        // 2. Grid can be aligned to anchors, i.e. anchors fall exactly on grid points.
        // 3. Strike is in the middle (roughly) of two grid points to enhance price accuracy.
        // 4. The larger the beta, the more uniform the grid.
        // 5. Size n means there are in total n segments or (n+1) points.
        // Example usage:
        //   - nonuniform(0, 5, 100, {0,5})     : Denser grid around the two ends: ;
        //   - nonuniform(0, 5, 100, {3,2})     : Denser grid around {2,3}, order in keys does not matter
        //   - nonuniform(0, 5, 100, {4,0,2,2}) : Denser grid around {0,2,4} and even denser (but not doubled) around {2}
        static SharedVector nonuniform(double xmin, double xmax, size_t size, double beta = 0.1,
                                       SharedVector keys = {}, SharedVector anchors = {}, SharedVector means = {}) {
            SharedVector grid;
            if(keys.size() == 0)
                grid = uniform(xmin, xmax, size);
            else {
                double const alpha = beta * (xmax - xmin);
                double const dx = 1.0 / size;

                auto jacobian = [&](double y) -> double {
                    double sum = 0;
                    for(int i = 0; i < keys.size(); i++)
                        sum += 1 / (alpha * alpha + square(y - keys[i]));
                    return 1 / sqrt(sum);
                };

                grid = SharedVector(size + 1);
                grid[0] = xmin;
                auto residue = [&](double lambda)-> double {
                    for(int i = 1; i < grid.size(); i++) {      // Runge Kutta integration
                        double y = grid[i - 1];
                        double a = jacobian(y);
                        double b = jacobian(y + a * dx / 2);
                        double c = jacobian(y + b * dx / 2);
                        double d = jacobian(y + c * dx);
                        grid[i] = y + lambda * (a + (b + c) * 2 + d) * dx / 6;
                    }
                    return grid(-1) - xmax;
                };
                double lambda = UnivariateFunction::boost_uni_root_one_sided(residue, 1.0);
                residue(lambda);
                grid(-1) = xmax;
            }
            return ensure_points_on_grid(grid, anchors, means);
        }

        static SharedVector nonuniform_simple(double xmin, double xmax, size_t size, double beta = 0.1,
                                              double key = DBL_MAX, SharedVector anchors = {}, SharedVector means = {}) {
            SharedVector grid;
            if(key == DBL_MAX)
                grid = uniform(xmin, xmax, size);
            else {
                double const alpha = beta * (xmax - xmin);
                grid = SharedVector(size + 1);

                double const asinh_xmax = std::asinh((xmax - key) / alpha);
                double const asinh_xmin = std::asinh((xmin - key) / alpha);
                for(size_t i = 0; i < size + 1; ++i) {
                    double v = double(i) / size;
                    grid[i] = key + alpha * std::sinh(v * asinh_xmax + (1 - v) * asinh_xmin);
                }
            }
            return ensure_points_on_grid(grid, anchors, means);
        }

        static SharedVector ensure_points_on_grid(SharedVector const& grid, SharedVector const& anchors, SharedVector const& means) {
            std::set<double> anchor_set;  //sorted set, remove duplicates
            for(auto& anchor : anchors)    //anchors and mean must be within the bounds of grid
                if(anchor > grid[0] && anchor < grid(-1))
                    anchor_set.insert(anchor);

            for(auto& mean : means) {
                if(mean > grid[0] && mean < grid(-1)) {  // ensure mean is in the middle (roughly) of two grid points to enhance numerical accuracy
                    anchor_set.erase(mean);
                    size_t i = PiecewiseFlat::index(mean, grid);
                    anchor_set.insert(mean + (grid[i] - grid[i - 1]) / 2);
                }
            }

            if(std::empty(anchor_set))
                return grid;

            anchor_set.insert(grid(-1)); // add tailing entry of grid
            size_t p = 0;
            double prev_anchor = grid[0];
            SharedVector newgrid(grid.size());
            for(auto it = anchor_set.begin(); it != anchor_set.end(); ++it) {
                double anchor = *it;
                size_t q = PiecewiseFlat::index(anchor, grid);
                if(anchor - grid[q - 1] < grid[q] - anchor) q--;
                if(p == q) THROW("anchor points are too close");
                double grid_stride = grid[q] - grid[p];
                double anchor_stride = anchor - prev_anchor;
                for(size_t i = p; i <= q; ++i)
                    newgrid[i] = (grid[i] - grid[p]) / grid_stride * anchor_stride + prev_anchor;
                newgrid[q] = anchor;
                prev_anchor = anchor;
                p = q;
            }
            return newgrid;
        }

        // compute grid spacing for numerical integration
        static SharedVector compute_grid_spacing(SharedVector const& grid) {
            SharedVector spacing(grid.size());
            spacing[0] = (grid[1] - grid[0]) / 2;
            for(int i = 1; i < grid.size() - 1; i++)
                spacing[i] = (grid[i + 1] - grid[i - 1]) / 2;
            spacing(-1) = (grid(-1) - grid(-2)) / 2;
            return spacing;
        }

        static TridiagonalMatrix get_fdm_matrix(SharedVector const& x, size_t order) { // raw differencing matrix without boundary condition
            auto h = diff(x); // x[i+1] > x[i]
            size_t n = x.size();
            TridiagonalMatrix tdm(n);
            for(int i = 0; i < n; i++) {
                double p = i == 0 ? h[0] : h[i - 1];
                double q = i == n - 1 ? h(-1) : h[i];
                if(order == 1)
                    tdm.set_row(i, -q / p / (p + q), (q - p) / (p * q), p / q / (p + q)); //diagonal, = (q / p - p / q) / (p + q)
                else if(order == 2)
                    tdm.set_row(i, 2 / p / (p + q), -2 / (p * q), 2 / q / (p + q));  //diagonal, = -2 * (1 / p + 1 / q) / (p + q)
                else
                    THROW("order of derivative must be 1 or 2");
            }
            return tdm;
        }
    };


    class Gaussian2D {
        double x0, y0, sx, sy, rho;
      public:
        Gaussian2D(double mu_x, double mu_y, double sigma_x, double sigma_y, double rho_)
            : x0(mu_x), y0(mu_y), sx(sigma_x), sy(sigma_y), rho(rho_) {}

        double pdf(double x, double y) {
            return gsl_ran_bivariate_gaussian_pdf(x - x0, y - y0, sx, sy, rho);
        }
    };


    class Gaussian3D {
        SharedMatrix L;
        SharedVector mean;
        SharedVector work;
      public:
        Gaussian3D(double x0, double y0, double z0,
                   double s0, double s1, double s2,
                   double r01, double r02, double r12)
            : work(3) {
            mean = SharedVector{ x0, y0, z0 };
            L = SharedMatrix(3, 3, 0.0);
            L(0, 0) = s0 * s0; L(1, 1) = s1 * s1; L(2, 2) = s2 * s2;
            L(1, 0) = s1 * s0 * r01;
            L(2, 0) = s2 * s0 * r02;
            L(2, 1) = s2 * s1 * r12;
            gsl_linalg_cholesky_decomp1(&L.gsl());
        }

        double pdf(double x, double y, double z) {
            SharedVector p{ x, y, z };
            double ans;
            gsl_ran_multivariate_gaussian_pdf(&p.gsl(), &mean.gsl(), &L.gsl(), &ans, &work.gsl());
            return ans;
        }

    };



    class Tools {
      public:
        static SharedVector EigenValues(SharedMatrix& mat) {
            int size1 = mat.size1(), size2 = mat.size2();
            gsl_vector* eval = gsl_vector_alloc(size1);
            gsl_matrix* evec = gsl_matrix_alloc(size1, size2);
            gsl_eigen_symmv_workspace* w = gsl_eigen_symmv_alloc(size1);
            gsl_eigen_symmv(&mat.gsl(), eval, evec, w);
            gsl_eigen_symmv_free(w);
            gsl_eigen_symmv_sort(eval, evec, GSL_EIGEN_SORT_ABS_ASC);
            SharedVector eigen(size1, eval->data);
            gsl_vector_free(eval);
            gsl_matrix_free(evec);
            return eigen;
        }

        static double BachelierValue(double fwd, double strike, double vol, double expiry, double opt = 1) {// undiscounted
            double d = opt * (fwd - strike);
            double v = vol * sqrt(expiry);
            return d * gsl_cdf_ugaussian_P(d / v) + v * gsl_ran_ugaussian_pdf(d / v);
        }

        static double BachelierVol(double fwd, double strike, double value, double expiry, double opt = 1) {
            auto fn = [&](double vol) { return BachelierValue(fwd, strike, vol, expiry, opt) - value; };
            return UnivariateFunction::boost_uni_root_one_sided(fn, 0.02);
        }

        static double BlackValue(double fwd, double strike, double vol, double expiry, double opt = 1) {// undiscounted
            double d1 = (std::log(fwd / strike) + vol * vol * expiry / 2) / vol / sqrt(expiry);
            double d2 = d1 - vol * sqrt(expiry);
            return opt * (fwd * gsl_cdf_ugaussian_P(opt * d1) - strike * gsl_cdf_ugaussian_P(opt * d2));
        }

        static double BlackVol(double fwd, double strike, double value, double expiry, double opt = 1) {
            auto fn = [&](double vol) { return BlackValue(fwd, strike, vol, expiry, opt) - value; };
            return UnivariateFunction::boost_uni_root_one_sided(fn, 0.3);
        }

        static double BlackDelta(double fwd, double strike, double vol, double expiry, double opt = 1) {// fwd delta
            double d1 = (std::log(fwd / strike) + vol * vol * expiry / 2) / vol / sqrt(expiry);
            return opt * gsl_cdf_ugaussian_P(opt * d1);
        }

        static double BlackVega(double fwd, double strike, double vol, double expiry) {// undiscouted vega
            double d1 = (std::log(fwd / strike) + vol * vol * expiry / 2) / vol / sqrt(expiry);
            return fwd * gsl_ran_ugaussian_pdf(d1) * sqrt(expiry);
        }

        class TrapezoidalRule1D {
            SharedVector dx;
          public:
            template<typename T> TrapezoidalRule1D(VectorExpression<T> const& x) : dx(diff(x)) {}
            template<typename T> double integrate(VectorExpression<T> const& f) { return sum(dx * (f.range(1) + f.range(0, -1))) / 2.0; }
        };

        class TrapezoidalRule2D {
            TrapezoidalRule1D integ_x, integ_y;
          public:
            template<typename A, typename B> TrapezoidalRule2D(VectorExpression<A> const& x, VectorExpression<B> const& y) : integ_x(x), integ_y(y) {}
            template<typename T> double integrate(MatrixExpression<T> const& f) {
                SharedVector area(f.size2());
                for(auto i : irange(f.size2()))
                    area[i] = integ_x.integrate(f.col(i));
                return integ_y.integrate(area);
            }
        };

        using Quadrature = struct { int n; SharedVector x; SharedVector w; };
        static Quadrature GaussHermite(int n, bool modified) {
            // http://keisan.casio.com/exec/system/1281195844
            // https://www.gnu.org/software/gsl/doc/html/integration.html#c.gsl_integration_fixed_workspace
            auto p = gsl_integration_fixed_alloc(gsl_integration_fixed_hermite, n, 0, 1, 0, 0);
            Quadrature gh;
            gh.n = n;
            gh.x = SharedVector(n, p->x);
            gh.w = SharedVector(n, p->weights);
            gsl_integration_fixed_free(p);
            if(modified) { gh.x *= M_SQRT2; gh.w /= M_SQRTPI; }
            return gh;
        }
    };



    template <typename RETURN, typename... ARGUMENTS>
    class CacheDecorator {
        std::function<RETURN(ARGUMENTS...)> f_;
        std::map<std::tuple<ARGUMENTS...>, RETURN> map_;
      public:
        CacheDecorator(std::function<RETURN(ARGUMENTS...)> f) : f_(f) {}
        RETURN operator()(ARGUMENTS... a) {
            std::tuple<ARGUMENTS...> key(a...);
            auto search = map_.find(key);
            if(search != map_.end()) {
                return search->second;
            }

            auto result = f_(a...);
            map_[key] = result;
            return result;
        }
    };



    template <typename BaseType, typename KeyType = std::string>
    class GlobalDict {
        using dict_t = std::map<KeyType, Shared<BaseType>>;
        static dict_t Repository;
      public:
        static KeyType& push(KeyType& key, Shared<BaseType>& sp_obj) {
            Repository[key] = sp_obj;
            return key;
        }
        static Shared<BaseType> fetch(KeyType& key) {
            auto ptr = Repository[key];
            if(ptr == nullptr)
                THROW("object is NOT in repository");
            return ptr;
        }
    };

    template <typename BaseType, typename KeyType>
    typename GlobalDict<BaseType, KeyType>::dict_t GlobalDict<BaseType, KeyType>::Repository;
}


