/*
*  Created on: March 10, 2019
*  Last modified on: June 15, 2019
*  Author: Changwei Xiong
*
*  Copyright (C) 2019, Changwei Xiong,
*  axcw@hotmail.com, <https://modelmania.github.io/main/>
*
*  Licence: Revised BSD License <https://en.wikipedia.org/wiki/BSD_licenses>
*/

#pragma once

#include <xlkit/xlkit.cpp>
XLKIT_INIT_ADDIN_LABEL("XLKit Test Addin")
XLKIT_PARM(const xlOperand*, DataRange, "Cell range of numbers")

#undef min
#undef max
#include "FEM.h"
using namespace Xiong;

using namespace Xiong;

xlResultOperandPtr xlRange(SharedMatrix const& src) {
    xlResultOperandPtr dest;
    xlCellMatrixRef rng(dest->setMatrix(src.size1(), src.size2()));
    for(auto i : irange(src.size1()))
        for(auto j : irange(src.size2()))
            rng(i, j).set(src(i, j));
    return dest;
}

template<typename T>
xlResultOperandPtr xlRange(T const& d) {
    xlResultOperandPtr result;
    result->set(d);
    return result;
}

#define XL_FUNCTION_BEGIN \
    XLKIT_BEGIN_FUNCTION \
    try {

#define XL_FUNCTION_END \
    } catch(std::exception const&  ex) { \
        return xlRange(ex.what()); \
    } catch(...) { \
        return xlRange("unknown error ..."); \
    } \
    XLKIT_END_FUNCTION(xlResultOperandPtr)

#define XL_REGISTER(FUNC) XLKIT_REGISTER(FUNC, "")

SharedMatrix Real2D(xlParmDataRange& rng) {
    if(rng.value()->isMissing()) {
        return SharedMatrix();
    } else if(rng.value()->isCellMatrix()) { // an array
        xlConstCellMatrixRef src(rng.value()->get<xlConstCellMatrixRef>());
        SharedMatrix dest(src.rows(), src.cols());
        for(auto i : irange(src.rows()))
            for(auto j : irange(src.cols()))
                dest(i, j) = src(i, j).get<double>();
        return dest;
    } else // a scalar
        return SharedMatrix(1, 1, rng.value()->get<double>());
}


//#ifndef _X_EXCEL_H
//#define _X_EXCEL_H
//
//#include <xlkit/xlkit.cpp>
//XLKIT_INIT_ADDIN_LABEL("XLKit Test Addin")
//
//// typedef xlParmDataRange
//XLKIT_PARM(const xlOperand*, DataRange, "Cell range of numbers")
//
//
//#define XL_FUNCTION_BEGIN \
//    XLKIT_BEGIN_FUNCTION \
//    try {
//
//
//#define XL_FUNCTION_END \
//    } catch(std::exception const&  ex) { \
//        return xlCell(ex.what()); \
//    } catch(...) { \
//        return xlCell("unknown error ..."); \
//    } \
//    XLKIT_END_FUNCTION(xlResultOperandPtr)
//
//
//#define XL_REGISTER(FUNC) XLKIT_REGISTER(FUNC, "")
//
//
//#undef min
//#undef max
//#include "FEM.h"
//using namespace Xiong;
//
//Xiong::SharedMatrix MReal_(xlParmDataRange& rng) {
//    if(rng.value()->isMissing()) {
//        return Xiong::SharedMatrix();
//    } else if(rng.value()->isCellMatrix()) { // an array
//        xlConstCellMatrixRef src(rng.value()->get<xlConstCellMatrixRef>());
//        Xiong::SharedMatrix dest(src.rows(), src.cols());
//        for(int i = 0; i < src.rows(); i++)
//            for(int j = 0; j < src.cols(); j++)
//                dest(i, j) = src(i, j).get<double>();
//        return dest;
//    } else // a scalar
//        return Xiong::SharedMatrix(1, 1, rng.value()->get<double>());
//}
//
//xlResultOperandPtr xlRange(SharedMatrix const& src) {
//    xlResultOperandPtr dest;
//    xlCellMatrixRef rng(dest->setMatrix(src.size1(), src.size2()));
//    for(int i = 0; i < src.size1(); i++)
//        for(int j = 0; j < src.size2(); j++)
//            rng(i, j).set(src(i, j));
//    return dest;
//}
//
//
//template<typename T>
//xlOperand* xlCell(T const & d) {
//    xlResultOperandPtr result;
//    result->set(d);
//    return result;
//}







xlOperand* XLKIT_API
X_HestonFEM(char const* name_, xlParmDataRange input_, xlParmDataRange pde_,
            int type_, double strike, double dn_barr, double up_barr, double rebate) {
    XL_FUNCTION_BEGIN
    SharedMatrix input = Real2D(input_);
    double spot =   input(0, 0);  //initial spot
    double rd =     input(1, 0);  //domestic rate
    double rf =     input(2, 0);  //foreign rate
    double expiry = input(3, 0);  //time to maturity
    double kappa =  input(4, 0);  //kappa, mean reversion rate
    double theta =  input(5, 0);  //theta, long term mean
    double xi =     input(6, 0);  //xi, volitility of variance
    double rho =    input(7, 0);  //rho, correlation
    double v0 =     input(8, 0);  //initial variance

    //spatial and temporal resolutions
    SharedMatrix pde = Real2D(pde_);
    int Nv     = pde(0, 0);  //resolution in variance
    int Ns     = pde(1, 0);  //resolution in spot process
    int Nt     = pde(2, 0);  //resolution in time per
    int solver = pde(3, 0);  //iterative solver: 0: repeated GMRES; 1: GSL GMRES; 2: CGS

    Product::OPTION type = type_ > 0 ? Product::OPTION::CALL : Product::OPTION::PUT; //option type

    Process process(spot, rd, rf, kappa, theta, xi, rho, v0);
    Product* product;
    if(std::string(name_) == "Vanilla") //vanilla product
        product = &EuropeanVanilla(type, strike, expiry);
    else if(std::string(name_) == "Barrier")
        product = &DoubleBarrier(type, strike, expiry, dn_barr, up_barr, rebate);
    else if(std::string(name_) == "DNT")
        product = &DoubleNoTouch(type, strike, expiry, dn_barr, up_barr);

    FEM fem(*product, process, Nv, Ns, Nt);
    return xlRange(fem.solve(solver));
    XL_FUNCTION_END
}
XL_REGISTER(X_HestonFEM)



