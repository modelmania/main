/*
*  Created on: March 10, 2019
*  Last modified on: June 15, 2019
*  Author: Changwei Xiong
*
*  Copyright (C) 2019, Changwei Xiong,
*  axcw@hotmail.com, <https://modelmania.github.io/main/>
*
*  Licence: Revised BSD License <https://en.wikipedia.org/wiki/BSD_licenses>
*/


#pragma once

#include <set>
#include "Utility.h"


namespace Xiong {
    using std::log;
    using std::exp;
    using std::vector;

    struct Node {
        int n; // index in the node list
        double x, y;  // coordinates of the node
        Node* a, *b; // left and right nodes that form the boundary edges
    };

    struct Element : public std::array<Node*, 3> {
        SharedMatrix JG; //Jacob.inv().trans() * m_Grad
        double jf;// Jacobian Factor := absolute of Jacobian determinant, = area of reference triangle * 2
    };

    class Mesh {
        vector<Node> m_node;
        vector<Element> m_elem;

      public:
        using NodeSet = std::set<Node*>;
        NodeSet xmin, xmax, ymin, ymax;

        SharedVector xv, yv;
        //Constant Matrices calcuated on reference triangle
        SharedMatrix Grad; //const, gradient matrix of basis function on reference triangle
        SharedMatrix Duo; //const, linear integral matrix, "unit double volume", integral of product of basis functions on reference triangle
        SharedMatrix Mono; //const, "unit single volume" matrix, integral of basis function on reference triangle

        Mesh() {}
        Mesh(SharedVector& x, SharedVector& y)
            : m_node(x.size() * y.size()),
              m_elem((x.size() - 1) * (y.size() - 1) * 2) {
            // G = | -1  1  0 |,  gradient of basis function on reference triangle
            //     | -1  0  1 |
            Grad = SharedMatrix(2, 3, 0.0);
            Grad(1, 0) = Grad(0, 0) = -1;
            Grad(1, 2) = Grad(0, 1) = 1;

            //      1    | 2  1  1 |
            // L = --- * | 1  2  1 |,  integral of product of basis functions on reference triangle
            //      24   | 1  1  2 |
            Duo = SharedMatrix(3, 3, 1.0);
            Duo(2, 2) = Duo(1, 1) = Duo(0, 0) = 2;
            Duo *= 1.0 / 24;

            Mono = SharedMatrix(3, 1, 1. / 6);// integral of basis function on reference triangle

            xv = x;
            yv = y;
            int nx = x.size();
            int ny = y.size();
            auto node_index = [&ny](int i, int j) {return i * ny + j; };
            /* Assume any points where X and Y meet belong to Y
                         j
                 X0Y0 -- X0 -- X0Y1
                  |              |
              i   Y0             Y1
                  |              |
                 X1Y0 -- X1 -- X1Y1
            */
            for(int i = 0; i < nx; i++)
                for(int j = 0; j < ny; j++) {
                    int n = node_index(i, j);
                    Node* a = nullptr;
                    Node* b = nullptr;
                    NodeSet* bdry = nullptr;
                    if(i == 0 && j == 0) {                 // X0Y0
                        a = &m_node[node_index(i + 1, j)];
                        b = &m_node[node_index(i, j + 1)];
                        bdry = &ymin;
                    } else if(i == 0 && j == ny - 1) {     // X0Y1
                        a = &m_node[node_index(i + 1, j)];
                        b = &m_node[node_index(i, j - 1)];
                        bdry = &ymax;
                    } else if(i == nx - 1 && j == 0) {     // X1Y0
                        a = &m_node[node_index(i - 1, j)];
                        b = &m_node[node_index(i, j + 1)];
                        bdry = &ymin;
                    } else if(i == nx - 1 && j == ny - 1) { // X1Y1
                        a = &m_node[node_index(i - 1, j)];
                        b = &m_node[node_index(i, j - 1)];
                        bdry = &ymax;
                    } else if(i == 0 || i == nx - 1) { // 1st row or last row, X0 or X1
                        bdry = i == 0 ? &xmin : &xmax;
                        a = &m_node[node_index(i, j - 1)];
                        b = &m_node[node_index(i, j + 1)];
                    } else if(j == 0 || j == ny - 1) { // 1st col or last col, Y0 or Y1
                        bdry = j == 0 ? &ymin : &ymax;
                        a = &m_node[node_index(i - 1, j)];
                        b = &m_node[node_index(i + 1, j)];
                    }
                    if(bdry != nullptr) bdry->insert(&m_node[n]);
                    m_node[n].n = n;
                    m_node[n].x = x[i];
                    m_node[n].y = y[j];
                    m_node[n].a = a;
                    m_node[n].b = b;
                }

            // record trangles' 3 vertices in counter clockwise order
            int elem = 0;
            for(int i = 0; i < nx - 1; i++)
                for(int j = 0; j < ny - 1; j++) {
                    m_elem[elem][0] = &m_node[node_index(i, j)];
                    m_elem[elem][1] = &m_node[node_index(i + 1, j)];
                    m_elem[elem][2] = &m_node[node_index(i, j + 1)];
                    elem++;
                    m_elem[elem][0] = &m_node[node_index(i + 1, j)];
                    m_elem[elem][1] = &m_node[node_index(i + 1, j + 1)];
                    m_elem[elem][2] = &m_node[node_index(i, j + 1)];
                    elem++;
                }

            for(int i = 0; i < m_elem.size(); i++) {
                Element& elem = m_elem[i];
                SharedMatrix Jacob(2, 2); //Jacobian matrix of affine mapping, maps to reference triangle
                /* Jacob = | x1-x0  x2-x0 |
                           | y1-y0  y2-y0 |  */
                Jacob(0, 0) = elem[1]->x - elem[0]->x;
                Jacob(0, 1) = elem[2]->x - elem[0]->x;
                Jacob(1, 0) = elem[1]->y - elem[0]->y;
                Jacob(1, 1) = elem[2]->y - elem[0]->y;
                m_elem[i].JG = Jacob.inverse().transpose().multiply(Grad);
                m_elem[i].jf = fabs(Jacob.determ());
            }
        }

        Node& node(int n) { return m_node[n]; }
        Element& element(int elem) { return m_elem[elem]; }
        size_t num_node() const { return m_node.size(); }
        size_t num_element() const { return m_elem.size(); }
    };




    class Process {
      public:
        double m_spot;    //spot
        double m_rd;      //domestic rate
        double m_rf;      //foreign/dividend rate
        double m_expiry;  //maturity
        double m_kappa;   //mean reversion rate
        double m_theta;   //long term mean
        double m_xi;      //volitility of variance
        double m_rho;     //correlation
        double m_v0;      //initial volatility

        SharedMatrix m_A; //const, constant part of A matrix

        Process(double spot, double rd, double rf, double kappa, double theta, double xi, double rho, double v0) :
            m_spot(spot), m_rd(rd), m_rf(rf), m_kappa(kappa), m_theta(theta), m_xi(xi), m_rho(rho), m_v0(v0) {
            // A = 0.5 * |xi^2   xi*rho|, constant part of matrix A
            //           |xi*rho    1  |
            m_A = SharedMatrix(2, 2, 0.5);
            m_A(0, 0) = m_xi * m_xi * 0.5;
            m_A(1, 0) = m_A(0, 1) = m_xi * m_rho * 0.5;
        }

        double black_scholes_w(double var, double logspot, double strike, double tau, double opt) {
            var = std::max(var, 1e-5); // prevent dividend by zero and prevent CDF returing inf
            return exp(-m_rd * tau) * Tools::BlackValue(exp(logspot + (m_rd - m_rf) * tau), strike, sqrt(var), tau, opt);
        }

        double black_scholes_dwdy(double var, double logspot, double strike, double tau, double opt) {
            var = std::max(var, 1e-5); // prevent dividend by zero and prevent CDF returing inf
            double dp = (logspot - log(strike) + (m_rd - m_rf + var / 2) * tau) / sqrt(var * tau);
            return opt * exp(logspot - m_rf * tau) * gsl_cdf_ugaussian_P(opt * dp);
        }

        double black_scholes_dwdv(double var, double logspot, double strike, double tau) {
            var = std::max(var, 1e-5); // prevent dividend by zero and prevent CDF returing inf
            double dp = (logspot - log(strike) + (m_rd - m_rf + var / 2) * tau) / sqrt(var * tau);
            return exp(logspot - m_rf * tau) * gsl_ran_ugaussian_pdf(dp) * sqrt(tau / var) / 2;
        }

        SharedMatrix local_stiffness_matrix(Mesh& mesh, int i) { //local stiffness matrix = 1st integral + 2nd integral
            Element const& elem = mesh.element(i);
            double v = (elem[0]->x + elem[1]->x + elem[2]->x) / 3.0; // v = x, average from the 3 vertices
            SharedMatrix A = m_A * (v * 0.5);// 0.5 is the area of reference triangle
            SharedMatrix b(1, 2);
            b(0, 0) = -m_kappa * (m_theta - v) + 0.5 * m_xi * m_xi;
            b(0, 1) = -(m_rd - m_rf) + 0.5 * (v + m_rho * m_xi);
            return (elem.JG.transpose().multiply(A) + mesh.Mono.multiply(b)).multiply(elem.JG) * elem.jf;
        }

        SharedMatrix local_mass_matrix(Mesh& mesh, int i) {
            return mesh.Duo * mesh.element(i).jf;//local mass matrix = 3rd integral
        }

        double estimate_variance_bound(double t) {// given by conditional mean and variance of variance process
            double a = m_xi * m_xi / m_kappa;
            double b = exp(-m_kappa * t);
            double mean = m_theta + (m_v0 - m_theta) * b;
            double var = (m_v0 * a * b + m_theta * a / 2 * (1 - b)) * (1 - b);
            return mean + sqrt(var) * 8;// extends to 10 times of vol of variance process
        }
        SharedVector estimate_logspot_bounds(double t) {
            double mean = m_theta + (m_v0 - m_theta) * exp(-m_kappa * t);
            double coef = sqrt(mean * t) * 4;
            double logfwd = log(m_spot) + (m_rd - m_rf) * t;
            return { logfwd - coef, logfwd + coef };
        }
    };




    class Product {
      public:
        enum class PRODUCT { VANILLA, BARRIER, DNT };
        enum class OPTION { CALL, PUT };
        double m_expiry;
        double m_strike;
        double m_up_bar;
        double m_dn_bar;
        OPTION m_optype;

        Product(OPTION optype, double strike, double expiry)
            : m_optype(optype), m_strike(strike), m_expiry(expiry) {
            m_up_bar = 0;
            m_dn_bar = 0;
        }
        virtual PRODUCT prod_type() = 0;
        virtual double payoff(double spot) = 0;
        virtual void set_terminal(SharedVector& value, Mesh& mesh) {
            for(int n = 0; n < mesh.num_node(); n++)
                value[n] = payoff(exp(mesh.node(n).y));
        }
        virtual SharedVector boundary_integral(Mesh& mesh, Process& process, double t) = 0;
        virtual void set_stiffness_identity(SparseMatrix& stiffness, Mesh& mesh) = 0;
        virtual void set_dirichlet(SharedVector& value, Mesh& mesh, Process& process, double t) = 0;
    };

    class EuropeanVanilla : public Product {
      public:
        EuropeanVanilla(OPTION optype, double strike, double expiry)
            : Product(optype, strike, expiry) {}
        double payoff(double spot) {
            if(m_optype == OPTION::CALL)
                return spot > m_strike ? spot - m_strike : 0;
            else
                return spot < m_strike ? m_strike - spot : 0;
        }
        PRODUCT prod_type() { return PRODUCT::VANILLA; }

        SharedVector boundary_integral(Mesh& mesh, Process& process, double t) {  //Neumann boundaries
            SharedVector val(mesh.num_node(), 0.0);
            double opt = m_optype == OPTION::CALL ? 1 : -1;
            for(auto const &p : m_optype == OPTION::CALL ? mesh.ymax : mesh.ymin) {
                double h = p->x / 2 * process.black_scholes_dwdy(p->x, p->y, m_strike, m_expiry - t, opt) * opt;
                val[p->n] = h * std::abs(p->a->x - p->b->x) / 2;
            }
            for(auto const &p : mesh.xmax) {
                double h = p->x / 2 * process.m_xi * process.m_xi * process.black_scholes_dwdv(p->x, p->y, m_strike, m_expiry - t);
                val[p->n] = h * std::abs(p->a->y - p->b->y) / 2;
            }
            return val;
        }
        void set_stiffness_identity(SparseMatrix& stiffness, Mesh& mesh) {
            for(auto const &p : m_optype == OPTION::CALL ? mesh.ymin : mesh.ymax)
                stiffness.set_row_identity(p->n);
        }
        void set_dirichlet(SharedVector & value, Mesh & mesh, Process & process, double t) { //Dirichlet boundaries
            double opt = m_optype == OPTION::CALL ? 1 : -1;
            for(auto const &p : m_optype == OPTION::CALL ? mesh.ymin : mesh.ymax)
                value[p->n] = process.black_scholes_w(p->x, p->y, m_strike, m_expiry - t, opt);
        }
    };

    class DoubleBarrier : public EuropeanVanilla {
      public:
        double m_rebate;

        DoubleBarrier(OPTION optype, double strike, double expiry, double dn_bar, double up_bar, double rebate = 0)
            : EuropeanVanilla(optype, strike, expiry) {
            m_dn_bar = dn_bar;
            m_up_bar = up_bar;
            m_rebate = rebate;
        }
        PRODUCT prod_type() { return PRODUCT::BARRIER; }

        double payoff(double spot) {
            return m_dn_bar < spot || spot < m_up_bar ? EuropeanVanilla::payoff(spot) : 0;
        }
        SharedVector boundary_integral(Mesh& mesh, Process& process, double t) {  //Neumann boundaries
            return SharedVector(mesh.num_node(), 0.0);
        }
        void set_stiffness_identity(SparseMatrix& stiffness, Mesh& mesh) {
            for(auto const &p : mesh.ymin)
                stiffness.set_row_identity(p->n);
            for(auto const &p : mesh.ymax)
                stiffness.set_row_identity(p->n);
        }
        void set_dirichlet(SharedVector & value, Mesh & mesh, Process & process, double t) { //Dirichlet boundaries
            for(auto const &p : mesh.ymin)
                value[p->n] = m_rebate;
            for(auto const &p : mesh.ymax)
                value[p->n] = m_rebate;
        }
    };

    class DoubleNoTouch : public DoubleBarrier {
      public:
        DoubleNoTouch(OPTION optype, double strike, double expiry, double dn_bar, double up_bar)
            : DoubleBarrier(optype, strike, expiry, dn_bar, up_bar) {}
        PRODUCT prod_type() { return PRODUCT::DNT; }
        double payoff(double spot) {
            return m_dn_bar < spot || spot < m_up_bar ? 1 : 0;
        }
    };




    class FEM {
        double interpolate(SharedVector& w, double x, double y) { // interpolation of the final result
            SharedMatrix m(2, 2);
            SharedVector r(2);
            for(int i = 0; i < m_mesh.num_element(); i++) {
                Element const& elem = m_mesh.element(i);
                m(0, 0) = elem[0]->x - elem[2]->x;
                m(0, 1) = elem[1]->x - elem[2]->x;
                m(1, 0) = elem[0]->y - elem[2]->y;
                m(1, 1) = elem[1]->y - elem[2]->y;
                r[0] = x - elem[2]->x;
                r[1] = y - elem[2]->y;
                r = m.solve_for(r);
                double L0 = r[0];
                double L1 = r[1];
                double L2 = 1.0 - L0 - L1;

                if(L0 >= 0 && L0 <= 1 && L1 >= 0 && L1 <= 1 && L2 >= 0 && L2 <= 1)   //within the triangle
                    return L0 * w[elem[0]->n] + L1 * w[elem[1]->n] + L2 * w[elem[2]->n];
            }
            THROW("interpolation failed");
        }

      public:
        Product& m_product;
        Process& m_process;
        Mesh m_mesh;
        int m_Nt;

        FEM(Product& product, Process& process, int Nv, int Ns, int Nt)
            : m_product(product), m_process(process) {

            double vmax = process.estimate_variance_bound(product.m_expiry);
            SharedVector v = Xiong::Grid::nonuniform(0, vmax, Nv, { process.m_v0 }, 0.1);  // vmin = 0

            SharedVector s;
            if(product.prod_type() == Product::PRODUCT::VANILLA) {
                SharedVector ends = process.estimate_logspot_bounds(product.m_expiry);
                s = Xiong::Grid::nonuniform(ends[0], ends[1], Ns, 0.1, { log(process.m_spot), log(product.m_strike) });
            } else {
                double a = log(product.m_dn_bar);
                double b = log(product.m_up_bar);
                s = Xiong::Grid::nonuniform(a, b, Ns, 0.1, { a, log(process.m_spot), log(product.m_strike), b });
            }

            m_mesh = Mesh(v, s);
            m_Nt = Nt;
        }


        SharedMatrix solve(int solver) {
            int n_node = m_mesh.num_node();

            SharedVector tv = Xiong::Grid::uniform(0, m_product.m_expiry, m_Nt);
            double const im_z = 1; //z = 1 for fully implicit, z = 0 for fully explicit, z = 0.5 for Crank-Nicolson
            double const im_c = im_z * m_process.m_rd + 1 / (m_product.m_expiry / (tv.size() - 1));
            double const im_z_ = im_z - 1.0; // = 0
            double const im_c_ = im_c - m_process.m_rd;
            double const cn_z = .5; //z = 1 for fully implicit, z = 0 for fully explicit, z = 0.5 for Crank-Nicolson
            double const cn_c = cn_z * m_process.m_rd + 1 / (m_product.m_expiry / (tv.size() - 1));
            double const cn_z_ = cn_z - 1.0;
            double const cn_c_ = cn_c - m_process.m_rd;

            SparseMatrix imL(n_node, n_node);//LHS matrix, implicit
            SparseMatrix imR(n_node, n_node);//RHS matrix, implicit
            SparseMatrix cnL(n_node, n_node);//LHS matrix, Crank-Nicolson
            SparseMatrix cnR(n_node, n_node);//RHS matrix, Crank-Nicolson
            for(int i = 0; i < m_mesh.num_element(); i++) { //construct LHS and RHS stiffness matrix
                Element const& elem = m_mesh.element(i);
                SharedMatrix mLS = m_process.local_stiffness_matrix(m_mesh, i); //local stiffness matrix = 1st integral + 2nd integral
                SharedMatrix mLM = m_process.local_mass_matrix(m_mesh, i); //local mass matrix = 3rd integral
                for(int i = 0; i < 3; i++)
                    for(int j = 0; j < 3; j++) {
                        imL.add(elem[i]->n, elem[j]->n, mLS(i, j) * im_z + mLM(i, j) * im_c);
                        imR.add(elem[i]->n, elem[j]->n, mLS(i, j) * im_z_ + mLM(i, j) * im_c_);
                        cnL.add(elem[i]->n, elem[j]->n, mLS(i, j) * cn_z + mLM(i, j) * cn_c);
                        cnR.add(elem[i]->n, elem[j]->n, mLS(i, j) * cn_z_ + mLM(i, j) * cn_c_);
                    }
            }

            m_product.set_stiffness_identity(imL, m_mesh);
            m_product.set_stiffness_identity(cnL, m_mesh);

            //initiate
            SharedVector value(n_node);
            m_product.set_terminal(value, m_mesh);

            for(int i = tv.size() - 2; i >= 0; i--) {
                if(tv.size() - i <= 4) {  // implicit for the first a few steps to overcome instability in Crank-Nicolson
                    SharedVector rhs = imR * value + m_product.boundary_integral(m_mesh, m_process, tv[i]);
                    m_product.set_dirichlet(rhs, m_mesh, m_process, tv[i]);
                    value = imL.solve_GMRES(value, rhs, 100, 1e-8);
                } else {
                    SharedVector rhs = cnR * value - m_product.boundary_integral(m_mesh, m_process, tv[i + 1]) * cn_z_ + m_product.boundary_integral(m_mesh, m_process, tv[i]) * cn_z;
                    m_product.set_dirichlet(rhs, m_mesh, m_process, tv[i]);
                    if(solver == 0)
                        value = cnL.solve_GMRES(value, rhs, 100, 1e-8); // restarted GMRES with preconditioner
                    else if(solver == 1)
                        value = cnL.solve_GSL(value, rhs, 500, 1e-8); // GSL restarted GMRES without preconditioner
                    else
                        value = cnL.solve_CGS(value, rhs, 2000, 1e-8); // CGS without preconditioner
                }
            }

            SharedMatrix res(m_mesh.xv.size() + 1, m_mesh.yv.size() + 1);
            res(0, 0) = interpolate(value, m_process.m_v0, log(m_process.m_spot));
            res.col(0).range(1) = m_mesh.xv;
            res.row(0).range(1) = exp(m_mesh.yv);
            res.range(1, 1) = SharedMatrix(m_mesh.xv.size(), m_mesh.yv.size(), value.begin());
            return res;
        }
    };

}

