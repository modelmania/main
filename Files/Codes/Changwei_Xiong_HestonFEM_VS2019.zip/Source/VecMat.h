/*
*  Created on: March 10, 2019
*  Last modified on: August 8, 2020
*  Author: Changwei Xiong
*
*  Copyright (C) 2019 - 2020, Changwei Xiong,
*  axcw@hotmail.com, <https://modelmania.github.io/main/>
*
*  Licence: Revised BSD License <https://en.wikipedia.org/wiki/BSD_licenses>
*/
#pragma once

#define COMPILE_RELEASE

#ifdef COMPILE_RELEASE
    #define GSL_RANGE_CHECK_OFF // GSL flag
    #define NDEBUG // turn off assert(...)
#endif

#define BOOST_ALL_NO_LIB // no static boost lib
#define HAVE_INLINE // GSL flag


#define _STR_(x) #x //double expansion trick
#define __STR__(x) _STR_(x)
#define S__LINE__ __STR__(__LINE__)
#define __FILENAME__ (std::strrchr(__FILE__, '/') ? std::strrchr(__FILE__, '/') + 1 : __FILE__)
#define LOCATION __FILENAME__ + " : Line " + S__LINE__
#define THROW(MESSAGE) throw std::runtime_error(__Debug("Err: " + boost::lexical_cast<std::string>(MESSAGE) + " @ " + LOCATION))


#include <gsl/gsl_spblas.h>
#include <gsl/gsl_splinalg.h>
#include <boost/range/irange.hpp>
#include <numeric> // std::accumulate


template <typename T> std::string __Debug(T const& first) {
    std::string f = boost::lexical_cast<std::string>(first) + "\n";
    OutputDebugStringA(f.c_str());
    return f;
}
template <typename T, typename... TS> std::string __Debug(T const& first, TS const& ... rest) {
    std::string f = boost::lexical_cast<std::string>(first) + "\t";
    OutputDebugStringA(f.c_str());
    return f + __Debug(rest...);
}


namespace Xiong {
    using std::string;
    using std::size_t;
    using std::exp;
    using std::log;
    using std::sqrt;
    template<typename T> inline decltype(auto) square(T const& v) { return v * v; }
    using boost::irange;
    template<typename T> using Shared = std::shared_ptr<T>;

    class Vector;
    class SharedVector;

    template<typename T> class VectorExpression {
        using self_t = VectorExpression;
        int mod(int i) const { int m = size(); return i >= m ? m : (i %= m) < 0 ? i + m : i; }
        template<typename B> void check(VectorExpression<B> const& b) const { assert(gsl().size == b.gsl().size); }
      protected:
        using val_t = double;
      public:
        gsl_vector& gsl() { return static_cast<T&>(*this).gsl(); }
        gsl_vector const& gsl() const { return static_cast<T const&>(*this).gsl(); }
        auto begin() { return static_cast<T&>(*this).begin(); }
        auto end() { return static_cast<T&>(*this).end(); }
        auto begin() const { return static_cast<T const&>(*this).begin(); }
        auto end() const { return static_cast<T const&>(*this).end(); }
        val_t& operator[](size_t i) { assert(i < size()); return static_cast<T&>(*this)[i]; } // non-negative indices
        val_t const& operator[](size_t i) const { assert(i < size()); return static_cast<T const&>(*this)[i]; } // non-negative indices

        val_t& operator()(int i) { return (*this)[mod(i)]; } // allows negative indices
        val_t const& operator()(int i) const { return (*this)[mod(i)]; } // allows negative indices
        size_t size() const { return gsl().size; }

        auto range(int a = 0, int b = INT_MAX) { a = mod(a); b = mod(b); assert(a <= b); return Vector(gsl(), a, 1, b - a); }
        auto const range(int a, int b = INT_MAX) const { a = mod(a); b = mod(b); assert(a <= b); return Vector(gsl(), a, 1, b - a); }
        auto slice(size_t start, size_t stride, size_t num) { return Vector(gsl(), start, stride, num); } // vector slice

        template<typename B> self_t& operator=(VectorExpression<B> const& b) { check(b); gsl_vector_memcpy(&gsl(), &b.gsl()); return *this; } // VectorExpression<T> = VectorExpression<B>, for T != B
        self_t& operator=(self_t const& b) { if(this != &b) operator=<T>(b); return *this; } // self_t = self_t, calls the templated operator= above, must explicitly override the default operator=!! Otherwise only shallow copy.
        self_t& operator=(val_t const& b) { gsl_vector_set_all(&gsl(), b); return *this; }  // VectorExpression<T> = double // for(auto& a : *this) a = b;

        template<typename V> auto& operator+=(V const& b) { return apply(std::plus<val_t>(), b); }
        template<typename V> auto& operator-=(V const& b) { return apply(std::minus<val_t>(), b); }
        template<typename V> auto& operator*=(V const& b) { return apply(std::multiplies<val_t>(), b); }
        template<typename V> auto& operator/=(V const& b) { return apply(std::divides<val_t>(), b); }
        template<typename V> auto operator+(V const& b) const { return map(std::plus<val_t>(), b); }
        template<typename V> auto operator-(V const& b) const { return map(std::minus<val_t>(), b); }
        template<typename V> auto operator*(V const& b) const { return map(std::multiplies<val_t>(), b); }
        template<typename V> auto operator/(V const& b) const { return map(std::divides<val_t>(), b); }
        friend auto operator+(val_t a, self_t const& b) { return b + a; }
        friend auto operator-(val_t a, self_t const& b) { return b.map(std::bind1st(std::minus<val_t>(), a)); }
        friend auto operator*(val_t a, self_t const& b) { return b * a; }
        friend auto operator/(val_t a, self_t const& b) { return b.map(std::bind1st(std::divides<val_t>(), a)); }

        template<typename F> auto map(F const& f) const { SharedVector r(size()); std::transform(begin(), end(), r.begin(), f); return r; }
        template<typename F> auto map(F const& f, val_t const& b) const { return map(std::bind2nd(f, b)); }
        template<typename F, typename B> auto map(F const& f, VectorExpression<B> const& b) const { check(b); SharedVector r(size()); std::transform(begin(), end(), b.begin(), r.begin(), f); return r; }
        template<typename F> self_t& apply(F const& f) { for(auto& a : *this) a = f(a); return *this; }
        template<typename F> self_t& apply(F const& f, val_t const& b) { return apply(std::bind2nd(f, b)); }
        template<typename F, typename B> self_t& apply(F const& f, VectorExpression<B> const& b) { check(b); std::transform(begin(), end(), b.begin(), begin(), f); return *this; }

        template<typename B> val_t dot(VectorExpression<B> const& b) const { double r; gsl_blas_ddot(&gsl(), &b.gsl(), &r); return r; }
        friend val_t sum(self_t const& v) { return std::accumulate(v.begin(), v.end(), 0.0); }
        friend auto log(self_t const& v) { return v.map(static_cast<val_t(*)(val_t)>(std::log)); }   //[](val_t & x) {return std::log(x);}); }
        friend auto exp(self_t const& v) { return v.map(static_cast<val_t(*)(val_t)>(std::exp)); }
        friend auto abs(self_t const& v) { return v.map(static_cast<val_t(*)(val_t)>(std::fabs)); }
        friend auto tanh(self_t const& v) { return v.map(static_cast<val_t(*)(val_t)>(std::tanh)); }
        friend auto atanh(self_t const& v) { return v.map(static_cast<val_t(*)(val_t)>(std::atanh)); }
        friend auto sqrt(self_t const& v) { return v.map(static_cast<val_t(*)(val_t)>(std::sqrt)); }
        friend val_t norm(self_t const& x) { return gsl_blas_dnrm2(&x.gsl()); } //Euclidean norm ||x||_2 = \sqrt {\sum x_i^2} of the vector x
        friend auto diff(self_t const& v, size_t step = 1) { return v.range(step) - v.range(0, -int(step)); }
        //template<typename B> friend auto joint(self_t const& a, VectorExpression<B> const& b) { SharedVector r(a.size() + b.size()); r.range(0, a.size()) = a; r.range(a.size()) = b; return r; }
    };

    class Vector : public gsl_vector, public VectorExpression<Vector> {
      protected:
        template<typename T> class Iterator {
          public:
            using iterator_category = std::random_access_iterator_tag;
            using value_type = T;
            using difference_type = std::ptrdiff_t;
            using reference = value_type&;
            using pointer = value_type*;

            Iterator(pointer ptr, difference_type stride) : p(reinterpret_cast<pointer>(ptr)), d(stride) {}
            reference operator*() const { return *p; }
            reference operator[](difference_type n) const { return *(p + n * d); }
            Iterator& operator++() { p += d; return *this; } // prefix ++
            Iterator operator+(difference_type n) const { return Iterator(p + n * d, d); }
            difference_type operator-(Iterator const& b) const { return (p - b.p) / d; }
            bool operator!=(Iterator const& b) const { return p != b.p; }
          protected:
            pointer p; // pointer
            difference_type d; // stride
        };

        using self_t = Vector;
        using expr_t = VectorExpression<self_t>;
        using base_t = gsl_vector;
        self_t(self_t const&) = delete; // disable copy constructor, to avoid duplication of l-valued object
      public:
        base_t& gsl() { return *this; }
        base_t const& gsl() const { return *this; }
        auto begin() { return Iterator<val_t>(data, stride); }
        auto end() { return begin() + base_t::size; }
        auto begin() const { return Iterator<val_t const>(data, stride); }
        auto end() const { return begin() + base_t::size; }
        val_t& operator[](size_t i) { return data[stride * i]; }
        val_t const& operator[](size_t i) const { return data[stride * i]; }

        ~Vector() { if(owner) delete[] data; }
        self_t(size_t n = 0) { owner = n > 0; data = owner ? new val_t[n] : nullptr; stride = 1; base_t::size = n; block = nullptr; }
        self_t(size_t n, val_t const& val) : self_t(n) { gsl_vector_set_all(this, val); }
        self_t(self_t&& v) noexcept : base_t(std::move(v)) { v.owner = 0; } // move constructor, shallow copy

        self_t(base_t const& v, size_t start, size_t stride, size_t num) : self_t(v.data + start * v.stride, v.stride * stride, num) {}
        self_t(val_t* ptr, size_t stride_, size_t num) { data = ptr; stride = stride_; base_t::size = num; owner = 0; block = nullptr; }  // subvector view, shallow copy; for "double const* p", use gsl_vector_const_view_array_with_stride

        self_t& operator=(self_t const& b) { if(this != &b) expr_t::operator=(b); return *this; }  // Vector = Vector, deep copy using base class operator=, must explicitly override the default operator=, otherwise shallow copy only
        using expr_t::operator=; //using base class operator= for other overloaded operator='s, e.g. Vector = VectorExpression<T>, deep copy
    };

    class SharedVector : private Shared<Vector>, public VectorExpression<SharedVector> {
        using self_t = SharedVector;
        using base_t = Shared<Vector>;
      public:
        gsl_vector& gsl() { return *get(); }
        gsl_vector const& gsl() const { return *get(); }
        auto begin() { return get()->data; }
        auto end() { return begin() + size(); }
        auto begin() const { return get()->data; }
        auto end() const { return begin() + size(); }
        val_t& operator[](size_t i) { return get()->data[i]; }
        val_t const& operator[](size_t i) const { return get()->data[i]; }

        self_t(size_t n = 0) : base_t(std::make_shared<Vector>(n)) {} // uninitialized; be aware of implicit cast from double to size_t!!
        self_t(size_t n, val_t const& val) : self_t(n) { gsl_vector_set_all(get(), val); } // initialized to val
        self_t(size_t n, val_t const* ptr) : self_t(n) { std::memcpy(begin(), ptr, sizeof(val_t) * n); } // initialized to array
        explicit self_t(gsl_vector const& a) : self_t(a.size) { gsl_vector_memcpy(&gsl(), &a); } // make a clone, deep copy, explicit call
        self_t(std::initializer_list<val_t> const& list) : self_t(list.size()) { std::copy(list.begin(), list.end(), begin()); } // constructed from initializer list
        template<typename A> self_t(VectorExpression<A> const& a) : self_t(a.gsl()) { } // implicit conversion from VectorExpression
        self_t clone() const { return self_t(size(), begin()); }

        self_t& operator=(self_t const& b) { if(this != &b) base_t::operator=(b); return *this; }  // SharedVector = SharedVector, shared_ptr shallow copy; Must override the default operator=; Use the operator= inherited from shared_ptr class
    };



    class Matrix;
    class SharedMatrix;

    template<typename T> class MatrixExpression {
        using self_t = MatrixExpression;
        int mod(int i, int m) const { return i >= m ? m : (i %= m) < 0 ? i + m : i; }
      protected:
        using val_t = double;
      public:
        gsl_matrix& gsl() { return static_cast<T*>(this)->gsl(); }
        gsl_matrix const& gsl() const { return static_cast<T const*>(this)->gsl(); }
        val_t& operator()(size_t i, size_t j) { return *gsl_matrix_ptr(&gsl(), i, j); }
        val_t const& operator()(size_t i, size_t j) const { return *gsl_matrix_const_ptr(&gsl(), i, j); }

        template<typename B> self_t& operator=(MatrixExpression<B> const& b) { assert(size1() == b.size1() && size2() == b.size2()); gsl_matrix_memcpy(&gsl(), &b.gsl()); return *this; } // MatrixExpression<T> = MatrixExpression<B>
        self_t& operator=(self_t const& b) { operator=<T>(b); return *this; } // MatrixExpression<T> = MatrixExpression<T>, override default assigment operator!!
        self_t& operator=(val_t const& b) { gsl_matrix_set_all(&gsl(), b); return *this; } // MatrixExpression<T> = double

        size_t size1() const { return gsl().size1; }
        size_t size2() const { return gsl().size2; }

        auto col(int j) { auto& m(gsl()); return Vector(m.data + mod(j, m.size2), m.tda, m.size1); }
        auto const col(int j) const { auto& m(gsl()); return Vector(m.data + mod(j, m.size2), m.tda, m.size1); }
        auto row(int i) { auto& m(gsl()); return Vector(m.data + mod(i, m.size1) * m.tda, 1, m.size2); }
        auto const row(int i) const { auto& m(gsl()); return Vector(m.data + mod(i, m.size1) * m.tda, 1, m.size2); }

        auto range(int row_min = 0, int col_min = 0, int row_max = INT_MAX, int col_max = INT_MAX) { //row_start, col_start, row_end, col_end
            row_min = mod(row_min, size1()); col_min = mod(col_min, size2()); row_max = mod(row_max, size1()); col_max = mod(col_max, size2());
            assert(row_min <= row_max && col_min <= col_max);
            return Matrix(gsl(), row_min, col_min, row_max - row_min, col_max - col_min);
        }

        template<typename B> self_t& operator+=(MatrixExpression<B> const& b) { assert(size1() == b.size1() && size2() == b.size2()); gsl_matrix_add(&gsl(), &b.gsl()); return *this; }
        template<typename B> self_t& operator-=(MatrixExpression<B> const& b) { assert(size1() == b.size1() && size2() == b.size2()); gsl_matrix_sub(&gsl(), &b.gsl()); return *this; }
        template<typename B> auto operator+(MatrixExpression<B> const& b) const { SharedMatrix a(gsl()); a += b; return a; }
        template<typename B> auto operator-(MatrixExpression<B> const& b) const { SharedMatrix a(gsl()); a -= b; return a; }
        auto operator+(val_t const& b) const { SharedMatrix a(gsl()); gsl_matrix_add_constant(&a.gsl(), b); return a; }
        auto operator-(val_t const& b) const { SharedMatrix a(gsl()); gsl_matrix_add_constant(&a.gsl(), -b); return a; }
        self_t& operator*=(val_t const& b) { gsl_matrix_scale(&gsl(), b); return *this; }
        self_t& operator/=(val_t const& b) { gsl_matrix_scale(&gsl(), 1 / b); return *this; }
        auto operator*(val_t const& b) const { SharedMatrix a(gsl()); a *= b; return a; }
        auto operator/(val_t const& b) const { SharedMatrix a(gsl()); a /= b; return a; }
        template<typename FN> auto map(FN const& fn) const { size_t I = size1(), J = size2(); SharedMatrix r(I, J); for(auto i : irange(I)) for(auto j : irange(J)) r(i, j) = fn((*this)(i, j)); return r; }

        auto transpose() const { SharedMatrix a(size2(), size1()); gsl_matrix_transpose_memcpy(&a.gsl(), &gsl()); return a; }

        auto inverse() const {
            gsl_permutation* perm = gsl_permutation_alloc(size1());
            int signum;
            SharedMatrix a(gsl());
            gsl_linalg_LU_decomp(&a.gsl(), perm, &signum);
            SharedMatrix invmat(size1(), size2());
            gsl_linalg_LU_invert(&a.gsl(), perm, &invmat.gsl());
            gsl_permutation_free(perm);
            return invmat;
        }

        val_t determ() const {
            gsl_permutation* perm = gsl_permutation_alloc(size1());
            int signum;
            SharedMatrix a(gsl());
            gsl_linalg_LU_decomp(&a.gsl(), perm, &signum);
            return gsl_linalg_LU_det(&a.gsl(), signum);
        }

        //MatrixExpression<A> * VectorExpression<B> ==> SharedVector
        template<typename B> SharedVector multiply(VectorExpression<B> const& b) const {
            assert(size2() == b.size());
            SharedVector x(size1());
            gsl_blas_dgemv(CblasNoTrans, 1, &gsl(), &b.gsl(), 0, &x.gsl()); // y = a*op(A)*x + b*y
            return x;
        }
        //MatrixExpression<A> * MatrixExpression<B> ==> SharedMatrix
        template<typename B> SharedMatrix multiply(MatrixExpression<B> const& b) const {
            assert(size2() == b.size1());
            SharedMatrix x(size1(), b.size2());
            gsl_blas_dgemm(CblasNoTrans, CblasNoTrans, 1, &gsl(), &b.gsl(), 0, &x.gsl()); // C = a*op(A)*op(B) + b*C
            return x;
        }
        //Solve SharedVector x for MatrixExpression<A> * x = VectorExpression<B>
        template<typename B> SharedVector solve_for(VectorExpression<B> const& b) const {
            assert(size1() == size2() && size2() == b.size());
            gsl_permutation* perm = gsl_permutation_alloc(size1());
            int signum;
            SharedMatrix a(gsl());
            gsl_linalg_LU_decomp(&a.gsl(), perm, &signum);
            SharedVector x(size1());
            gsl_linalg_LU_solve(&a.gsl(), perm, &b.gsl(), &x.gsl());
            gsl_permutation_free(perm);
            return x;
        }
    };

    class Matrix : public gsl_matrix, public MatrixExpression<Matrix> {
        using self_t = Matrix;
        using expr_t = MatrixExpression<self_t>;
        using base_t = gsl_matrix;
        self_t(self_t const&) = delete; // copy constructor, disabled to avoid duplication of l-valued object, otherwise it may cause multiple deletions
      public:
        base_t& gsl() { return *this; }
        base_t const& gsl() const { return *this; }

        ~Matrix() { if(owner) delete[] data; }
        self_t(size_t i = 0, size_t j = 0) { owner = i * j > 0; data = owner ? new double[i * j] : nullptr; base_t::size1 = i; base_t::size2 = j; tda = j; block = nullptr; }
        self_t(self_t&& m) noexcept : base_t(std::move(m)) { m.owner = 0; } // move constructor, shallow copy
        self_t(size_t i, size_t j, val_t const& val) : self_t(i, j) { gsl_matrix_set_all(this, val); } // initialized to val
        self_t(gsl_matrix& v, size_t k1, size_t k2, size_t n1, size_t n2) : base_t(gsl_matrix_submatrix(&v, k1, k2, n1, n2).matrix) {} //submatrix: m'(i,j) = m->data[(k1*m->tda + k2) + i*m->tda + j]
        self_t(gsl_vector& v, size_t n1, size_t n2, size_t tda) : base_t(gsl_matrix_view_vector_with_tda(&v, n1, n2, tda).matrix) {}//m'(i,j) = v->data[i*tda + j]

        self_t& operator=(self_t const& b) { expr_t::operator=(b); return *this; } // Matrix = Matrix, deep copy using base class operator=, must explicitly override the default operator=, otherwise shallow copy only
        using expr_t::operator=; //using base class operator= for other overloaded operator='s, e.g. Matrix = MatrixExpression<T>, deep copy
    };

    class SharedMatrix : private Shared<Matrix>, public MatrixExpression<SharedMatrix> {
        using self_t = SharedMatrix;
        using expr_t = MatrixExpression<self_t>;
        using base_t = Shared<Matrix>;
      public:
        gsl_matrix& gsl() { return *get(); }
        gsl_matrix const& gsl() const { return *get(); }

        self_t(size_t i = 0, size_t j = 0) : Shared<Matrix>(std::make_shared<Matrix>(i, j)) {} // uninitialized
        self_t(size_t i, size_t j, val_t const& val) : self_t(i, j) { gsl_matrix_set_all(get(), val); } // initialized to val
        self_t(size_t i, size_t j, val_t const* ptr) : self_t(i, j) { std::memcpy(get()->data, ptr, i * j * sizeof(val_t)); } //initialized to double array

        explicit self_t(gsl_matrix const& a) : self_t(a.size1, a.size2) { gsl_matrix_memcpy(&gsl(), &a); }
        explicit self_t(gsl_vector const& a) : self_t(a.size, 1) { gsl_vector_memcpy(&col(0).gsl(), &a); } // single col matrix from VectorExpression
        self_t& operator=(self_t const& b) { base_t::operator=(b); return *this; } // SharedMatrix = SharedMatrix, shared_ptr shallow copy; Must override the default operator=; Use the operator= inherited from shared_ptr class
    };


    class Shared2D : public SharedVector {
        using self_t = Shared2D;
        using base_t = SharedVector;
        size_t I, J;
        self_t(self_t const&) = delete; // copy constructor, disabled to avoid duplication of l-valued object
      public:
        self_t(size_t i = 0, size_t j = 0) : I(i), J(j), base_t(i * j) {}
        self_t(size_t i, size_t j, val_t const* ptr) : I(i), J(j), base_t(i * j, ptr) {}
        self_t& operator=(self_t const& b) { I = b.I; J = b.J; base_t::operator=(b); return *this; } // Shared = Shared, shallow copy, must override the default copy assignment, use default copy assigment inherited from shared_ptr class
        self_t(self_t&& b) noexcept { operator=(std::move(b)); } // move constructor, shallow copy, needed by clone()
        self_t clone() { return self_t(I, J, begin()); }
        size_t size(size_t d) const { return d < 1 ? I : J; }

        template<typename B> self_t operator+(B const& b) const { self_t a(I, J, begin()); a += b; return a; }
        template<typename B> self_t operator-(B const& b) const { self_t a(I, J, begin()); a -= b; return a; }
        val_t& operator()(size_t i, size_t j) { return begin()[i + j * I]; }
        val_t const& operator()(size_t i, size_t j) const { return begin()[i + j * I]; }
        auto x(size_t j) { return Vector(begin() + j * I, 1, I); }
        auto y(size_t i) { return Vector(begin() + i, I, J); }
        auto xy() { SharedMatrix r(I, J); for(auto i : irange(I)) for(auto j : irange(J)) r(i, j) = (*this)(i, j); return r; }
    };

    class Shared3D : public SharedVector {
        using self_t = Shared3D;
        using base_t = SharedVector;
        size_t I, J, K;
        self_t(self_t const&) = delete; // copy constructor, disabled to avoid duplication of l-valued object
      public:
        self_t(size_t i = 0, size_t j = 0, size_t k = 0) : I(i), J(j), K(k), base_t(i * j * k) { }
        self_t(size_t i, size_t j, size_t k, val_t const* ptr) : I(i), J(j), K(k), base_t(i * j * k, ptr) { }
        self_t& operator=(self_t const& b) { I = b.I; J = b.J; K = b.K; base_t::operator=(b); return *this; } // Shared = Shared, shallow copy, must override the default copy assignment, use default copy assigment inherited from shared_ptr class
        self_t(self_t&& b) noexcept { operator=(std::move(b)); } // move constructor, shallow copy, needed by clone()
        self_t clone() const { return self_t(I, J, K, begin()); }
        size_t size(size_t d) const { return d < 1 ? I : (d < 2 ? J : K); }

        template<typename B> self_t operator+(B const& b) const { self_t a = clone(); a += b; return a; }
        template<typename B> self_t operator-(B const& b) const { self_t a = clone(); a -= b; return a; }
        val_t& operator()(size_t i, size_t j, size_t k) { return begin()[i + I * (j + k * J)]; }
        val_t const& operator()(size_t i, size_t j, size_t k) const { return begin()[i + I * (j + k * J)]; }

        auto x(size_t j, size_t k) { return Vector(begin() + I * (j + k * J), 1, I); }
        auto y(size_t i, size_t k) { return Vector(begin() + i + k * I * J, I, J); }
        auto z(size_t i, size_t j) { return Vector(begin() + i + j * I, I * J, K); }
        //auto x(size_t i) { return x(i / K, i % K); } // J * K
        //auto y(size_t j) { return y(j / K, j % K); } // I * K
        //auto z(size_t k) { return z(k / J, k % J); } // I * J
        auto xy(size_t k) { SharedMatrix r(I, J); for(auto i : irange(I)) for(auto j : irange(J)) r(i, j) = (*this)(i, j, k); return r; }
        auto xz(size_t j) { SharedMatrix r(I, K); for(auto i : irange(I)) for(auto k : irange(K)) r(i, k) = (*this)(i, j, k); return r; }
        auto yz(size_t i) { SharedMatrix r(J, K); for(auto j : irange(J)) for(auto k : irange(K)) r(j, k) = (*this)(i, j, k); return r; }
    };


#if 0
    /*---------------- Dynamic Multidimensional Array ----------------*/
    template<typename T, size_t DIM>
    class Array { // https://codereview.stackexchange.com/questions/127777/dynamic-multidimensional-arrays
        static_assert((DIM >= 1), "");
        T* ptr;
        size_t const dims[DIM]; // col major
        template<typename I> size_t index(I i) const { return i; } // base function (1D)
        template<typename I, typename J> size_t index(I i, J j) const { return i + dims[0] * j; } // 2D for efficiency
        template<typename I, typename J, typename K> size_t index(I i, J j, K k) const { return i + dims[0] * (j + dims[1] * k); } // 3D for efficiency
        template<typename FIRST, typename SECOND, typename... REST> size_t index(FIRST f, SECOND s, REST... rest) const { return f + dims[DIM - 2 - sizeof...(REST)] * index(s, rest...); } // 4D and above by recursion
      public:
        Array() : dims{} { ptr = nullptr;};
        template <typename... SIZE_T> explicit Array(SIZE_T... sizes) : dims{ size_t(sizes)... } { static_assert(sizeof...(SIZE_T) == DIM, ""); ptr = new T[size()]; }
        ~Array() { delete[] ptr; };
        void fill(T const & val) { std::fill(ptr, ptr + size(), val); }
        size_t size(size_t d = 999) const { return d < DIM ? dims[d] : std::accumulate(dims, dims + DIM, 1, std::multiplies<size_t>()); }
        template <typename... Indices> T& operator()(Indices... idcs) { return *(ptr + index(idcs...)); }
        template <typename... Indices> T const& operator()(Indices... idcs) const { return *(ptr + index(idcs...)); }

        T* begin() { return ptr; }
        T const* begin() const { return ptr; }
        T* end() { return ptr + size(); }
        T const* end() const { return ptr + size(); }
    };
#endif


    /*---------------- Sparse Matrix ----------------*/
    class SparseMatrix {
        using self_t = SparseMatrix;
        using base_t = gsl_spmatrix;
        using val_t = double;
        base_t* ptr;
        self_t(self_t const&) = delete; // copy constructor, disabled to avoid duplication of l-valued object
        self_t& operator=(self_t const&) = delete;
      public:
        self_t(size_t i = 0, size_t j = 0, size_t nz = 0) : ptr(gsl_spmatrix_alloc_nzmax(i, j, nz == 0 ? i * 10 : nz, GSL_SPMATRIX_TRIPLET)) {}
        self_t(self_t&& v) noexcept : ptr(v.ptr) { v.ptr = nullptr; } // move constructor, shallow copy
        ~SparseMatrix() { if(ptr != nullptr) gsl_spmatrix_free(ptr); }
        self_t clone() const { self_t r(size1(), size2()); gsl_spmatrix_memcpy(r.ptr, ptr); return r; }

        size_t size1() const { return ptr->size1; }
        size_t size2() const { return ptr->size2; }

        void set(size_t i, size_t j, val_t x) { gsl_spmatrix_set(ptr, i, j, x); }
        val_t get(size_t i, size_t j) { return gsl_spmatrix_get(ptr, i, j); }
        void add(size_t i, size_t j, val_t v) { set(i, j, get(i, j) + v); }

        //MatrixExpression<A> * VectorExpression<B> ==> SharedVector
        template<typename B> SharedVector operator*(VectorExpression<B> const& b) {
            assert(ptr->size2 == b.size());
            SharedVector x(ptr->size1);
            gsl_spblas_dgemv(CblasNoTrans, 1, ptr, &b.gsl(), 0, &x.gsl()); // y = a*op(A)*x + b*y
            return x;
        }

        void set_row_identity(size_t n) {
            for(size_t k = 0; k < ptr->nz; k++)
                if(ptr->i[k] == n)
                    ptr->data[k] = ptr->p[k] == n ? 1 : 0;
        }

        //solve the system A*x = b: SparseMatrix * SharedVector = VectorExpression<B>
        template<typename B> SharedVector solve_GSL(VectorExpression<B>& x, VectorExpression<B> const& b, size_t const max_iter, double const tol, size_t restart = 12) {
            assert(size1() == size2() && size2() == b.size() && x.size() == b.size());
            gsl_splinalg_itersolve* work = gsl_splinalg_itersolve_alloc(gsl_splinalg_itersolve_gmres, size2(), restart);/* solve with the GMRES iterative solver */
            int status = GSL_CONTINUE, iter = 0;
            for(; status == GSL_CONTINUE && iter < max_iter; iter++)
                status = gsl_splinalg_itersolve_iterate(ptr, &b.gsl(), tol, &x.gsl(), work); // residual norm ||A*x - b|| = gsl_splinalg_itersolve_normr(work);
            gsl_splinalg_itersolve_free(work);
            if(status != GSL_SUCCESS) THROW("iterative solver not converged");
            return x;
        }

        //solve the system A*x = b: SparseMatrix * SharedVector = VectorExpression<B>, http://www.netlib.org/templates/matlab/cgs.m
        template<typename B> SharedVector solve_CGS(VectorExpression<B>& x, VectorExpression<B> const& b, size_t max_iter, double const tol) {
            assert(size1() == size2() && size2() == b.size() && x.size() == b.size());
            val_t rho1, rho2;
            val_t b_norm = norm(b);
            SharedVector r = b - (*this) * x;
            SharedVector r0 = r.clone();
            SharedVector p, q, v, u;

            val_t beta = 0.0;
            for(int iter = 1; iter <= max_iter; iter++) {
                if(norm(r) / b_norm <= tol) return x;
                rho1 = r.dot(r0);

                if(iter == 1)   // direction vectors
                    p = u = r;
                else {
                    val_t beta = rho1 / rho2;
                    u = r + beta * q;
                    p = u + beta * (q + beta * p);
                }
                //p = M * p; //Preconditing
                v = (*this) * p; // adjusting scalars
                val_t alpha = rho1 / v.dot(r0);
                q = u - alpha * v;
                u = u + q; //u = M * (u + q); //Preconditing
                x += alpha * u; //update approximation
                r -= alpha * ((*this) * u);
                rho2 = rho1;
            }
            THROW("CGS not converged");
        }

        //solve the system A*x = b: SparseMatrix * SharedVector = VectorExpression<B>, http://www.netlib.org/templates/matlab/gmres.m and http://www.netlib.org/templates/matlab/rotmat.m
        template<typename B> SharedVector solve_GMRES(VectorExpression<B>& x, VectorExpression<B> const& b, size_t max_iter, val_t const tol, size_t restart = 10) {
            assert(size1() == size2() && size2() == b.size() && x.size() == b.size());
            auto givens_rotation = [](val_t c, val_t s, val_t & a, val_t & b) { auto t = c * a - s * b; b = s * a + c * b; a = t; };

            self_t M(size1(), size2()); // trivial preconditioner: https://en.wikipedia.org/wiki/Preconditioner
            for(size_t i = 0; i < size1(); i++)
                M.set(i, i, 1.0 / this->get(i, i)); //= diag(A)^-1

            size_t m = restart < size1() ? restart : size1();
            Matrix Vmat(m + 1, size1(), 0.0);
            Vector y(m + 1, 0.0);
            Vector cs(m, 0.0);
            Vector sn(m, 0.0);
            val_t b_norm = norm(b);
            for(int iter = 0; iter < max_iter; iter++) {   // outer iteration
                SharedVector r = M * (b - (*this) * x); // preconditioning: r = M \ (...)
                val_t r_norm = norm(r);
                if(r_norm / b_norm < tol) break;

                Vmat.row(0) = r / r_norm;
                Matrix Hmat(m + 1, m, 0.0); // reset to zeros
                Vector g(m + 1, 0.0); // reset to zeros
                g[0] = r_norm;

                int k = 0;
                for(; k < m; k++) {   //inner iteration
                    Vector v = Vmat.row(k + 1);
                    Vector h = Hmat.col(k);

                    v = M * ((*this) * Vmat.row(k)); // preconditioning: r = M \ (...)
                    for(int i = 0; i < k + 1; i++) {
                        Vector u = Vmat.row(i);
                        h[i] = v.dot(u);
                        v -= h[i] * u;
                    }
                    h[k + 1] = norm(v);
                    v /= h[k + 1];

                    for(int i = 0; i < k; i++)
                        givens_rotation(cs[i], sn[i], h[i], h[i + 1]);

                    val_t tmp = std::sqrt(h[k] * h[k] + h[k + 1] * h[k + 1]);
                    cs[k] = h[k] / tmp;
                    sn[k] = -h[k + 1] / tmp;
                    h[k] = tmp; //cs[k] * h[k] - sn[k] * h[k + 1];
                    h[k + 1] = 0;
                    givens_rotation(cs[k], sn[k], g[k], g[k + 1]);
                    if(fabs(g[k + 1]) / b_norm < tol) break;
                } // inner iteration

                k = k < m ? k : m - 1;
                y[k] = g[k] / Hmat(k, k);
                for(int i = k - 1; i >= 0; i--) {
                    y[i] = g[i];
                    for(int j = i + 1; j <= k; j++)
                        y[i] -= Hmat(i, j) * y[j];
                    y[i] /= Hmat(i, i);
                }
                for(int i = 0; i <= k; i++)
                    x += Vmat.row(i) * y[i];
            } // outer iteration
            return x;
        }
    };
};


