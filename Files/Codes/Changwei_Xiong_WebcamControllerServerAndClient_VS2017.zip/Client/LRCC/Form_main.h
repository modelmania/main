/*
*  Created on: Dec 12, 2008
*  Last modified on: Nov 18, 2009
*  Author: Changwei Xiong
*  
*  Copyright (C) 2009, Changwei Xiong, 
*  axcw@hotmail.com, <http://www.cs.utah.edu/~cxiong/>
*
*  Licence: Revised BSD License
*/


#pragma once
#include <string>

#define LIST_BOX ListBox_msg
#define LISTBOX(msg)															\
		{																		\
		LIST_BOX->Items->Add("["+(LIST_BOX->Items->Count+1)+"] "+(msg));	\
		if (LIST_BOX->Items->Count!=0){										\
		this->LIST_BOX->SetSelected(LIST_BOX->Items->Count - 1, true);	\
		this->LIST_BOX->SetSelected(LIST_BOX->Items->Count - 1, false);	\
		}																	\
		}


const int TIMER_INTERVAL = 400;

namespace LRCC {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	using namespace System::IO;
	using namespace System::Net;
	using namespace System::Net::Sockets;

	using std::string;

	typedef enum {
		NO_PTZ = 64,
		PT_RESET,
		Z_RESET,

		P_LEFT,
		P_RIGHT,
		T_UP,
		T_DOWN,

		P_LLEFT,
		P_RRIGHT,
		T_UUP,
		T_DDOWN,

		Z_IN,
		Z_OUT
	} PTZC;

	/// <summary>
	/// Summary for Form_main
	///
	/// WARNING: If you change the name of this class, you will need to change the
	///          'Resource File Name' property for the managed resource compiler tool
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public ref class Form_main : public System::Windows::Forms::Form
	{
	public:
		Form_main(void)
		{
			InitializeComponent();
			ListBox_msg->CheckForIllegalCrossThreadCalls = false;

			this->Button_ptreset->Tag = (int)PT_RESET;
			this->Button_zoomreset->Tag = (int)Z_RESET;

			this->Button_left->Tag = (int)P_LEFT;
			this->Button_right->Tag = (int)P_RIGHT;
			this->Button_up->Tag = (int)T_UP;
			this->Button_down->Tag = (int)T_DOWN;

			this->Button_lleft->Tag = (int)P_LLEFT;
			this->Button_rright->Tag = (int)P_RRIGHT;
			this->Button_uup->Tag = (int)T_UUP;
			this->Button_ddown->Tag = (int)T_DDOWN;

			this->Button_zoomin->Tag = (int)Z_IN;
			this->Button_zoomout->Tag = (int)Z_OUT;

			this->Timer_mousehold->Interval = TIMER_INTERVAL;

			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form_main()
		{
			if (components)
			{
				delete components;
			}
		}

	private: System::Windows::Forms::Label^  Label_IP;
	private: System::Windows::Forms::Label^  Label_port;
	private: System::Windows::Forms::TextBox^  TextBox_IP;
	private: System::Windows::Forms::TextBox^  TextBox_port;

	private: System::Windows::Forms::Button^  Button_connect;

	private: System::Windows::Forms::Button^  Button_ptreset;
	private: System::Windows::Forms::Button^  Button_left;
	private: System::Windows::Forms::Button^  Button_up;
	private: System::Windows::Forms::Button^  Button_right;
	private: System::Windows::Forms::Button^  Button_down;

	private: System::Windows::Forms::Button^  Button_ddown;
	private: System::Windows::Forms::Button^  Button_rright;
	private: System::Windows::Forms::Button^  Button_uup;
	private: System::Windows::Forms::Button^  Button_lleft;

	private: System::Windows::Forms::Button^  Button_zoomin;
	private: System::Windows::Forms::Button^  Button_zoomreset;
	private: System::Windows::Forms::Button^  Button_zoomout;

	private: System::Windows::Forms::Panel^  Panel_PTZ;	
	private: System::Windows::Forms::ListBox^  ListBox_msg;
	private: System::ComponentModel::IContainer^  components;


	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>

		TcpClient^ tcpclient;
		StreamWriter^ clientwriter;
	private: System::Windows::Forms::Timer^  Timer_mousehold;


			 StreamReader^ clientreader;
			 PTZC PTZ_cmd, PTZ_mousehold;


#pragma region Windows Form Designer generated code
			 /// <summary>
			 /// Required method for Designer support - do not modify
			 /// the contents of this method with the code editor.
			 /// </summary>
			 void InitializeComponent(void)
			 {
				 this->components = (gcnew System::ComponentModel::Container());
				 System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(Form_main::typeid));
				 this->Label_IP = (gcnew System::Windows::Forms::Label());
				 this->Label_port = (gcnew System::Windows::Forms::Label());
				 this->TextBox_IP = (gcnew System::Windows::Forms::TextBox());
				 this->TextBox_port = (gcnew System::Windows::Forms::TextBox());
				 this->Button_connect = (gcnew System::Windows::Forms::Button());
				 this->Button_left = (gcnew System::Windows::Forms::Button());
				 this->Button_up = (gcnew System::Windows::Forms::Button());
				 this->Button_right = (gcnew System::Windows::Forms::Button());
				 this->Button_down = (gcnew System::Windows::Forms::Button());
				 this->Button_ptreset = (gcnew System::Windows::Forms::Button());
				 this->Button_zoomin = (gcnew System::Windows::Forms::Button());
				 this->Button_zoomreset = (gcnew System::Windows::Forms::Button());
				 this->Button_zoomout = (gcnew System::Windows::Forms::Button());
				 this->Panel_PTZ = (gcnew System::Windows::Forms::Panel());
				 this->Button_ddown = (gcnew System::Windows::Forms::Button());
				 this->Button_rright = (gcnew System::Windows::Forms::Button());
				 this->Button_uup = (gcnew System::Windows::Forms::Button());
				 this->Button_lleft = (gcnew System::Windows::Forms::Button());
				 this->ListBox_msg = (gcnew System::Windows::Forms::ListBox());
				 this->Timer_mousehold = (gcnew System::Windows::Forms::Timer(this->components));
				 this->Panel_PTZ->SuspendLayout();
				 this->SuspendLayout();
				 // 
				 // Label_IP
				 // 
				 this->Label_IP->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
					 static_cast<System::Byte>(0)));
				 this->Label_IP->Location = System::Drawing::Point(16, 20);
				 this->Label_IP->Name = L"Label_IP";
				 this->Label_IP->Size = System::Drawing::Size(113, 25);
				 this->Label_IP->TabIndex = 2;
				 this->Label_IP->Text = L"Destination IP :";
				 this->Label_IP->TextAlign = System::Drawing::ContentAlignment::MiddleCenter;
				 // 
				 // Label_port
				 // 
				 this->Label_port->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
					 static_cast<System::Byte>(0)));
				 this->Label_port->Location = System::Drawing::Point(276, 20);
				 this->Label_port->Name = L"Label_port";
				 this->Label_port->Size = System::Drawing::Size(54, 25);
				 this->Label_port->TabIndex = 4;
				 this->Label_port->Text = L"Port :";
				 this->Label_port->TextAlign = System::Drawing::ContentAlignment::MiddleCenter;
				 // 
				 // TextBox_IP
				 // 
				 this->TextBox_IP->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
					 static_cast<System::Byte>(0)));
				 this->TextBox_IP->Location = System::Drawing::Point(131, 19);
				 this->TextBox_IP->Name = L"TextBox_IP";
				 this->TextBox_IP->Size = System::Drawing::Size(140, 22);
				 this->TextBox_IP->TabIndex = 1;
				 this->TextBox_IP->Text = L"192.168.1.1";
				 // 
				 // TextBox_port
				 // 
				 this->TextBox_port->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
					 static_cast<System::Byte>(0)));
				 this->TextBox_port->Location = System::Drawing::Point(331, 20);
				 this->TextBox_port->Name = L"TextBox_port";
				 this->TextBox_port->Size = System::Drawing::Size(70, 22);
				 this->TextBox_port->TabIndex = 3;
				 this->TextBox_port->Text = L"27920";
				 // 
				 // Button_connect
				 // 
				 this->Button_connect->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
					 static_cast<System::Byte>(0)));
				 this->Button_connect->Location = System::Drawing::Point(414, 18);
				 this->Button_connect->Name = L"Button_connect";
				 this->Button_connect->Size = System::Drawing::Size(100, 25);
				 this->Button_connect->TabIndex = 5;
				 this->Button_connect->Text = L"Connect";
				 this->Button_connect->UseVisualStyleBackColor = true;
				 this->Button_connect->Click += gcnew System::EventHandler(this, &Form_main::button_connect_Click);
				 // 
				 // Button_left
				 // 
				 this->Button_left->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
					 static_cast<System::Byte>(0)));
				 this->Button_left->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"Button_left.Image")));
				 this->Button_left->Location = System::Drawing::Point(45, 85);
				 this->Button_left->Name = L"Button_left";
				 this->Button_left->Size = System::Drawing::Size(30, 50);
				 this->Button_left->TabIndex = 0;
				 this->Button_left->UseVisualStyleBackColor = true;
				 this->Button_left->Click += gcnew System::EventHandler(this, &Form_main::PNZ_button_Click);
				 this->Button_left->MouseDown += gcnew System::Windows::Forms::MouseEventHandler(this, &Form_main::Button_MouseDown);
				 this->Button_left->MouseUp += gcnew System::Windows::Forms::MouseEventHandler(this, &Form_main::Button_MouseUp);
				 // 
				 // Button_up
				 // 
				 this->Button_up->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
					 static_cast<System::Byte>(0)));
				 this->Button_up->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"Button_up.Image")));
				 this->Button_up->Location = System::Drawing::Point(80, 50);
				 this->Button_up->Name = L"Button_up";
				 this->Button_up->Size = System::Drawing::Size(50, 30);
				 this->Button_up->TabIndex = 6;
				 this->Button_up->UseVisualStyleBackColor = true;
				 this->Button_up->Click += gcnew System::EventHandler(this, &Form_main::PNZ_button_Click);
				 this->Button_up->MouseDown += gcnew System::Windows::Forms::MouseEventHandler(this, &Form_main::Button_MouseDown);
				 this->Button_up->MouseUp += gcnew System::Windows::Forms::MouseEventHandler(this, &Form_main::Button_MouseUp);
				 // 
				 // Button_right
				 // 
				 this->Button_right->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
					 static_cast<System::Byte>(0)));
				 this->Button_right->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"Button_right.Image")));
				 this->Button_right->Location = System::Drawing::Point(135, 85);
				 this->Button_right->Name = L"Button_right";
				 this->Button_right->Size = System::Drawing::Size(30, 50);
				 this->Button_right->TabIndex = 7;
				 this->Button_right->UseVisualStyleBackColor = true;
				 this->Button_right->Click += gcnew System::EventHandler(this, &Form_main::PNZ_button_Click);
				 this->Button_right->MouseDown += gcnew System::Windows::Forms::MouseEventHandler(this, &Form_main::Button_MouseDown);
				 this->Button_right->MouseUp += gcnew System::Windows::Forms::MouseEventHandler(this, &Form_main::Button_MouseUp);
				 // 
				 // Button_down
				 // 
				 this->Button_down->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
					 static_cast<System::Byte>(0)));
				 this->Button_down->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"Button_down.Image")));
				 this->Button_down->Location = System::Drawing::Point(80, 140);
				 this->Button_down->Name = L"Button_down";
				 this->Button_down->Size = System::Drawing::Size(50, 30);
				 this->Button_down->TabIndex = 8;
				 this->Button_down->UseVisualStyleBackColor = true;
				 this->Button_down->Click += gcnew System::EventHandler(this, &Form_main::PNZ_button_Click);
				 this->Button_down->MouseDown += gcnew System::Windows::Forms::MouseEventHandler(this, &Form_main::Button_MouseDown);
				 this->Button_down->MouseUp += gcnew System::Windows::Forms::MouseEventHandler(this, &Form_main::Button_MouseUp);
				 // 
				 // Button_ptreset
				 // 
				 this->Button_ptreset->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
					 static_cast<System::Byte>(0)));
				 this->Button_ptreset->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"Button_ptreset.Image")));
				 this->Button_ptreset->Location = System::Drawing::Point(80, 85);
				 this->Button_ptreset->Name = L"Button_ptreset";
				 this->Button_ptreset->Size = System::Drawing::Size(50, 50);
				 this->Button_ptreset->TabIndex = 9;
				 this->Button_ptreset->UseVisualStyleBackColor = true;
				 this->Button_ptreset->Click += gcnew System::EventHandler(this, &Form_main::PNZ_button_Click);
				 // 
				 // Button_zoomin
				 // 
				 this->Button_zoomin->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
					 static_cast<System::Byte>(0)));
				 this->Button_zoomin->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"Button_zoomin.Image")));
				 this->Button_zoomin->Location = System::Drawing::Point(220, 19);
				 this->Button_zoomin->Name = L"Button_zoomin";
				 this->Button_zoomin->Size = System::Drawing::Size(50, 50);
				 this->Button_zoomin->TabIndex = 10;
				 this->Button_zoomin->UseVisualStyleBackColor = true;
				 this->Button_zoomin->Click += gcnew System::EventHandler(this, &Form_main::PNZ_button_Click);
				 this->Button_zoomin->MouseDown += gcnew System::Windows::Forms::MouseEventHandler(this, &Form_main::Button_MouseDown);
				 this->Button_zoomin->MouseUp += gcnew System::Windows::Forms::MouseEventHandler(this, &Form_main::Button_MouseUp);
				 // 
				 // Button_zoomreset
				 // 
				 this->Button_zoomreset->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, 
					 System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
				 this->Button_zoomreset->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"Button_zoomreset.Image")));
				 this->Button_zoomreset->Location = System::Drawing::Point(220, 85);
				 this->Button_zoomreset->Name = L"Button_zoomreset";
				 this->Button_zoomreset->Size = System::Drawing::Size(50, 50);
				 this->Button_zoomreset->TabIndex = 11;
				 this->Button_zoomreset->UseVisualStyleBackColor = true;
				 this->Button_zoomreset->Click += gcnew System::EventHandler(this, &Form_main::PNZ_button_Click);
				 // 
				 // Button_zoomout
				 // 
				 this->Button_zoomout->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
					 static_cast<System::Byte>(0)));
				 this->Button_zoomout->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"Button_zoomout.Image")));
				 this->Button_zoomout->Location = System::Drawing::Point(220, 151);
				 this->Button_zoomout->Name = L"Button_zoomout";
				 this->Button_zoomout->Size = System::Drawing::Size(50, 50);
				 this->Button_zoomout->TabIndex = 12;
				 this->Button_zoomout->UseVisualStyleBackColor = true;
				 this->Button_zoomout->Click += gcnew System::EventHandler(this, &Form_main::PNZ_button_Click);
				 this->Button_zoomout->MouseDown += gcnew System::Windows::Forms::MouseEventHandler(this, &Form_main::Button_MouseDown);
				 this->Button_zoomout->MouseUp += gcnew System::Windows::Forms::MouseEventHandler(this, &Form_main::Button_MouseUp);
				 // 
				 // Panel_PTZ
				 // 
				 this->Panel_PTZ->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
				 this->Panel_PTZ->Controls->Add(this->Button_ddown);
				 this->Panel_PTZ->Controls->Add(this->Button_rright);
				 this->Panel_PTZ->Controls->Add(this->Button_uup);
				 this->Panel_PTZ->Controls->Add(this->Button_lleft);
				 this->Panel_PTZ->Controls->Add(this->Button_zoomout);
				 this->Panel_PTZ->Controls->Add(this->Button_zoomreset);
				 this->Panel_PTZ->Controls->Add(this->Button_zoomin);
				 this->Panel_PTZ->Controls->Add(this->Button_ptreset);
				 this->Panel_PTZ->Controls->Add(this->Button_down);
				 this->Panel_PTZ->Controls->Add(this->Button_right);
				 this->Panel_PTZ->Controls->Add(this->Button_up);
				 this->Panel_PTZ->Controls->Add(this->Button_left);
				 this->Panel_PTZ->Enabled = false;
				 this->Panel_PTZ->Location = System::Drawing::Point(230, 65);
				 this->Panel_PTZ->Name = L"Panel_PTZ";
				 this->Panel_PTZ->Size = System::Drawing::Size(285, 225);
				 this->Panel_PTZ->TabIndex = 13;
				 // 
				 // Button_ddown
				 // 
				 this->Button_ddown->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
					 static_cast<System::Byte>(0)));
				 this->Button_ddown->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"Button_ddown.Image")));
				 this->Button_ddown->Location = System::Drawing::Point(80, 175);
				 this->Button_ddown->Name = L"Button_ddown";
				 this->Button_ddown->Size = System::Drawing::Size(50, 30);
				 this->Button_ddown->TabIndex = 16;
				 this->Button_ddown->UseVisualStyleBackColor = true;
				 this->Button_ddown->Click += gcnew System::EventHandler(this, &Form_main::PNZ_button_Click);
				 this->Button_ddown->MouseDown += gcnew System::Windows::Forms::MouseEventHandler(this, &Form_main::Button_MouseDown);
				 this->Button_ddown->MouseUp += gcnew System::Windows::Forms::MouseEventHandler(this, &Form_main::Button_MouseUp);
				 // 
				 // Button_rright
				 // 
				 this->Button_rright->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
					 static_cast<System::Byte>(0)));
				 this->Button_rright->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"Button_rright.Image")));
				 this->Button_rright->Location = System::Drawing::Point(170, 85);
				 this->Button_rright->Name = L"Button_rright";
				 this->Button_rright->Size = System::Drawing::Size(30, 50);
				 this->Button_rright->TabIndex = 15;
				 this->Button_rright->UseVisualStyleBackColor = true;
				 this->Button_rright->Click += gcnew System::EventHandler(this, &Form_main::PNZ_button_Click);
				 this->Button_rright->MouseDown += gcnew System::Windows::Forms::MouseEventHandler(this, &Form_main::Button_MouseDown);
				 this->Button_rright->MouseUp += gcnew System::Windows::Forms::MouseEventHandler(this, &Form_main::Button_MouseUp);
				 // 
				 // Button_uup
				 // 
				 this->Button_uup->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
					 static_cast<System::Byte>(0)));
				 this->Button_uup->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"Button_uup.Image")));
				 this->Button_uup->Location = System::Drawing::Point(80, 15);
				 this->Button_uup->Name = L"Button_uup";
				 this->Button_uup->Size = System::Drawing::Size(50, 30);
				 this->Button_uup->TabIndex = 14;
				 this->Button_uup->UseVisualStyleBackColor = true;
				 this->Button_uup->Click += gcnew System::EventHandler(this, &Form_main::PNZ_button_Click);
				 this->Button_uup->MouseDown += gcnew System::Windows::Forms::MouseEventHandler(this, &Form_main::Button_MouseDown);
				 this->Button_uup->MouseUp += gcnew System::Windows::Forms::MouseEventHandler(this, &Form_main::Button_MouseUp);
				 // 
				 // Button_lleft
				 // 
				 this->Button_lleft->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
					 static_cast<System::Byte>(0)));
				 this->Button_lleft->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"Button_lleft.Image")));
				 this->Button_lleft->Location = System::Drawing::Point(10, 85);
				 this->Button_lleft->Name = L"Button_lleft";
				 this->Button_lleft->Size = System::Drawing::Size(30, 50);
				 this->Button_lleft->TabIndex = 13;
				 this->Button_lleft->UseVisualStyleBackColor = true;
				 this->Button_lleft->Click += gcnew System::EventHandler(this, &Form_main::PNZ_button_Click);
				 this->Button_lleft->MouseDown += gcnew System::Windows::Forms::MouseEventHandler(this, &Form_main::Button_MouseDown);
				 this->Button_lleft->MouseUp += gcnew System::Windows::Forms::MouseEventHandler(this, &Form_main::Button_MouseUp);
				 // 
				 // ListBox_msg
				 // 
				 this->ListBox_msg->FormattingEnabled = true;
				 this->ListBox_msg->HorizontalScrollbar = true;
				 this->ListBox_msg->Location = System::Drawing::Point(15, 65);
				 this->ListBox_msg->Name = L"ListBox_msg";
				 this->ListBox_msg->SelectionMode = System::Windows::Forms::SelectionMode::MultiExtended;
				 this->ListBox_msg->Size = System::Drawing::Size(200, 225);
				 this->ListBox_msg->TabIndex = 14;
				 // 
				 // Timer_mousehold
				 // 
				 this->Timer_mousehold->Tick += gcnew System::EventHandler(this, &Form_main::Timer_mousehold_Tick);
				 // 
				 // Form_main
				 // 
				 this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
				 this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
				 this->ClientSize = System::Drawing::Size(532, 303);
				 this->Controls->Add(this->ListBox_msg);
				 this->Controls->Add(this->Panel_PTZ);
				 this->Controls->Add(this->Button_connect);
				 this->Controls->Add(this->Label_port);
				 this->Controls->Add(this->TextBox_port);
				 this->Controls->Add(this->Label_IP);
				 this->Controls->Add(this->TextBox_IP);
				 this->MaximizeBox = false;
				 this->MaximumSize = System::Drawing::Size(540, 330);
				 this->MinimumSize = System::Drawing::Size(540, 330);
				 this->Name = L"Form_main";
				 this->Text = L"LogiCam Remote Control Client 1.0";
				 this->Panel_PTZ->ResumeLayout(false);
				 this->ResumeLayout(false);
				 this->PerformLayout();

			 }
#pragma endregion


			 //************************ IMPLEMENTATION ********************************************* 
	private: std::string Form_main::ConvertToString(System::String^ str){ 
				 int q=(int)System::Runtime::InteropServices::Marshal::StringToHGlobalAnsi(str);
				 char* p=(char*)q;
				 return std::string(p);
			 }

	private: int send_cmd(int cmd){
				 try{
					 clientwriter->WriteLine((wchar_t)cmd);
					 clientwriter->Flush();
					 //tmp = clientreader->ReadLine();
				 }
				 catch (...){
					 // connection lost
				 }
				 return cmd;
			 }


	private: System::Void button_connect_Click(System::Object^  sender, System::EventArgs^  e){
				 if(this->Button_connect->Text == L"Connect"){
					 try{
						 tcpclient = gcnew TcpClient(TextBox_IP->Text, Convert::ToInt32(TextBox_port->Text));
						 clientwriter = gcnew StreamWriter(tcpclient->GetStream()); 
						 //clientreader = gcnew StreamReader(tcpclient->GetStream());
					 }
					 catch (SocketException^ se){
						 LISTBOX("Connection to server failed with error \"" + se->Message +"\"");
						 return;
					 }
					 LISTBOX("Successfully Connected to \"" + TextBox_IP->Text +"\"" );
					 this->Panel_PTZ->Enabled = true;
					 this->Button_connect->Text = L"Disconnect";
				 }
				 else if(this->Button_connect->Text == L"Disconnect"){
					 Timer_mousehold->Stop();
					 clientwriter->Close();
					 tcpclient->Close();
					 LISTBOX("Disconnected");
					 this->Panel_PTZ->Enabled = false;
					 this->Button_connect->Text = L"Connect";
				 }
			 }

	private: System::Void PNZ_button_Click(System::Object^  sender, System::EventArgs^  e) {
				 int cmd  = Convert::ToInt32(((System::Windows::Forms::Button^) sender)->Tag);
				 if(cmd<PT_RESET || cmd>Z_OUT){
					 LISTBOX("Invalid Signal: " + cmd);
					 return;
				 }
				 LISTBOX("Signal: " + (wchar_t)send_cmd(cmd));
			 }

	private: System::Void Button_MouseDown(System::Object^  sender, System::Windows::Forms::MouseEventArgs^  e) {
				 int mouse_down  = Convert::ToInt32(((System::Windows::Forms::Button^) sender)->Tag);
				 if(mouse_down>=P_LEFT || mouse_down<=Z_OUT){
					 PTZ_mousehold = (LRCC::PTZC) mouse_down;
					 Timer_mousehold->Start();
					 return;
				 }
				 PTZ_mousehold = NO_PTZ;
			 }

	private: System::Void Button_MouseUp(System::Object^  sender, System::Windows::Forms::MouseEventArgs^  e) {
				 int mouse_up  = Convert::ToInt32(((System::Windows::Forms::Button^) sender)->Tag);
				 if(mouse_up>=P_LEFT || mouse_up<=Z_OUT){
					 PTZ_mousehold = NO_PTZ;
					 Timer_mousehold->Stop();
				 }
			 }

	private: System::Void Timer_mousehold_Tick(System::Object^  sender, System::EventArgs^  e) {
				 LISTBOX("Signal: " + (wchar_t)send_cmd(PTZ_mousehold));
			 }

	};
}