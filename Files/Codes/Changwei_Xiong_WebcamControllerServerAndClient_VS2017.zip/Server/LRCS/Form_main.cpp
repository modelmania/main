/*
*  Created on: Dec 12, 2008
*  Last modified on: Nov 18, 2009
*  Author: Changwei Xiong
*  
*  Copyright (C) 2009, Changwei Xiong, 
*  axcw@hotmail.com, <http://www.cs.utah.edu/~cxiong/>
*
*  Licence: Revised BSD License
*/

#include "stdafx.h"
#include "Form_main.h"

using namespace LRCS;
#pragma comment(lib, "strmiids.lib")


std::string LRCS::Form_main::ConvertToString(System::String^ str){ 
	int q=(int)System::Runtime::InteropServices::Marshal::StringToHGlobalAnsi(str);
	return std::string((char*)q);
}


void LRCS::Form_main::AcceptCB(IAsyncResult^ iar)	{							  
	TcpListener^ tcpListener = (TcpListener^)iar->AsyncState;
	Socket^ clientsocket;
	try{
		clientsocket = tcpListener->EndAcceptSocket(iar);
	}
	catch(ObjectDisposedException^){ 
		return;
	}

	IPEndPoint^ clientEP = (IPEndPoint^)clientsocket->RemoteEndPoint;
	LISTBOX("Connected on remote IP: " + clientEP->Address + " Port: " + clientEP->Port);

	// Send socket successful connection message
	//array<unsigned char>^ msg = 
	//	Encoding::ASCII->GetBytes(String::Format("Successfully connection to the server"));
	//clientsocket->BeginSend(msg, 0, msg->Length, SocketFlags::None,	  
	//	gcnew AsyncCallback(this, &LRCS::Form_main::SendCB), clientsocket);


	// Get message from client
	StateObject^ so = gcnew StateObject(clientsocket, BUF_SIZE);
	clientsocket->BeginReceive(so->message, 0, so->bufSize, 
		SocketFlags::None, gcnew AsyncCallback(this, &LRCS::Form_main::ReceiveCB), so);

	// Get the next socket connection
	//Console::WriteLine("Waiting for client connections. [Return to Exit]");
	tcpListener->BeginAcceptSocket(gcnew AsyncCallback(this, &LRCS::Form_main::AcceptCB), 
		tcpListener);
}



void LRCS::Form_main::SendCB(IAsyncResult^ iar){
	Socket^ clientsocket = (Socket^)iar->AsyncState;
	try{
		clientsocket->EndSend(iar);
	}
	catch(SocketException^ se){
		LISTBOX("Connection (send) failed with \"" + se->Message +"\"");
	}  
}


void LRCS::Form_main::ReceiveCB(IAsyncResult^ iar){
	StateObject^ so = (StateObject^)iar->AsyncState;
	Socket^ clientsocket = so->workSocket;

	IPEndPoint^ clientEP = (IPEndPoint^)clientsocket->RemoteEndPoint;
	IPEndPoint^ serverEP = (IPEndPoint^)clientsocket->LocalEndPoint;

	int rcv;
	try{
		rcv = clientsocket->EndReceive(iar);
	}
	catch(System::Net::Sockets::SocketException^ se){
		LISTBOX("Connection (recv) failed with \"" + se->Message + "\"");
	}

	if (rcv == 3) {//message consists of 3 characters: 1.signal, 2.carriage return, 3.newline	
		//LISTBOX("Addr.["+ serverEP->Address +"] Port[" + serverEP->Port + "] ");// + Encoding::ASCII->GetString(so->message, 0, rcv));
		int msg = so->message[0];
		if(msg >= NO_PTZ && msg <= Z_OUT){//valid signal
			//Control Webcam Function goes here
			WC_Control(msg);
		}else{
			LISTBOX("Invalid Signal: " + so->message);
		}
		// echo message
		try{
			clientsocket->BeginSend(so->message, 0, rcv, SocketFlags::None, 
				gcnew AsyncCallback(this, &LRCS::Form_main::SendCB), clientsocket);
		}
		catch(System::ArgumentOutOfRangeException^ ae){
			LISTBOX("Connection (recv) failed with \"" + ae->Message + "\"");
		}
		// set up for next receive
		so = gcnew StateObject(clientsocket, 8);
		try{
			clientsocket->BeginReceive(so->message, 0, so->bufSize, SocketFlags::None, 
				gcnew AsyncCallback(this, &LRCS::Form_main::ReceiveCB), so); 
		}
		catch(System::Net::Sockets::SocketException^ se){
			LISTBOX("Connection (recv) failed with \"" + se->Message + "\"");
		}
	}
	else{
		clientsocket->Close();
	}
}


void LRCS::Form_main::WC_Control(int cmd){
	static int ZOOM = 50;
	if(pCameraControl == NULL){
		LISTBOX("Signal Received: " + (wchar_t)cmd + "; Error: Webcam Not Detected");
		return;
	}
	LISTBOX("Signal Received: " + (wchar_t)cmd);

	switch (cmd){
		case NO_PTZ:
			break;
		case P_LEFT  :
			set_mechanical_pan_relative( LRCS::pCameraControl, -PT_SMALL_STEP );
			break;
		case P_RIGHT :
			set_mechanical_pan_relative( LRCS::pCameraControl,  PT_SMALL_STEP );
			break;
		case T_UP    :
			set_mechanical_tilt_relative( LRCS::pCameraControl, -PT_SMALL_STEP );
			break;
		case T_DOWN  :
			set_mechanical_tilt_relative( LRCS::pCameraControl,  PT_SMALL_STEP );
			break;
		case P_LLEFT  :
			set_mechanical_pan_relative( LRCS::pCameraControl, -PT_LARGE_STEP );
			break;
		case P_RRIGHT :
			set_mechanical_pan_relative( LRCS::pCameraControl,  PT_LARGE_STEP );
			break;
		case T_UUP    :
			set_mechanical_tilt_relative( LRCS::pCameraControl, -PT_LARGE_STEP );
			break;
		case T_DDOWN  :
			set_mechanical_tilt_relative( LRCS::pCameraControl,  PT_LARGE_STEP );
			break;	
		case Z_IN    :
			set_digital_zoom_absolute( LRCS::pCameraControl, ZOOM += ZOOM_STEP );
			break;
		case Z_OUT   :
			set_digital_zoom_absolute( LRCS::pCameraControl, ZOOM -= ZOOM_STEP );
			break;
		case PT_RESET :
			reset_machanical_pan_tilt( LRCS::pCameraControl );
			break;
		case Z_RESET :
			reset_digital_zoom(LRCS::pCameraControl);
			ZOOM = 50;
			break;
	}
}


int LRCS::Form_main::WC_Startup(){
	CoInitializeEx(NULL, COINIT_APARTMENTTHREADED);

	HRESULT hr;

	LISTBOX("Enumerating video input devices ...");

	// Create the System Device Enumerator.
	ICreateDevEnum *pSysDevEnum = NULL;
	hr = CoCreateInstance(CLSID_SystemDeviceEnum, NULL, CLSCTX_INPROC_SERVER,
		IID_ICreateDevEnum, (void **)&pSysDevEnum);
	if(FAILED(hr)) {
		LISTBOX("ERROR: Unable to create system device enumerator");
		return hr;
	}

	// Obtain a class enumerator for the video input device category.
	IEnumMoniker *pEnumCat = NULL;
	hr = pSysDevEnum->CreateClassEnumerator(CLSID_VideoInputDeviceCategory, &pEnumCat, 0);

	if(hr == S_OK){
		// Enumerate the monikers.
		IMoniker *pMoniker = NULL;
		ULONG cFetched;
		while(pEnumCat->Next(1, &pMoniker, &cFetched) == S_OK){
			IPropertyBag *pPropBag;
			IBaseFilter* pWebcamFilter = NULL;

			hr = pMoniker->BindToStorage(0, 0, IID_IPropertyBag, (void **)&pPropBag);
			if(SUCCEEDED(hr)){//1st if
				// To retrieve the filter's friendly name, do the following:
				VARIANT varName;
				VariantInit(&varName);
				hr = pPropBag->Read(L"FriendlyName", &varName, 0);

				if (SUCCEEDED(hr) && (gcnew String(varName.bstrVal)) == L"QuickCam Orbit/Sphere AF"){// 2nd if 
					// Display the name in your UI somehow.
					LISTBOX(L"Found device: " + (gcnew System::String(varName.bstrVal)));
					// To create an instance of the filter, do the following:
					hr = pMoniker->BindToObject(NULL, NULL, IID_IBaseFilter, (void**)(&pWebcamFilter));

					// Get a pointer to the IAMCameraControl interface used to control the camera
					hr = pWebcamFilter->QueryInterface(IID_IAMCameraControl, (void **)&LRCS::pCameraControl);
					if(hr != S_OK){
						LISTBOX("ERROR: Unable to access IAMCameraControl interface");
						return hr;
					}
				}//end 2nd if
				else {
					LISTBOX("Error: \"QuickCam Orbit/Sphere AF\" Not Detected");
				}
				VariantClear(&varName);
				//Remember to release pFilter later.
				pPropBag->Release();
			}// end 1st if
			pMoniker->Release();

			if(pWebcamFilter != NULL){
				pWebcamFilter->Release();
				break;
			}

		}// end while
		pEnumCat->Release();
	}//end if
	pSysDevEnum->Release();

	return 0; 
} 


void LRCS::Form_main::WC_Shutdown(){
	CoUninitialize();
}