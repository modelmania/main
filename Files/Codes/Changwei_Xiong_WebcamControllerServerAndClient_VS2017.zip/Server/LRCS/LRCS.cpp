/*
*  Created on: Dec 12, 2008
*  Last modified on: Nov 18, 2009
*  Author: Changwei Xiong
*  
*  Copyright (C) 2009, Changwei Xiong, 
*  axcw@hotmail.com, <http://www.cs.utah.edu/~cxiong/>
*
*  Licence: Revised BSD License
*/

// LRCS.cpp : main project file.
#pragma once
#include "stdafx.h"
#include "Form_main.h"

using namespace LRCS;

[STAThreadAttribute]
int main(array<System::String ^> ^args)
{

	// Enabling Windows XP visual effects before any controls are created
	Application::EnableVisualStyles();
	Application::SetCompatibleTextRenderingDefault(false); 

	// Create the main window and run it
	Application::Run(gcnew Form_main());
	return 0;

	//
	//void main(){
	//    TcpListener^ listener = gcnew TcpListener(IPAddress::Any, 777);
	//    listener->Start();
	//
	//    Console::WriteLine("Waiting for client connections. [Return to Exit]");
	//    listener->BeginAcceptSocket(gcnew AsyncCallback(&TcpServer::AcceptCB), 
	//        listener);
	//
	//    // Exit on return key
	//    Console::ReadLine();
	//}
	//
}


