#include "stdafx.h"
#include "PTZ.h"

#pragma comment(lib, "strmiids.lib")


/*
* Pans the camera by a given angle.
*
* The angle is given in degrees, positive values are clockwise rotation (seen from the top),
* negative values are counter-clockwise rotation. If the "Mirror horizontal" option is
* enabled, the panning sense is reversed.
*/
HRESULT PTZ::set_mechanical_pan_relative(IAMCameraControl *pCameraControl, long value){
	HRESULT hr = 0;
	long flags = KSPROPERTY_CAMERACONTROL_FLAGS_RELATIVE | KSPROPERTY_CAMERACONTROL_FLAGS_MANUAL;

	hr = pCameraControl->Set(CameraControl_Pan, value, flags);
	if(hr != S_OK)
		fprintf(stderr, "ERROR: Unable to set CameraControl_Pan property value to %d. (Error 0x%08X)\n", value, hr);

	// Note that we need to wait until the movement is complete, otherwise the next request will
	// fail with hr == 0x800700AA == HRESULT_FROM_WIN32(ERROR_BUSY).
	Sleep(500);

	return hr;
}


/*
* Tilts the camera by a given angle.
*
* The angle is given in degrees, positive values are downwards, negative values are upwards.
* If the "Mirror vertical" option is enabled, the tilting sense is reversed.
*/
HRESULT PTZ::set_mechanical_tilt_relative(IAMCameraControl *pCameraControl, long value){
	HRESULT hr = 0;
	long flags = KSPROPERTY_CAMERACONTROL_FLAGS_RELATIVE | KSPROPERTY_CAMERACONTROL_FLAGS_MANUAL;

	hr = pCameraControl->Set(CameraControl_Tilt, value, flags);
	if(hr != S_OK)
		fprintf(stderr, "ERROR: Unable to set CameraControl_Tilt property value to %d. (Error 0x%08X)\n", value, hr);

	// Note that we need to wait until the movement is complete, otherwise the next request will
	// fail with hr == 0x800700AA == HRESULT_FROM_WIN32(ERROR_BUSY).
	Sleep(500);

	return hr;
}


/*
* Resets the camera's pan/tilt position by moving into a corner and then back to the center.
*/
void PTZ::reset_machanical_pan_tilt(IAMCameraControl *pCameraControl){
	set_mechanical_pan_relative(pCameraControl, 180);
	Sleep(500);
	set_mechanical_tilt_relative(pCameraControl, 180);
	Sleep(500);
	set_mechanical_pan_relative(pCameraControl, -64);
	Sleep(500);
	set_mechanical_tilt_relative(pCameraControl, -24);
	Sleep(500);
}


/*
* Sets the digital pan angle.
*
* Positive values pan to the right, negative values pan to the left. Note that the digital pan
* angle only has an influence if the digital zoom is active.
*/
HRESULT PTZ::set_digital_pan_absolute(IAMCameraControl *pCameraControl, long value){
	HRESULT hr = 0;

	// Specifying the KSPROPERTY_CAMERACONTROL_FLAGS_ABSOLUTE flag instructs the driver
	// to use digital instead of mechanical pan.
	long flags = KSPROPERTY_CAMERACONTROL_FLAGS_ABSOLUTE | KSPROPERTY_CAMERACONTROL_FLAGS_MANUAL;

	hr = pCameraControl->Set(CameraControl_Pan, value, flags);
	if(hr != S_OK)
		fprintf(stderr, "ERROR: Unable to set CameraControl_Pan property value to %d. (Error 0x%08X)\n", value, hr);

	return hr;
}


/*
* Sets the digital tilt angle.
*
* Positive values tilt downwards, negative values tilt upwards. Note that the digital pan
* angle only has an influence if the digital zoom is active.
*/
HRESULT PTZ::set_digital_tilt_absolute(IAMCameraControl *pCameraControl, long value){
	HRESULT hr = 0;

	// Specifying the KSPROPERTY_CAMERACONTROL_FLAGS_ABSOLUTE flag instructs the driver
	// to use digital instead of mechanical tilt.
	long flags = KSPROPERTY_CAMERACONTROL_FLAGS_ABSOLUTE | KSPROPERTY_CAMERACONTROL_FLAGS_MANUAL;

	hr = pCameraControl->Set(CameraControl_Tilt, value, flags);
	if(hr != S_OK)
		fprintf(stderr, "ERROR: Unable to set CameraControl_Tilt property value to %d. (Error 0x%08X)\n", value, hr);

	return hr;
}


/*
* Sets the digital zoom value.
*
* The minimum value is 50 and means no zoom (100%). The maximum value is 200
* and means 4x zoom (400%).
*/
HRESULT PTZ::set_digital_zoom_absolute(IAMCameraControl *pCameraControl, long value){
	HRESULT hr = 0;
	long flags = KSPROPERTY_CAMERACONTROL_FLAGS_ABSOLUTE | KSPROPERTY_CAMERACONTROL_FLAGS_MANUAL;

	hr = pCameraControl->Set(CameraControl_Zoom, value, flags);
	if(hr != S_OK)
		fprintf(stderr, "ERROR: Unable to set CameraControl_Zoom property value to %d. (Error 0x%08X)\n", value, hr);

	return hr;
}


/*
* Resets the digital pan and tilt angles.
*/
void PTZ::reset_digital_pan_tilt(IAMCameraControl *pCameraControl){
	set_digital_pan_absolute(pCameraControl, 0);
	set_digital_tilt_absolute(pCameraControl, 0);
}


/*
* Resets the digital zoom.
*/
void PTZ::reset_digital_zoom(IAMCameraControl *pCameraControl){
	set_digital_zoom_absolute(pCameraControl, 50);
}
