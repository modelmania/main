/*
*  Created on: Dec 12, 2008
*  Last modified on: Nov 18, 2009
*  Author: Changwei Xiong
*  
*  Copyright (C) 2009, Changwei Xiong, 
*  axcw@hotmail.com, <http://www.cs.utah.edu/~cxiong/>
*
*  Licence: Revised BSD License
*/

#include <string>
#include "PTZ.h"

#define LIST_BOX ListBox_msg
#define LISTBOX(msg)																	\
		{																				\
		LIST_BOX->Items->Add("["+(LIST_BOX->Items->Count+1)+"] "+(msg));	\
		if (LIST_BOX->Items->Count!=0){											\
		this->LIST_BOX->SetSelected(LIST_BOX->Items->Count - 1, true);	\
		this->LIST_BOX->SetSelected(LIST_BOX->Items->Count - 1, false);	\
		}																			\
		}



const int TCP_PORT = 27920;
const int PT_SMALL_STEP  = 5;
const int PT_LARGE_STEP = 20;
const int ZOOM_STEP = 20;
const int BUF_SIZE = 64;

typedef enum {
	NO_PTZ = 64,
	PT_RESET,
	Z_RESET,

	P_LEFT,
	P_RIGHT,
	T_UP,
	T_DOWN,

	P_LLEFT,
	P_RRIGHT,
	T_UUP,
	T_DDOWN,

	Z_IN,
	Z_OUT
} PTZC;



namespace LRCS {

	//Windows Forms
	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	//TCP_Server
	//using namespace System;
	using namespace System::Net;
	using namespace System::Net::Sockets;
	using namespace System::Threading;
	using namespace System::Text;

	using std::string;

	using namespace PTZ;
	//using namespace TCPS;

	//TCP_Server Classes
	static IAMCameraControl *pCameraControl = NULL;

	/// <summary>
	/// Summary for Form_main
	///
	/// WARNING: If you change the name of this class, you will need to change the
	///          'Resource File Name' property for the managed resource compiler tool
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public ref class Form_main : public System::Windows::Forms::Form{

	public:
		ref class StateObject{
		public:
			property int bufSize;
			property Socket ^workSocket;
			property array<unsigned char>^ message;

			StateObject(Socket^ sock, int bufsize) {
				workSocket = sock;
				bufSize = bufsize;
				message = gcnew array<unsigned char>(bufsize);
			}
		};


		Form_main(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//

			//Set this to false to allow TCP Listener thread write in ListBox
			this->ListBox_msg->CheckForIllegalCrossThreadCalls = false;
			this->listener = gcnew TcpListener(IPAddress::Any, TCP_PORT);
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form_main()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  Button_svrctrl;
	private: System::Windows::Forms::ListBox^  ListBox_msg;	 

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

		//TCP Server objects
		TcpListener^ listener;


#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->Button_svrctrl = (gcnew System::Windows::Forms::Button());
			this->ListBox_msg = (gcnew System::Windows::Forms::ListBox());
			this->SuspendLayout();
			// 
			// Button_svrctrl
			// 
			this->Button_svrctrl->Location = System::Drawing::Point(241, 17);
			this->Button_svrctrl->Name = L"Button_svrctrl";
			this->Button_svrctrl->Size = System::Drawing::Size(100, 30);
			this->Button_svrctrl->TabIndex = 0;
			this->Button_svrctrl->Text = L"Startup";
			this->Button_svrctrl->Click += gcnew System::EventHandler(this, &Form_main::Button_svrctrl_Click);
			// 
			// ListBox_msg
			// 
			this->ListBox_msg->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->ListBox_msg->FormattingEnabled = true;
			this->ListBox_msg->HorizontalScrollbar = true;
			this->ListBox_msg->Location = System::Drawing::Point(11, 67);
			this->ListBox_msg->Name = L"ListBox_msg";
			this->ListBox_msg->SelectionMode = System::Windows::Forms::SelectionMode::MultiExtended;
			this->ListBox_msg->Size = System::Drawing::Size(330, 212);
			this->ListBox_msg->TabIndex = 1;
			// 
			// Form_main
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(9, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(352, 293);
			this->Controls->Add(this->ListBox_msg);
			this->Controls->Add(this->Button_svrctrl);
			this->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->Margin = System::Windows::Forms::Padding(4);
			this->MaximizeBox = false;
			this->MaximumSize = System::Drawing::Size(360, 320);
			this->MinimumSize = System::Drawing::Size(360, 320);
			this->Name = L"Form_main";
			this->Text = L"Logicam Remote Control Server 1.0";
			this->ResumeLayout(false);

		}
#pragma endregion
	private: 
		std::string ConvertToString(System::String^ str);

		void AcceptCB(IAsyncResult^ iar);
		void SendCB(IAsyncResult^ iar);
		void ReceiveCB(IAsyncResult^ iar);

		void WC_Control(int cmd);
		int WC_Startup();
		void WC_Shutdown();

	private: System::Void Button_svrctrl_Click(System::Object^  sender, System::EventArgs^  e) {
				 if(this->Button_svrctrl->Text == L"Startup"){
					 this->WC_Startup();
					 listener->Start();
					 LISTBOX("Socket started up");
					 //listener->LocalEndpoint->
					 listener->BeginAcceptSocket(gcnew AsyncCallback(this, &LRCS::Form_main::AcceptCB), listener);

					 this->Button_svrctrl->Text = L"Shutdown";
				 }else if(this->Button_svrctrl->Text == L"Shutdown"){
					 listener->Stop();
					 ListBox_msg->Items->Clear();
					 this->Button_svrctrl->Text = L"Startup";
				 }
			 }

	};
}
