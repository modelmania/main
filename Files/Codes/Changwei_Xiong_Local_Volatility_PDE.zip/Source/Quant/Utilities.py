﻿#
#  Created on: Oct 25, 2015
#  Last modified on: Oct 25, 2015
#  Author: Changwei Xiong
#  
#  Copyright (C) 2015, Changwei Xiong, 
#  axcw@hotmail.com, <https://modelmania.github.io/main/>
#
#  Licence: Revised BSD License
# 
  
# from bisect import bisect_left 
# bisect_left: a[:i] < x <= a[i:] or a[i-1] < x <= a[i]
# bisect_right: a[:i] <= x < a[i:] or a[i-1] <= x < a[i]

from math import log
import time
from functools import wraps
import numpy as np
from scipy.interpolate import interp1d 
from colorama import Fore, Style, init
#init(autoreset=True)

#import IPython; IPython.embed(); import ipdb; ipdb.set_trace()

class FormatPrint:
    def __init__(self, format='{0:.2f}'):
        self.format = format
        return

    def __call__(self, *args, **kwargs):
        args = (self.format.format(a) if isinstance(a, float) else a for a in args)
        kwargs = {k:self.format.format(a) if isinstance(a, float) else a for k,v in kwargs.items()}
        builtins.print(*args, **kwargs)


def convert_to_interpolator(size=300, ns=4.5, kind='linear'):
    def decorate(fn):
        def interpolator(x):
            stdev = np.std(x)
            if stdev == 0:
                return fn(np.mean(x))
            else:
                xv = np.linspace(-stdev * ns, stdev * ns, size)
                xv[0] = np.min(x)
                xv[-1] = np.max(x)
                yv = [fn(z) for z in xv]             
                return interp1d(x=xv, y=yv, kind=kind)(x)
        return interpolator
    return decorate 


def time_this(fn):
    """
    decorator that reports the execution time.
    """
    # use @wraps(fn) to expose the function name and docstring to the caller of
    # the decorated function (otherwise, we would see the function name and
    # docstring for the decorator, not the function it decorates).
    @wraps(fn) 
    def wrapper(*args, **kwargs):
        print('Start ' + fn.__name__)
        start = time.time()
        result = fn(*args, **kwargs)
        print(fn.__name__, 'finished in', '{0:.2f}'.format(time.time() - start), 'seconds\n')
        return result
    return wrapper 


def print_results(pv_pde, pv_mc):
    print('PV(PDE): %s' % pv_pde)
    print('PV(MC ): %s' % pv_mc)
    print('diff.% : ' + Style.BRIGHT + Fore.RED + '%s%%' % '{0:.6f}'.format(log(pv_pde / pv_mc) * 100.0))
    print(Style.RESET_ALL)


if __name__ == '__main__':
    pass


