/*
*  Created on: Dec 02, 2004
*  Last modified on: Nov 18, 2009
*  Author: Changwei Xiong
*  
*  Copyright (C) 2009, Changwei Xiong, 
*  axcw@hotmail.com, <http://www.cs.utah.edu/~cxiong/>
*
*  Licence: Revised BSD License
*/
 
#include <GL/glui.h>
#include <GL/glut.h>
#include <math.h>
#include <stdio.h>
#include "texture.h"
#include "material.h"
#include "glm.h"
#include "scene.h"


const int NUM_TEXTURES = 12;
const float delta = 0.01;

/* Objects */
#define DINE_OBJ_PATH ".\\materials\\diner.obj"
#define CHAIR_OBJ_PATH ".\\materials\\chair.obj"

/* Textures */
#define WOOD_TEXTURE_PATH ".\\materials\\wood1.rgb"
#define CARPET_TEXTURE_PATH ".\\materials\\carpet.rgb"
#define SHINGLE_TEXTURE_PATH ".\\materials\\shingle.rgb"
#define BRICK_TEXTURE_PATH ".\\materials\\brick1.rgb"
#define STUCCO_TEXTURE_PATH ".\\materials\\stucco.rgb"
#define GRASS_TEXTURE_PATH ".\\materials\\grass.rgb"
#define FAR_BRICK_TEXTURE_PATH ".\\materials\\brick2.rgb"
#define CHAIR_TEXTURE_PATH ".\\materials\\wood2.rgb"
#define PIC_TEXTURE_PATH ".\\materials\\pic.rgb"
#define DOOR_TEXTURE_PATH ".\\materials\\door.rgb"
#define BARK_TEXTURE_PATH ".\\materials\\bark.rgb"
#define PLATFORM_TEXTURE_PATH ".\\materials\\cement.rgb"

/* Scene */
enum {WOOD=0, CARPET, SHINGLE, BRICK, STUCCO, GRASS, FAR_BRICK, CHAIR, PIC, DOOR, BARK, PLATFORM};

void initObjTextureMaps();
void initLights();
void initObjs();
void drawRoof();
void drawLightBulb();
void drawWalls();
void drawPicture();
void drawTable();
void drawTeapot();
void drawChairs();
void drawFirePlace();
void drawFloor();
void drawPlatform();
void drawGrass();
void drawQuad(int texScale);

GLuint texNames[NUM_TEXTURES];

// Wavefront Objects
GLMmodel* objDine = NULL;
GLMmodel* objChair = NULL;
GLMmodel* objChimney = NULL;
GLMmodel* objBathsi = NULL;



void drawScene(){
	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE); 
	glPushMatrix();
		glColor4f(1,1,1,1);
		drawRoof();
		drawLightBulb();
		drawWalls();
		drawPicture();	
		drawTable();
		drawTeapot();
		drawChairs();
		drawFirePlace();
		drawFloor();
		drawLogs();
		drawPlatform();
		drawGrass();
	glPopMatrix();
}

void drawRoof() {
	
	/* Roof */
	const float rSc = 0.75;
	const float rH = 0.3;  
	glEnable(GL_TEXTURE_2D);
	glPushMatrix(); 
		glTranslatef(0, ROOM_HEIGHT, 0);		
		glBindTexture(GL_TEXTURE_2D, texNames[SHINGLE]); 

		/* Top */
		glBegin(GL_QUADS);			
			glNormal3f(0, 1, 0);
			glTexCoord2f(5, 5); glVertex3f(ROOF_SIZE, rH, ROOF_SIZE);
			glTexCoord2f(0, 5); glVertex3f(-ROOF_SIZE, rH, ROOF_SIZE);
			glTexCoord2f(0, 0); glVertex3f(-ROOF_SIZE, rH, -ROOF_SIZE);
			glTexCoord2f(5, 0); glVertex3f(ROOF_SIZE, rH, -ROOF_SIZE);
		glEnd(); 

		glBindTexture(GL_TEXTURE_2D, texNames[STUCCO]);

		glBegin(GL_QUADS);
			/* Bottom */
			glNormal3f(0, -1, 0);
			glTexCoord2f(5, 5); glVertex3f(ROOM_HEIGHT + rSc, 0, ROOM_HEIGHT + rSc);
			glTexCoord2f(0, 5); glVertex3f(-ROOM_HEIGHT - rSc, 0, ROOM_HEIGHT + rSc);
			glTexCoord2f(0, 0); glVertex3f(-ROOM_HEIGHT - rSc, 0, -ROOM_HEIGHT - rSc);
			glTexCoord2f(5, 0); glVertex3f(ROOM_HEIGHT + rSc, 0, -ROOM_HEIGHT - rSc);
			
			/* Near */
			glNormal3f(0, 0, -1);
			glTexCoord2f(1.25, 1.25); glVertex3f(ROOM_HEIGHT + rSc, 0, ROOM_HEIGHT + rSc);
			glTexCoord2f(0, 1.25); glVertex3f(-ROOM_HEIGHT - rSc, 0, ROOM_HEIGHT + rSc);
			glTexCoord2f(0, 0); glVertex3f(-ROOM_HEIGHT - rSc, rH, ROOM_HEIGHT + rSc);
			glTexCoord2f(1.25, 0); glVertex3f(ROOM_HEIGHT + rSc, rH, ROOM_HEIGHT + rSc);
			
			/* Left */
			glNormal3f(-1, 0, 0);
			glTexCoord2f(1.25, 1.25); glVertex3f(ROOM_HEIGHT + rSc, 0, ROOM_HEIGHT + rSc);
			glTexCoord2f(0, 1.25); glVertex3f(ROOM_HEIGHT + rSc, 0, -ROOM_HEIGHT - rSc);
			glTexCoord2f(0, 0); glVertex3f(ROOM_HEIGHT + rSc, rH, -ROOM_HEIGHT - rSc);
			glTexCoord2f(1.25, 0); glVertex3f(ROOM_HEIGHT + rSc, rH, ROOM_HEIGHT + rSc);

			/* Far */
			glNormal3f(0, 0, 1);
			glTexCoord2f(1.25, 1.25); glVertex3f(ROOM_HEIGHT + rSc, 0, -ROOM_HEIGHT - rSc);
			glTexCoord2f(0, 1.25); glVertex3f(-ROOM_HEIGHT - rSc, 0, -ROOM_HEIGHT - rSc);
			glTexCoord2f(0, 0); glVertex3f(-ROOM_HEIGHT - rSc, rH, -ROOM_HEIGHT - rSc);
			glTexCoord2f(1.25, 0); glVertex3f(ROOM_HEIGHT + rSc, rH, -ROOM_HEIGHT - rSc);
			
			/* Right */
			glNormal3f(1, 0, 0);
			glTexCoord2f(1.25, 1.25); glVertex3f(-ROOM_HEIGHT - rSc, 0, ROOM_HEIGHT + rSc);
			glTexCoord2f(0, 1.25); glVertex3f(-ROOM_HEIGHT - rSc, 0, -ROOM_HEIGHT - rSc);
			glTexCoord2f(0, 0); glVertex3f(-ROOM_HEIGHT - rSc, rH, -ROOM_HEIGHT - rSc);
			glTexCoord2f(1.25, 0); glVertex3f(-ROOM_HEIGHT - rSc, rH, ROOM_HEIGHT + rSc);

		glEnd();
	glPopMatrix();	 
	glDisable(GL_TEXTURE_2D);
	
}

void drawLightBulb() {
	
	/* Light Cylinder */
	setMaterial(3);
	glPushMatrix();
		glTranslatef(0, ROOM_HEIGHT, 0);
		glRotatef(90, 1, 0, 0);
		GLUquadricObj* cyl = gluNewQuadric();
		gluQuadricDrawStyle(cyl, GLU_FILL);
		gluQuadricNormals(cyl, GLU_FLAT);
		gluCylinder(cyl, 0.06, 0.06, 1.5, 20, 20);
	glPopMatrix();
	
	/* Light Sphere */
	setMaterial(2);
	glPushMatrix();
		glTranslatef(0, ROOM_HEIGHT-1.5, 0);
		glutSolidSphere(0.30, 20, 20);
	glPopMatrix();
	setMaterial(0);
}
	
void drawWalls() {
	
	/* Walls */
	const int wD = 1;  
	glEnable(GL_TEXTURE_2D);

	glPushMatrix();
		glBindTexture(GL_TEXTURE_2D, texNames[BRICK]);
		
		{
			/* Left Wall */
			glBegin(GL_QUADS);
				glNormal3f(-1, 0, 0);
				glTexCoord2f(wD, wD); glVertex3f(ROOM_HEIGHT, ROOM_HEIGHT, ROOM_HEIGHT);
				glTexCoord2f(wD, 0); glVertex3f(ROOM_HEIGHT, -ROOM_HEIGHT, ROOM_HEIGHT);
				glTexCoord2f(0, 0); glVertex3f(ROOM_HEIGHT, -ROOM_HEIGHT, -ROOM_HEIGHT);
				glTexCoord2f(0, wD); glVertex3f(ROOM_HEIGHT, ROOM_HEIGHT, -ROOM_HEIGHT);
			glEnd();
		
			/* Right Wall */
			glBegin(GL_QUADS);
				glNormal3f(1, 0, 0);
				glTexCoord2f(wD, wD); glVertex3f(-ROOM_HEIGHT, ROOM_HEIGHT, ROOM_HEIGHT);
				glTexCoord2f(wD, 0); glVertex3f(-ROOM_HEIGHT, -ROOM_HEIGHT, ROOM_HEIGHT);
				glTexCoord2f(0, 0); glVertex3f(-ROOM_HEIGHT, -ROOM_HEIGHT, -ROOM_HEIGHT);
				glTexCoord2f(0, wD); glVertex3f(-ROOM_HEIGHT, ROOM_HEIGHT, -ROOM_HEIGHT);
			glEnd();
		
		}
		
		/* Back */
		glBindTexture(GL_TEXTURE_2D, texNames[BRICK]);
		glEnable(GL_TEXTURE_2D);
		{
			glBegin(GL_QUADS);
				glNormal3f(0, 0, 1);
				glTexCoord2f(wD, wD); glVertex3f(ROOM_HEIGHT, ROOM_HEIGHT, -ROOM_HEIGHT);
				glTexCoord2f(0, wD); glVertex3f(-ROOM_HEIGHT, ROOM_HEIGHT, -ROOM_HEIGHT);
				glTexCoord2f(0, 0); glVertex3f(-ROOM_HEIGHT, -ROOM_HEIGHT, -ROOM_HEIGHT);
				glTexCoord2f(wD, 0); glVertex3f(ROOM_HEIGHT, -ROOM_HEIGHT, -ROOM_HEIGHT);
			glEnd();
		}
		glDisable(GL_TEXTURE_2D);

		/* Front */
		glBindTexture(GL_TEXTURE_2D, texNames[DOOR]);
		glEnable(GL_TEXTURE_2D);
		{
			glBegin(GL_QUADS);
				glNormal3f(0, 0, -1);
				glTexCoord2f(1, 1); glVertex3f(ROOM_HEIGHT, ROOM_HEIGHT, ROOM_HEIGHT);
				glTexCoord2f(0, 1); glVertex3f(-ROOM_HEIGHT, ROOM_HEIGHT, ROOM_HEIGHT);
				glTexCoord2f(0, 0); glVertex3f(-ROOM_HEIGHT, -ROOM_HEIGHT, ROOM_HEIGHT);
				glTexCoord2f(1, 0); glVertex3f(ROOM_HEIGHT, -ROOM_HEIGHT, ROOM_HEIGHT);
			glEnd();
		}
	glPopMatrix();
	glDisable(GL_TEXTURE_2D);
}

void drawPicture() {
	
	/* Picture */
	
	glEnable(GL_TEXTURE_2D);
	glPushMatrix();
		glBindTexture(GL_TEXTURE_2D, texNames[PIC]);
		glTranslatef(ROOM_HEIGHT-delta, -.75, -2.0);
		glRotatef(270, 0, 1, 0);
		glBegin(GL_QUADS);
			glNormal3f(0, 0, 1);
			glTexCoord2f(0, 0); glVertex3f(0, 0, 0);
			glTexCoord2f(1, 0); glVertex3f(4, 0, 0);
			glTexCoord2f(1, 1); glVertex3f(4, 4, 0);
			glTexCoord2f(0, 1); glVertex3f(0, 4, 0);
		glEnd();
	glPopMatrix();
	glDisable(GL_TEXTURE_2D);
}

void drawTable() {	
	/* Table */
	const int objSc = 3;  	
	glEnable(GL_TEXTURE_2D);
	glPushMatrix();	
		glBindTexture(GL_TEXTURE_2D, texNames[WOOD]); 
		glTranslatef(-2.9, -ROOM_HEIGHT, 1);
		glRotatef(270, 1, 0, 0);
		glScalef(objSc, objSc-1, objSc);
		glmDraw(objDine, GLM_TEXTURE);
	glPopMatrix();
	glDisable(GL_TEXTURE_2D);
}

void drawTeapot() {
	const float TP_SIZE = 0.5;
	setMaterial(1);
	glPushMatrix();
		glTranslatef(-3.0, -2.372, 1);
		glutSolidTeapot(TP_SIZE);
	glPopMatrix();
	setMaterial(0);
	
}

void drawChairs() {
	const int objSc = 3;
	/* Chair 1 */    	
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texNames[CHAIR]);
	glPushMatrix();
		glTranslatef(-4.0, 0.6-ROOM_HEIGHT, -2.0);
		glRotatef(270, 1, 0, 0);
		glScalef(objSc, objSc, objSc);
		glmDraw(objChair, GLM_TEXTURE);
	glPopMatrix();

	/* Chair 2 */
	glPushMatrix();
		glTranslatef(-2.50, 0.6-ROOM_HEIGHT, 4.75);
		glRotatef(270, 1, 0, 0);
		glRotatef(135, 0, 0, 1);
		glScalef(objSc, objSc, objSc);
		glmDraw(objChair, GLM_TEXTURE);
	glPopMatrix();
	glDisable(GL_TEXTURE_2D);
}

void drawFirePlace() {   
	/* Fire Place */
	/* Left Front */
	const float zF = -ROOM_HEIGHT+0.75;
	const float zB = -ROOM_HEIGHT-1; 

	glBindTexture(GL_TEXTURE_2D, texNames[FAR_BRICK]);
	glEnable(GL_TEXTURE_2D);
	glPushMatrix();
		glTranslatef(0, -ROOM_HEIGHT, 0);

		glPushMatrix();
			glTranslatef(1.5, 0, 1);
			glBegin(GL_QUADS);
				glNormal3f(0, 0, 1);
				glTexCoord2f(1, 3); glVertex3f(ROOM_HEIGHT/14, ROOM_HEIGHT-(ROOM_HEIGHT/3), zF);
				glTexCoord2f(0, 3); glVertex3f(-ROOM_HEIGHT/14, ROOM_HEIGHT-(ROOM_HEIGHT/3), zF);
				glTexCoord2f(0, 0); glVertex3f(-ROOM_HEIGHT/14, 0, zF);
				glTexCoord2f(3, 0); glVertex3f(ROOM_HEIGHT/14, 0, zF);
			glEnd();
		glPopMatrix();

		/* LF Left Side */
		glPushMatrix();
			glTranslatef(1.5, 0, 1);
			glNormal3f(1, 0, 0);
			glBegin(GL_QUADS);
				glTexCoord2d(1, 3); glVertex3f(ROOM_HEIGHT/14, ROOM_HEIGHT-(ROOM_HEIGHT/3), zF);
				glTexCoord2d(1, 0); glVertex3f(ROOM_HEIGHT/14, 0, zF);
				glTexCoord2d(0, 0); glVertex3f(ROOM_HEIGHT/14, 0, zB);
				glTexCoord2d(0, 3); glVertex3f(ROOM_HEIGHT/14, ROOM_HEIGHT-(ROOM_HEIGHT/3), zB);
			glEnd();
		glPopMatrix();

		/* LF Right Side */
		glPushMatrix();
			glTranslatef(0.85, 0, 1);
			glNormal3f(-1, 0, 0);
			glBegin(GL_QUADS);
				glTexCoord2d(1, 3); glVertex3f(ROOM_HEIGHT/14, ROOM_HEIGHT-(ROOM_HEIGHT/3), zF);
				glTexCoord2d(0, 3); glVertex3f(ROOM_HEIGHT/14, ROOM_HEIGHT-(ROOM_HEIGHT/3), -ROOM_HEIGHT-1);
				glTexCoord2d(0, 0); glVertex3f(ROOM_HEIGHT/14, 0, -ROOM_HEIGHT-1);
				glTexCoord2d(1, 0); glVertex3f(ROOM_HEIGHT/14, 0, zF);
			glEnd();
		glPopMatrix();

		/* Right Front */
		glPushMatrix();
			glTranslatef(-1.5, 0, 1);
			glBegin(GL_QUADS);
				glNormal3f(0, 0, 1);
				glTexCoord2f(1, 3); glVertex3f(ROOM_HEIGHT/14, ROOM_HEIGHT-(ROOM_HEIGHT/3), zF);
				glTexCoord2f(0, 3); glVertex3f(-ROOM_HEIGHT/14, ROOM_HEIGHT-(ROOM_HEIGHT/3), zF);
				glTexCoord2f(0, 0); glVertex3f(-ROOM_HEIGHT/14, 0, zF);
				glTexCoord2f(1, 0); glVertex3f(ROOM_HEIGHT/14, 0, zF);
			glEnd();
		glPopMatrix();

		/* RF Right Side */
		glPushMatrix();
			glTranslatef(-1.5, 0, 1);
			glNormal3f(1, 0, 0);
			glBegin(GL_QUADS);
				glTexCoord2d(1, 3); glVertex3f(ROOM_HEIGHT/14, ROOM_HEIGHT-(ROOM_HEIGHT/3), zF);
				glTexCoord2d(1, 0); glVertex3f(ROOM_HEIGHT/14, 0, zF);
				glTexCoord2d(0, 0); glVertex3f(ROOM_HEIGHT/14, 0, -ROOM_HEIGHT-1);
				glTexCoord2d(0, 3); glVertex3f(ROOM_HEIGHT/14, ROOM_HEIGHT-(ROOM_HEIGHT/3), -ROOM_HEIGHT-1);
			glEnd();
		glPopMatrix();
		
		/* RF Left Side */
		glPushMatrix();
			glTranslatef(-2.15, 0, 1);
			glNormal3f(-1, 0, 0);
			glBegin(GL_QUADS);
				glTexCoord2d(1, 3); glVertex3f(ROOM_HEIGHT/14, ROOM_HEIGHT-(ROOM_HEIGHT/3), zF);
				glTexCoord2d(0, 3); glVertex3f(ROOM_HEIGHT/14, ROOM_HEIGHT-(ROOM_HEIGHT/3), -ROOM_HEIGHT-1);	
				glTexCoord2d(0, 0); glVertex3f(ROOM_HEIGHT/14, 0, -ROOM_HEIGHT-1);
				glTexCoord2d(1, 0); glVertex3f(ROOM_HEIGHT/14, 0, zF);
			glEnd();
		glPopMatrix();

		/* Front Top */
		glPushMatrix();
			glTranslatef(0, ROOM_HEIGHT-(ROOM_HEIGHT/4), 1.5);
			glBegin(GL_QUADS);
				glNormal3f(0, 0, 1);
				glTexCoord2f(3, 1); glVertex3f(ROOM_HEIGHT/2.5, 0, zF);
				glTexCoord2f(0, 1); glVertex3f(-ROOM_HEIGHT/2.5, 0, zF);
				glTexCoord2f(0, 0); glVertex3f(-ROOM_HEIGHT/2.5, -ROOM_HEIGHT/8, zF);
				glTexCoord2f(3, 0); glVertex3f(ROOM_HEIGHT/2.5, -ROOM_HEIGHT/8, zF);
			glEnd();
		glPopMatrix();
		
		/* FT Right */
		glPushMatrix();
			glTranslatef(0, ROOM_HEIGHT-(ROOM_HEIGHT/4), 1.5);
			glBegin(GL_QUADS);
				glNormal3f(1, 0, 0);
				glTexCoord2f(0, 0); glVertex3f(ROOM_HEIGHT/2.5, 0, zF);
				glTexCoord2f(0, 1); glVertex3f(ROOM_HEIGHT/2.5, -ROOM_HEIGHT/8, zF);
				glTexCoord2f(3, 1); glVertex3f(ROOM_HEIGHT/2.5, -ROOM_HEIGHT/8, -ROOM_HEIGHT-1.5);
				glTexCoord2f(3, 0); glVertex3f(ROOM_HEIGHT/2.5, 0, -ROOM_HEIGHT-1.5);
			glEnd();
		glPopMatrix();
		
		/* FT Left */
		glPushMatrix();
			glTranslatef(-4, ROOM_HEIGHT-(ROOM_HEIGHT/4), 1.5);
			glBegin(GL_QUADS);
				glNormal3f(-1, 0, 0);
				glTexCoord2f(0, 0); glVertex3f(ROOM_HEIGHT/2.5, 0, zF);
				glTexCoord2f(3, 0); glVertex3f(ROOM_HEIGHT/2.5, 0, -ROOM_HEIGHT-1.5);
				glTexCoord2f(3, 1); glVertex3f(ROOM_HEIGHT/2.5, -ROOM_HEIGHT/8, -ROOM_HEIGHT-1.5);
				glTexCoord2f(0, 1); glVertex3f(ROOM_HEIGHT/2.5, -ROOM_HEIGHT/8, zF);
			glEnd();
		glPopMatrix();

		/* FT Top */
		glPushMatrix();
			glTranslatef(0, ROOM_HEIGHT-(ROOM_HEIGHT/4), 1.5);
			glBegin(GL_QUADS);
				glNormal3f(0, 1, 0);
				glTexCoord2f(3, 1); glVertex3f(ROOM_HEIGHT/2.5, 0, zF);
				glTexCoord2f(3, 0); glVertex3f(ROOM_HEIGHT/2.5, 0, -ROOM_HEIGHT-1.5);
				glTexCoord2f(0, 0); glVertex3f(-ROOM_HEIGHT/2.5, 0, -ROOM_HEIGHT-1.5);
				glTexCoord2f(0, 1); glVertex3f(-ROOM_HEIGHT/2.5, 0, zF);
			glEnd();
		glPopMatrix();

		//glutSolidSphere(0.2, 20, 20);
		//very bottom surface  *************************
		glPushMatrix();
			glTranslatef(0, delta, 1.5);
			glBegin(GL_QUADS);
				glNormal3f(0, 1, 0);
				glTexCoord2f(3, 1); glVertex3f( ROOM_HEIGHT/3, 0, zF-0.5);
				glTexCoord2f(3, 0); glVertex3f( ROOM_HEIGHT/3, 0, zF-2.25);
				glTexCoord2f(0, 0); glVertex3f(-ROOM_HEIGHT/3, 0, zF-2.25);
				glTexCoord2f(0, 1); glVertex3f(-ROOM_HEIGHT/3, 0, zF-0.5);
			glEnd();
		glPopMatrix();

		/* FT Bottom */
		glPushMatrix();
			glTranslatef(0, ROOM_HEIGHT-(ROOM_HEIGHT/4), 1.5);
			glBegin(GL_QUADS);
				glNormal3f(0, -1, 0);
				glTexCoord2f(3, 1); glVertex3f(ROOM_HEIGHT/2.5, -ROOM_HEIGHT/8, zF);
				glTexCoord2f(0, 1); glVertex3f(-ROOM_HEIGHT/2.5, -ROOM_HEIGHT/8, zF);
				glTexCoord2f(0, 0); glVertex3f(-ROOM_HEIGHT/2.5, -ROOM_HEIGHT/8, -ROOM_HEIGHT-1.5);
				glTexCoord2f(3, 0); glVertex3f(ROOM_HEIGHT/2.5, -ROOM_HEIGHT/8, -ROOM_HEIGHT-1.5);
			glEnd();
		glPopMatrix();

		/* In-House Chimney */
		/* Front */
		glPushMatrix();
			glTranslatef(0, ROOM_HEIGHT-(ROOM_HEIGHT/3), 1);
			glBegin(GL_QUADS);
				glNormal3f(0, 0, 1);
				glTexCoord2f(1, 7); glVertex3f(ROOM_HEIGHT/8, ROOM_HEIGHT+(ROOM_HEIGHT/1), zF);
				glTexCoord2f(0, 7); glVertex3f(-ROOM_HEIGHT/8, ROOM_HEIGHT+(ROOM_HEIGHT/1), zF);
				glTexCoord2f(0, 0); glVertex3f(-ROOM_HEIGHT/8, 0, zF);
				glTexCoord2f(1, 0); glVertex3f(ROOM_HEIGHT/8, 0, zF);
			glEnd();
		glPopMatrix();
		
		/* Back */
		glPushMatrix();
			glTranslatef(0, ROOM_HEIGHT-(ROOM_HEIGHT/3), .01);
			glBegin(GL_QUADS);
				glNormal3f(0, 0, -1);
				glTexCoord2f(1, 7); glVertex3f(ROOM_HEIGHT/8, ROOM_HEIGHT+(ROOM_HEIGHT/1), -ROOM_HEIGHT);
				glTexCoord2f(1, 0); glVertex3f(ROOM_HEIGHT/8, 0, -ROOM_HEIGHT);
				glTexCoord2f(0, 0); glVertex3f(-ROOM_HEIGHT/8, 0, -ROOM_HEIGHT);								
				glTexCoord2f(0, 7); glVertex3f(-ROOM_HEIGHT/8, ROOM_HEIGHT+(ROOM_HEIGHT/1), -ROOM_HEIGHT);				
			glEnd();
		glPopMatrix();
		
		/* Right */
		glPushMatrix();
			glTranslatef(0, ROOM_HEIGHT-(ROOM_HEIGHT/3), 1);
			glBegin(GL_QUADS);
				glNormal3f(1, 0, 0);
				glTexCoord2f(0, 0); glVertex3f(ROOM_HEIGHT/8, 0, zF);
				glTexCoord2f(1, 0); glVertex3f(ROOM_HEIGHT/8, 0, -ROOM_HEIGHT-1);
				glTexCoord2f(1, 7); glVertex3f(ROOM_HEIGHT/8, ROOM_HEIGHT+(ROOM_HEIGHT/1), -ROOM_HEIGHT-1);
				glTexCoord2f(0, 7); glVertex3f(ROOM_HEIGHT/8, ROOM_HEIGHT+(ROOM_HEIGHT/1), zF);
			glEnd();
		glPopMatrix();
		
		/* Left */
		
		glPushMatrix();
			glTranslatef(-1.25, ROOM_HEIGHT-(ROOM_HEIGHT/3), 1);
			glBegin(GL_QUADS);
				glNormal3f(-1, 0, 0);
				glTexCoord2f(0, 0); glVertex3f(ROOM_HEIGHT/8, 0, zF);
				glTexCoord2f(0, 7); glVertex3f(ROOM_HEIGHT/8, ROOM_HEIGHT+(ROOM_HEIGHT/1), zF);
				glTexCoord2f(1, 7); glVertex3f(ROOM_HEIGHT/8, ROOM_HEIGHT+(ROOM_HEIGHT/1), -ROOM_HEIGHT-1);
				glTexCoord2f(1, 0); glVertex3f(ROOM_HEIGHT/8, 0, -ROOM_HEIGHT-1);
			glEnd();
		glPopMatrix();
		
		glPushMatrix();
			glTranslatef(0, 3.25, .01);
			glBegin(GL_QUADS);
				glNormal3f(0, 0, 1);
				glTexCoord2f(2, 2); glVertex3f(ROOM_HEIGHT/3, 0, -ROOM_HEIGHT);
				glTexCoord2f(2, 0); glVertex3f(ROOM_HEIGHT/3, -ROOM_HEIGHT/1.5, -ROOM_HEIGHT);
				glTexCoord2f(0, 0); glVertex3f(-ROOM_HEIGHT/3, -ROOM_HEIGHT/1.5, -ROOM_HEIGHT);
				glTexCoord2f(0, 2); glVertex3f(-ROOM_HEIGHT/3, 0, -ROOM_HEIGHT);
			glEnd();
		glPopMatrix();
	
	glPopMatrix();
	glDisable(GL_TEXTURE_2D);
}

void drawFloor() {
	
	/* Floor */         	
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texNames[CARPET]);
	glPushMatrix();
		glTranslatef(0, -ROOM_HEIGHT, 0);
		glBegin(GL_QUADS);
			glNormal3f(0, 1, 0);
			glTexCoord2f(1, 1); glVertex3f(ROOM_HEIGHT, 0, ROOM_HEIGHT);
			glTexCoord2f(-1, 1); glVertex3f(-ROOM_HEIGHT, 0, ROOM_HEIGHT);
			glTexCoord2f(-1, -1); glVertex3f(-ROOM_HEIGHT, 0, -ROOM_HEIGHT);
			glTexCoord2f(1, -1); glVertex3f(ROOM_HEIGHT, 0, -ROOM_HEIGHT);
		glEnd();
	glPopMatrix();
	glDisable(GL_TEXTURE_2D);	
}

void drawLogs() {

	glBindTexture(GL_TEXTURE_2D, texNames[BARK]);
	glEnable(GL_TEXTURE_2D);

	glPushMatrix();
		glTranslatef(0, -ROOM_HEIGHT+0.1, -ROOM_HEIGHT+1.75);

		glPushMatrix();
			glRotatef(225, 1, 0, 0);
			GLUquadricObj* cyl1 = gluNewQuadric();
			gluQuadricDrawStyle(cyl1, GLU_FILL);
			gluQuadricNormals(cyl1, GLU_FLAT);
			gluQuadricTexture(cyl1, GL_TRUE);
			gluCylinder(cyl1, 0.15, 0.15, 1.0, 20, 20);
		glPopMatrix();
		
		glPushMatrix();
			glTranslatef(0, 0.75, -.75);
			glRotatef(135, 1, 0, 0);
			GLUquadricObj* cyl2 = gluNewQuadric();
			gluQuadricDrawStyle(cyl2, GLU_FILL);
			gluQuadricNormals(cyl2, GLU_FLAT);
			gluQuadricTexture(cyl2, GL_TRUE);
			gluCylinder(cyl2, 0.15, 0.15, 1.0, 20, 20);
		glPopMatrix();
		
		glPushMatrix();
			glTranslatef(0.75, 0, -0.75);
			glRotatef(90, 0, 1, 0);
			glPushMatrix();
				glRotatef(225, 1, 0, 0);
				GLUquadricObj* cyl3 = gluNewQuadric();
				gluQuadricDrawStyle(cyl3, GLU_FILL);
				gluQuadricNormals(cyl3, GLU_FLAT);
				gluQuadricTexture(cyl3, GL_TRUE);
				gluCylinder(cyl3, 0.15, 0.15, 1.0, 20, 20);
			glPopMatrix();
		
			glPushMatrix();
				glTranslatef(0, 0.75, -.75);
				glRotatef(135, 1, 0, 0);
				GLUquadricObj* cyl4 = gluNewQuadric();
				gluQuadricDrawStyle(cyl4, GLU_FILL);
				gluQuadricNormals(cyl4, GLU_FLAT);
				gluQuadricTexture(cyl4, GL_TRUE);
				gluCylinder(cyl4, 0.15, 0.15, 1.0, 20, 20);
			glPopMatrix();
		glPopMatrix();

		glTranslatef(-0.75, .1 , -1.50);
		glRotatef(45, 0, 1, 0);
		
		glPushMatrix();
			GLUquadricObj* cyl5 = gluNewQuadric();
			gluQuadricDrawStyle(cyl5, GLU_FILL);
			gluQuadricNormals(cyl5, GLU_FLAT);
			gluQuadricTexture(cyl5, GL_TRUE);
			gluCylinder(cyl5, 0.15, 0.15, 2.0, 20, 20);
		glPopMatrix();
		
		glPushMatrix();
			glTranslatef(-1, 0, 1);
			glRotatef(90, 0, 1, 0);
			GLUquadricObj* cyl6 = gluNewQuadric();
			gluQuadricDrawStyle(cyl6, GLU_FILL);
			gluQuadricNormals(cyl6, GLU_FLAT);
			gluQuadricTexture(cyl6, GL_TRUE);
			gluCylinder(cyl6, 0.15, 0.15, 2.0, 20, 20);
		glPopMatrix();
	
	glPopMatrix();
	glDisable(GL_TEXTURE_2D);
}


void drawPlatform() {
	const float w = ROOM_HEIGHT + 2.5;
	const float h = 0.5; 
	const float ttc = 4;
	const float stw = 4;
	const float sth  = 0.25;
		/* Platform */
	glBindTexture(GL_TEXTURE_2D, texNames[PLATFORM]);
	glEnable(GL_TEXTURE_2D);
	
	glPushMatrix();
		glTranslatef(0, -ROOM_HEIGHT-delta, 0);
		//top face
		glBegin(GL_QUADS);
			glNormal3f(0, 1, 0);
			glTexCoord2f(ttc, ttc); glVertex3f( w,  0,  w);
			glTexCoord2f(ttc,   0); glVertex3f(-w,  0,  w);
			glTexCoord2f(0  ,   0); glVertex3f(-w,  0, -w);
			glTexCoord2f(0  , ttc); glVertex3f( w,  0, -w);
		glEnd(); 

		glTranslatef(0, -h, 0);

		//front side
		glBegin(GL_QUADS);
			glNormal3f(0, 0, 1);
			glTexCoord2f(stw, sth); glVertex3f( w,  h,  w);
			glTexCoord2f(0  , sth); glVertex3f(-w,  h,  w);
			glTexCoord2f(0  ,   0); glVertex3f(-w, -h,  w);
			glTexCoord2f(stw,   0); glVertex3f( w, -h,  w);
		glEnd(); 

		//right side
		glBegin(GL_QUADS);
			glNormal3f(1, 0, 0);
			glTexCoord2f(stw, sth); glVertex3f( w,  h, -w);
			glTexCoord2f(0  , sth); glVertex3f( w,  h,  w);
			glTexCoord2f(0  ,   0); glVertex3f( w, -h,  w);
			glTexCoord2f(stw,   0); glVertex3f( w, -h, -w);
		glEnd();

		//back side
		glBegin(GL_QUADS);
			glNormal3f(0, 0, -1);
			glTexCoord2f(0  , sth); glVertex3f( w,  h, -w);
			glTexCoord2f(0  ,   0); glVertex3f( w, -h, -w);
			glTexCoord2f(stw,   0); glVertex3f(-w, -h, -w);
			glTexCoord2f(stw, sth); glVertex3f(-w,  h, -w);
		glEnd();

		//left side
		glBegin(GL_QUADS);
			glNormal3f(-1, 0, 0);
			glTexCoord2f(0  , sth); glVertex3f(-w,  h, -w);
			glTexCoord2f(0  ,   0); glVertex3f(-w, -h, -w);
			glTexCoord2f(stw,   0); glVertex3f(-w, -h,  w);
			glTexCoord2f(stw, sth); glVertex3f(-w,  h,  w);
		glEnd();
	glPopMatrix();

	glDisable(GL_TEXTURE_2D);
}

void drawGrass() {
	
	/* grass */
	glBindTexture(GL_TEXTURE_2D, texNames[GRASS]);
	glEnable(GL_TEXTURE_2D);
	
	glPushMatrix();
		glTranslatef(0, -ROOM_HEIGHT-1, 0);
		glBegin(GL_QUADS);
				glNormal3f(0, 1, 0);
				glTexCoord2f(10, 10); glVertex3f(GROUND_SIZE, -0.1, GROUND_SIZE);
				glTexCoord2f(10, 0); glVertex3f(-GROUND_SIZE, -0.1, GROUND_SIZE);
				glTexCoord2f(0, 0); glVertex3f(-GROUND_SIZE, -0.1, -GROUND_SIZE);
				glTexCoord2f(0, 10); glVertex3f(GROUND_SIZE, -0.1, -GROUND_SIZE);
		glEnd();  
	glPopMatrix();

	glDisable(GL_TEXTURE_2D);
}


void initObjTextureMaps() {
	
	unsigned *wood;
	int width, height, comp;
	
	glGenTextures(NUM_TEXTURES, texNames);
	
	wood = read_texture(WOOD_TEXTURE_PATH, &width, &height, &comp);
	glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
	glBindTexture(GL_TEXTURE_2D, texNames[WOOD]);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	gluBuild2DMipmaps(GL_TEXTURE_2D, GL_RGBA, width, height, GL_RGBA, GL_UNSIGNED_BYTE, wood);	


	unsigned *carpet;
	carpet = read_texture(CARPET_TEXTURE_PATH, &width, &height, &comp);
	glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
	glBindTexture(GL_TEXTURE_2D, texNames[CARPET]);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	gluBuild2DMipmaps(GL_TEXTURE_2D, GL_RGBA, width, height, GL_RGBA, GL_UNSIGNED_BYTE, carpet);

	unsigned *shingle;
	shingle = read_texture(SHINGLE_TEXTURE_PATH, &width, &height, &comp);
	glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
	glBindTexture(GL_TEXTURE_2D, texNames[SHINGLE]);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	gluBuild2DMipmaps(GL_TEXTURE_2D, GL_RGBA, width, height, GL_RGBA, GL_UNSIGNED_BYTE, shingle);

	unsigned *brick;
	brick = read_texture(BRICK_TEXTURE_PATH, &width, &height, &comp);
	glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
	glBindTexture(GL_TEXTURE_2D, texNames[BRICK]);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	gluBuild2DMipmaps(GL_TEXTURE_2D, GL_RGBA, width, height, GL_RGBA, GL_UNSIGNED_BYTE, brick);

	unsigned *stucco;
	stucco = read_texture(STUCCO_TEXTURE_PATH, &width, &height, &comp);
	glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
	glBindTexture(GL_TEXTURE_2D, texNames[STUCCO]);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	gluBuild2DMipmaps(GL_TEXTURE_2D, GL_RGBA, width, height, GL_RGBA, GL_UNSIGNED_BYTE, stucco);
	
	unsigned *grass;
	grass = read_texture(GRASS_TEXTURE_PATH, &width, &height, &comp);
	glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
	glBindTexture(GL_TEXTURE_2D, texNames[GRASS]);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	gluBuild2DMipmaps(GL_TEXTURE_2D, GL_RGBA, width, height, GL_RGBA, GL_UNSIGNED_BYTE, grass);
	
	unsigned *farBrick;
	farBrick = read_texture(FAR_BRICK_TEXTURE_PATH, &width, &height, &comp);
	glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
	glBindTexture(GL_TEXTURE_2D, texNames[FAR_BRICK]);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	gluBuild2DMipmaps(GL_TEXTURE_2D, GL_RGBA, width, height, GL_RGBA, GL_UNSIGNED_BYTE, farBrick);
	
	unsigned *chair;
	chair = read_texture(CHAIR_TEXTURE_PATH, &width, &height, &comp);
	glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
	glBindTexture(GL_TEXTURE_2D, texNames[CHAIR]);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	gluBuild2DMipmaps(GL_TEXTURE_2D, GL_RGBA, width, height, GL_RGBA, GL_UNSIGNED_BYTE, chair);
	
	unsigned *pic;
	pic = read_texture(PIC_TEXTURE_PATH, &width, &height, &comp);
	glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
	glBindTexture(GL_TEXTURE_2D, texNames[PIC]);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	gluBuild2DMipmaps(GL_TEXTURE_2D, GL_RGBA, width, height, GL_RGBA, GL_UNSIGNED_BYTE, pic);
	
	unsigned *door;
	door = read_texture(DOOR_TEXTURE_PATH, &width, &height, &comp);
	glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
	glBindTexture(GL_TEXTURE_2D, texNames[DOOR]);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	gluBuild2DMipmaps(GL_TEXTURE_2D, GL_RGBA, width, height, GL_RGBA, GL_UNSIGNED_BYTE, door);

	unsigned *bark;
	bark = read_texture(BARK_TEXTURE_PATH, &width, &height, &comp);
	glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
	glBindTexture(GL_TEXTURE_2D, texNames[BARK]);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	gluBuild2DMipmaps(GL_TEXTURE_2D, GL_RGBA, width, height, GL_RGBA, GL_UNSIGNED_BYTE, bark);

	unsigned *cement;
	cement = read_texture(PLATFORM_TEXTURE_PATH, &width, &height, &comp);
	glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
	glBindTexture(GL_TEXTURE_2D, texNames[PLATFORM]);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	gluBuild2DMipmaps(GL_TEXTURE_2D, GL_RGBA, width, height, GL_RGBA, GL_UNSIGNED_BYTE, cement);


}

void initObjs() {

	// Load Dinning Room Table
	objDine = glmReadOBJ(DINE_OBJ_PATH);
	glmFacetNormals(objDine);
	glmVertexNormals(objDine, 90);
	glmLinearTexture(objDine);
	
	// Load Chair
	objChair = glmReadOBJ(CHAIR_OBJ_PATH);
	glmFacetNormals(objChair);
	glmVertexNormals(objChair, 90);
	glmLinearTexture(objChair);
}