/*
*  Created on: Dec 02, 2004
*  Last modified on: Nov 18, 2009
*  Author: Changwei Xiong
*
*  Copyright (C) 2009, Changwei Xiong,
*  axcw@hotmail.com, <http://www.cs.utah.edu/~cxiong/>
*
*  Licence: Revised BSD License
*/

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <iostream>	
#include <GL/glut.h>
#include <GL/glui.h>

#include "scene.h"
#include "util.h"
#include "pixmap.h"
using namespace std;

#pragma comment( lib, "opengl32.lib" )
#pragma comment( lib, "glu32.lib" )
#pragma comment( lib, "freeglut.lib" )
#pragma comment( lib, "glui32.lib" )

const float PI = 3.1415926535897932384626433832795;

//-----------My Variables --------------

#define DRAW_SMOKE 
#define DRAW_FIRE
#define DRAW_SNOW
#define DRAW_TREE

//*********Smoke**********  
Vector SmokeOrigin(0, ROOM_HEIGHT * 2 - 2.4, -ROOM_HEIGHT + 1);//smoke origin
ParticleList Smoke;//smoke particle list

const float SMOKE_SIZE_MIN = 0.1;
const float SMOKE_SIZE_MAX = 1.2;
const float SMOKE_SPEED_MIN = 0.03;
const float SMOKE_SPEED_MAX = 0.06;
const float SMOKE_SPIN_SPEED_MAX = 0.2;
const float SMOKE_MAX_DIST = 15;
const int   SMOKE_SEEDING_SPEED = 5;

unsigned SmokeTex;
RGBApixmap SmokePix;

//*********Fire**********
Vector FLAME(0, 0, 0.2);
Vector FireOrigin(0, -ROOM_HEIGHT + 0.72, -ROOM_HEIGHT + 1);//smoke origin
ParticleList Fire;//smoke particle list

const float FIRE_SIZE_MIN = 0.2;
const float FIRE_SIZE_MAX = 0.6;
const float FIRE_SPEED_MIN = 0.08;
const float FIRE_SPEED_MAX = 0.12;
const float FIRE_SPIN_SPEED_MAX = 0.1;
const float FIRE_MAX_DIST = 3;
const int   FIRE_SEEDING_SPEED = 8;

unsigned FireTex;
RGBApixmap FirePix;

//*********Snow**********
const float SNOW_Y_START = 100;
const float SNOW_Y_END = -ROOM_HEIGHT;
const float SNOW_X_START = -100;
const float SNOW_X_END = 100;
const float SNOW_Z_START = -100;
const float SNOW_Z_END = 100;

ParticleList Snow;//smoke particle list

const float SNOW_SIZE_MIN = 0.2;
const float SNOW_SIZE_MAX = 0.4;
const float SNOW_SPEED_RATIO = 1;
const float SNOW_SPIN_SPEED_MAX = 0.1;
const float SNOW_SPIN_MAG_MAX = 1.5;
const float SNOW_MAX_DIST = 3;
const int   SNOW_SEEDING_SPEED = 15;

unsigned SnowTex;
RGBApixmap SnowPix;

//********Trees**************
const int TREE_NUM = 250;
const float TREE_Y_PLANE = -ROOM_HEIGHT - 1.5;
const float TREE_MIN_R = 35;

const float TREE_X_START = -100;
const float TREE_X_END = 100;
const float TREE_Z_START = -100;
const float TREE_Z_END = 100;

const float TREE_SIZE_MIN = 4;
const float TREE_SIZE_MAX = 10;

struct Tree {
	float x, y, z, size;
	unsigned tex;
};

Tree tree[TREE_NUM];

const int TreeTexNum = 4;
unsigned TreeTex[TreeTexNum];
RGBApixmap TreePix[TreeTexNum];


//----------End My Variables -------------

// the camera info
float eye[3];
float lookat[3];
Vector up(0, 1, 0);

void normalize(float v[3]) {
	float l = v[0] * v[0] + v[1] * v[1] + v[2] * v[2];
	l = 1 / (float)sqrt(l);
	v[0] *= l;
	v[1] *= l;
	v[2] *= l;
}

void crossproduct(float a[3], float b[3], float res[3]) {
	res[0] = (a[1] * b[2] - a[2] * b[1]);
	res[1] = (a[2] * b[0] - a[0] * b[2]);
	res[2] = (a[0] * b[1] - a[1] * b[0]);
}

float length(float v[3]) {
	return (float)sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
}

void updateSmoke();
void updateFire();
void updateSnow();

int	main_window;
void myGlutIdle(void) {
	// make sure the main window is active
	if (glutGetWindow() != main_window)
		glutSetWindow(main_window);

	// if you have moving objects, you can do that here
#ifdef DRAW_SMOKE
	updateSmoke();
#endif

#ifdef DRAW_FIRE
	updateFire();
#endif

#ifdef DRAW_SNOW
	updateSnow();
#endif


	// just keep redrawing the scene over and over
	glutPostRedisplay();
}


// mouse handling functions for the main window
// left mouse translates, middle zooms, right rotates
// keep track of which button is down and where the last position was
int cur_button = -1;
int last_x;
int last_y;
// catch mouse up/down events
void myGlutMouse(int button, int state, int x, int y) {
	if (state == GLUT_DOWN)	cur_button = button;
	else if (button == cur_button) cur_button = -1;

	last_x = x;
	last_y = y;
}

// catch mouse move events
void myGlutMotion(int x, int y) {
	// the change in mouse position
	int dx = x - last_x;
	int dy = y - last_y;

	float scale, len, theta;
	float neye[3], neye2[3];
	float f[3], r[3], u[3];

	switch (cur_button) {
	case GLUT_LEFT_BUTTON:
		// translate
		f[0] = lookat[0] - eye[0];
		f[1] = lookat[1] - eye[1];
		f[2] = lookat[2] - eye[2];
		u[0] = 0; u[1] = 1; u[2] = 0;

		// scale the change by how far away we are
		scale = sqrt(length(f)) * 0.007;

		crossproduct(f, u, r);
		crossproduct(r, f, u);
		normalize(r);
		normalize(u);

		eye[0] += -r[0] * dx*scale + u[0] * dy*scale;
		eye[1] += -r[1] * dx*scale + u[1] * dy*scale;
		eye[2] += -r[2] * dx*scale + u[2] * dy*scale;

		lookat[0] += -r[0] * dx*scale + u[0] * dy*scale;
		lookat[1] += -r[1] * dx*scale + u[1] * dy*scale;
		lookat[2] += -r[2] * dx*scale + u[2] * dy*scale;

		break;

	case GLUT_MIDDLE_BUTTON:
		// zoom
		f[0] = lookat[0] - eye[0];
		f[1] = lookat[1] - eye[1];
		f[2] = lookat[2] - eye[2];

		len = length(f);
		normalize(f);

		// scale the change by how far away we are
		len -= sqrt(len)*dx*0.03;

		eye[0] = lookat[0] - len*f[0];
		eye[1] = lookat[1] - len*f[1];
		eye[2] = lookat[2] - len*f[2];

		// make sure the eye and lookat points are sufficiently far away
		// push the lookat point forward if it is too close
		if (len < 1) {
			printf("lookat move: %f\n", len);
			lookat[0] = eye[0] + f[0];
			lookat[1] = eye[1] + f[1];
			lookat[2] = eye[2] + f[2];
		}

		break;

	case GLUT_RIGHT_BUTTON:
		// rotate

		neye[0] = eye[0] - lookat[0];
		neye[1] = eye[1] - lookat[1];
		neye[2] = eye[2] - lookat[2];

		// first rotate in the x/z plane
		theta = -dx * 0.007;
		neye2[0] = (float)cos(theta)*neye[0] + (float)sin(theta)*neye[2];
		neye2[1] = neye[1];
		neye2[2] = -(float)sin(theta)*neye[0] + (float)cos(theta)*neye[2];

		// now rotate vertically
		theta = -dy * 0.007;

		f[0] = -neye2[0];
		f[1] = -neye2[1];
		f[2] = -neye2[2];
		u[0] = 0;
		u[1] = 1;
		u[2] = 0;
		crossproduct(f, u, r);
		crossproduct(r, f, u);
		len = length(f);
		normalize(f);
		normalize(u);

		neye[0] = len * ((float)cos(theta)*f[0] + (float)sin(theta)*u[0]);
		neye[1] = len * ((float)cos(theta)*f[1] + (float)sin(theta)*u[1]);
		neye[2] = len * ((float)cos(theta)*f[2] + (float)sin(theta)*u[2]);

		eye[0] = lookat[0] - neye[0];
		eye[1] = lookat[1] - neye[1];
		eye[2] = lookat[2] - neye[2];

		break;
	}

	//if(eye[1]< -ROOM_HEIGHT)  eye[1] = -ROOM_HEIGHT;

	last_x = x;
	last_y = y;

	glutPostRedisplay();
}

// you can put keyboard shortcuts in here
void myGlutKeyboard(unsigned char key, int x, int y) {
	switch (key) {
		// quit
	case 27:
	case 'q':
	case 'Q':
		exit(0);
		break;
	}
	glutPostRedisplay();
}

// the window has changed shapes, fix ourselves up
void myGlutReshape(int	x, int y) {
	int tx, ty, tw, th;
	GLUI_Master.get_viewport_area(&tx, &ty, &tw, &th);
	glViewport(tx, ty, tw, th);

	glutPostRedisplay();
}

void drawSmoke();
void drawFire();
void drawSnow();
void drawTrees();



// draw the scene
void myGlutDisplay() {
	glClearColor(0, 0, 0, 0);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// projection transform
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glFrustum(-1, 1, -1, 1, 1, 1000);

	// camera transform
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(eye[0], eye[1], eye[2], lookat[0], lookat[1], lookat[2], 0, 1, 0);

	//draw something here
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	drawScene();
	glDisable(GL_LIGHTING);
	glDisable(GL_LIGHT0);

#ifdef DRAW_TREE
	drawTrees();
#endif 

#ifdef DRAW_SNOW
	drawSnow();
#endif

#ifdef DRAW_SMOKE
	drawSmoke();
#endif

#ifdef DRAW_FIRE
	drawFire();
#endif

	glutSwapBuffers();
}

// some controls generate a callback when they are changed
void glui_cb(int control) {
	switch (control) {
	case 1:	break;
	}
	glutPostRedisplay();
}

void initBBTextureMaps(void) {

#ifdef DRAW_SMOKE
	glGenTextures(1, &SmokeTex);
	SmokePix.readBMPFile(".\\materials\\smoke.bmp", 50.0, 0);
	SmokePix.setTexture(SmokeTex);
#endif

#ifdef DRAW_FIRE
	glGenTextures(1, &FireTex);
	FirePix.readBMPFile(".\\materials\\fire.bmp", 50.0, 0);
	FirePix.setTexture(FireTex);
#endif

#ifdef DRAW_SNOW
	glGenTextures(1, &SnowTex);
	SnowPix.readBMPFile(".\\materials\\snow.bmp", 30.0, 0);
	SnowPix.setTexture(SnowTex);
#endif

#ifdef DRAW_TREE
	glGenTextures(TreeTexNum, TreeTex);
	TreePix[0].readBMPFile(".\\materials\\tree0.bmp", 0, 1);
	TreePix[0].setTexture(TreeTex[0]);

	TreePix[1].readBMPFile(".\\materials\\tree1.bmp", 0, 1);
	TreePix[1].setTexture(TreeTex[1]);

	TreePix[2].readBMPFile(".\\materials\\tree2.bmp", 0, 1);
	TreePix[2].setTexture(TreeTex[2]);

	TreePix[3].readBMPFile(".\\materials\\tree3.bmp", 0, 1);
	TreePix[3].setTexture(TreeTex[3]);
#endif  
}



void initLight() {
	/* Light Parameters	*/
	const float lightAmbient[] = { 0.2, 0.2, 0.2, 1.0 };
	const float lightDiffuse[] = { 0.8, 0.8, 0.8, 1.0 };
	const float lightSpecular[] = { 1, 1, 1, 1.0 };

	glLightfv(GL_LIGHT0, GL_AMBIENT, lightAmbient);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, lightDiffuse);
	glLightfv(GL_LIGHT0, GL_SPECULAR, lightSpecular);

	float lmodel_ambient[] = { 0.3, 0.3, 0.3, 1.0 };
	glLightModelfv(GL_LIGHT_MODEL_AMBIENT, lmodel_ambient);

	const float lightPos[3] = { 0, ROOM_HEIGHT - 1.5,0 };
	glLightfv(GL_LIGHT0, GL_POSITION, lightPos);
	glShadeModel(GL_SMOOTH);
}

void initTrees();

void initAll() {
	initBBTextureMaps();
	initTrees();
	initObjTextureMaps();
	initObjs();
	initLight();
}


// entry point 
void main(int argc, char **argv) { // for console application
	srand((unsigned)time(NULL));

	//
	// create the glut window
	//
	//this is init function
	glutInit(&argc, argv);

	glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);
	glutInitWindowSize(800, 600);
	glutInitWindowPosition(50, 50);
	main_window = glutCreateWindow("Particle System");

	//
	// set callbacks
	//
	glutDisplayFunc(myGlutDisplay);
	GLUI_Master.set_glutReshapeFunc(myGlutReshape);
	GLUI_Master.set_glutIdleFunc(myGlutIdle);
	GLUI_Master.set_glutKeyboardFunc(myGlutKeyboard);
	GLUI_Master.set_glutMouseFunc(myGlutMouse);
	glutMotionFunc(myGlutMotion);

	initAll();

	// initialize the camera
	eye[0] = 0;
	eye[1] = 0;
	eye[2] = 20;
	lookat[0] = 0;
	lookat[1] = 0;
	lookat[2] = 0;

	// initialize gl
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_COLOR_MATERIAL);

	// pass control to glut
	glutMainLoop();
}

int WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, char* lpCmdLine, int nCmdShow) { // for Windows application
	main(0, NULL);
	return 0;
}


//---------- SMOKE Functions -----------------------------------------------------------
void createSmoke() {
	for (int i = 0; i < SMOKE_SEEDING_SPEED; i++) {
		Particle par;
		par.pos.x = 0;
		par.pos.y = 0;
		par.pos.z = 0;
		par.size = random(SMOKE_SIZE_MIN, SMOKE_SIZE_MAX);
		par.spin = random(0, 360);
		par.spinspd = random(-SMOKE_SPIN_SPEED_MAX, SMOKE_SPIN_SPEED_MAX);
		par.color = random(1, 1);

		par.para[0] = random(3, 6.0);
		par.para[1] = random(0.4, 0.7);
		par.para[2] = random(0.2, 0.2);
		par.para[3] = random(2.0, 2.0);
		par.para[4] = random(0.2, 0.6);
		par.para[5] = random(0.5, 0.8);

		par.para[6] = random(-0.5, 0.5);
		par.para[7] = random(0.1, 0.2);
		par.para[8] = random(0.1, 0.7);
		par.para[9] = random(0.2, 0.3);
		par.para[10] = random(0.2, 1.0);

		Smoke.push(par);
	}

}

void smokeMotion(Particle &p) {
	p.pos.x += random(SMOKE_SPEED_MIN, SMOKE_SPEED_MAX);
	float x = p.pos.x;
	p.pos.y = p.para[0] * pow(x, p.para[1]) + p.para[2] * sin(p.para[3] * x) + p.para[4] * sin(p.para[5] * x);
	p.pos.z = p.para[6] * x + p.para[7] * sin(p.para[8] * x) + p.para[9] * sin(p.para[10] * x);
	p.spin += p.spinspd;
}

void updateSmoke() {
	//int i = 0;	
	ParticleNode** npp = &(Smoke.head);
	while (*npp) {
		//i++;
		smokeMotion((*npp)->par);
		if ((*npp)->par.pos.length() > SMOKE_MAX_DIST)
			Smoke.erase(npp);
		else
			npp = &((*npp)->next);
	}

	//cout << i << endl;
	createSmoke();
}

void drawSmoke() {

	Vector eyepos(eye[0], eye[1], eye[2]);

	glDisable(GL_COLOR_MATERIAL);
	glEnable(GL_DEPTH_TEST);
	glDepthMask(0);

	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	glEnable(GL_TEXTURE_2D);
	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	glBindTexture(GL_TEXTURE_2D, SmokeTex);
	ParticleNode* np = Smoke.head;
	while (np) {
		glPushMatrix();
		Particle &par = np->par;

		Vector z = SmokeOrigin + par.pos - eyepos;
		z.normalize();
		Vector x = up ^ z;
		x.normalize();
		Vector y = z ^ x;
		float rotate[16] = { x.x, x.y, x.z, 0,
							y.x, y.y, y.z, 0,
							z.x, z.y, z.z, 0,
							  0,   0,   0, 1 };
		glTranslatef(par.pos.x + SmokeOrigin.x, par.pos.y + SmokeOrigin.y, par.pos.z + SmokeOrigin.z);

		float a = (SMOKE_MAX_DIST - par.pos.length()) / SMOKE_MAX_DIST;
		float aaa = a*a*a;

		glMultMatrixf(rotate);
		glRotatef(par.spin, 0, 0, 1);

		glBegin(GL_QUADS);
		glColor4f(par.color, par.color, par.color, aaa*0.7);
		//glColor4f(1, 1, 1,1); 
		glTexCoord2f(0.0, 0.0); glVertex3f(par.size, par.size, 0);
		glTexCoord2f(1.0, 0.0); glVertex3f(-par.size, par.size, 0);
		glTexCoord2f(1.0, 1.0); glVertex3f(-par.size, -par.size, 0);
		glTexCoord2f(0.0, 1.0); glVertex3f(par.size, -par.size, 0);
		glEnd();

		glPopMatrix();
		np = np->next;
	}

	glDisable(GL_BLEND);
	glDisable(GL_TEXTURE_2D);
	glEnable(GL_COLOR_MATERIAL);
	glEnable(GL_DEPTH_TEST);
}

//---------- end SMOKE Functions ---------------


//---------- FIRE Functions ------------------------------------------------------------
void createFire() {
	for (int i = 0; i < FIRE_SEEDING_SPEED; i++) {
		Particle par;
		par.pos.x = 0;
		par.pos.y = 0;
		par.pos.z = 0;
		par.size = random(FIRE_SIZE_MIN, FIRE_SIZE_MAX);
		par.spin = random(0, 360);
		par.spinspd = random(-FIRE_SPIN_SPEED_MAX, FIRE_SPIN_SPEED_MAX);

		par.para[0] = random(0.5, 0.1); //
		par.para[1] = random(0.3, 0.1);
		par.para[2] = random(0.2, 0.2);
		par.para[3] = random(2.0, 2.0);
		par.para[4] = random(0.2, 0.6);
		par.para[5] = random(0.5, 0.8);
		float angle = random(0, PI * 2);
		par.para[6] = cos(angle);
		par.para[7] = sin(angle);

		Fire.push(par);
	}

}

void fireMotion(Particle &p) {
	p.pos.y += random(FIRE_SPEED_MIN, FIRE_SPEED_MAX);
	float y = p.pos.y;
	float r = (p.para[0] * pow(y, p.para[1]));//+p.para[2]*sin(p.para[3]*y)+p.para[4]*sin(p.para[5]*y));
	//cout << y<<"    "<<r<<endl;
	p.pos.x = r*p.para[6];
	p.pos.z = r*p.para[7];
	p.spin += p.spinspd;
}

void updateFire() {
	//int i = 0;	
	ParticleNode** npp = &(Fire.head);
	while (*npp) {
		//i++;
		fireMotion((*npp)->par);
		if ((*npp)->par.pos.length() > FIRE_MAX_DIST)
			Fire.erase(npp);
		else
			npp = &((*npp)->next);
	}
	//cout << i << endl;
	createFire();
}

void drawFire() {
	Vector eyepos(eye[0], eye[1], eye[2]);

	glDisable(GL_COLOR_MATERIAL);
	glEnable(GL_DEPTH_TEST);
	glDepthMask(0);

	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glEnable(GL_TEXTURE_2D);
	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	glBindTexture(GL_TEXTURE_2D, FireTex);

	ParticleNode* np = Fire.head;
	while (np) {
		glPushMatrix();
		Particle &par = np->par;

		Vector z = FireOrigin + par.pos - eyepos;
		z.normalize();
		Vector x = up ^ z;
		x.normalize();
		Vector y = z ^ x;
		float rotate[16] = { x.x, x.y, x.z, 0,
							y.x, y.y, y.z, 0,
							z.x, z.y, z.z, 0,
							  0,   0,   0, 1 };
		glTranslatef(par.pos.x + FireOrigin.x, par.pos.y + FireOrigin.y, par.pos.z + FireOrigin.z);

		float dist = (par.pos - FLAME).length();
		float a = (FIRE_MAX_DIST - dist) / FIRE_MAX_DIST;
		float aaa = a*a*a;

		glMultMatrixf(rotate);
		glRotatef(par.spin, 0, 0, 1);
		glBegin(GL_QUADS);
		glColor4f(a, a, a, aaa);
		glTexCoord2f(0.0, 0.0); glVertex3f(par.size, par.size, 0);
		glTexCoord2f(1.0, 0.0); glVertex3f(-par.size, par.size, 0);
		glTexCoord2f(1.0, 1.0); glVertex3f(-par.size, -par.size, 0);
		glTexCoord2f(0.0, 1.0); glVertex3f(par.size, -par.size, 0);
		glEnd();
		glPopMatrix();
		np = np->next;
	}

	glDisable(GL_BLEND);
	glDisable(GL_TEXTURE_2D);
	glEnable(GL_COLOR_MATERIAL);
	glEnable(GL_DEPTH_TEST);
	glDepthMask(1);
}

//---------- end FIRE Functions ---------------


//---------- SNOW Functions -------------------------------------------------------------
void createSnow() {
	for (int i = 0; i < SNOW_SEEDING_SPEED; i++) {
		Particle par;
		par.pos.x = random(SNOW_X_START, SNOW_Z_END);
		par.pos.y = SNOW_Y_START;
		par.pos.z = random(SNOW_Z_START, SNOW_Z_END);
		par.size = random(SNOW_SIZE_MIN, SNOW_SIZE_MAX);
		par.speed = par.size * SNOW_SPEED_RATIO;//random(SNOW_SPEED_MIN, SNOW_SPEED_MAX);

		par.spin = random(0, 360);
		par.spinspd = random(-SNOW_SPIN_SPEED_MAX, SNOW_SPIN_SPEED_MAX);
		par.spinmag = random(0, SNOW_SPIN_MAG_MAX);

		Snow.push(par);
	}

}

void snowMotion(Particle &p) {
	p.pos.y -= p.speed;
	p.pos.x += p.speed / 4.0;
	p.spin += p.spinspd;
}

const float ROOF_HEIGHT = ROOM_HEIGHT + 0.3;
void updateSnow() {
	//int i = 0;	
	ParticleNode** npp = &(Snow.head);
	while (*npp) {
		//i++;
		snowMotion((*npp)->par);
		float x = (*npp)->par.pos.x;
		float y = (*npp)->par.pos.y;
		float z = (*npp)->par.pos.z;

		if (y < SNOW_Y_END)
			Snow.erase(npp);
		else if (x > -ROOF_SIZE && x<ROOF_SIZE && z>-ROOF_SIZE && z < ROOF_SIZE && y < ROOF_HEIGHT)
			Snow.erase(npp);
		else
			npp = &((*npp)->next);
	}

	//cout << i << endl;
	createSnow();
}

void drawSnow() {

	Vector eyepos(eye[0], eye[1], eye[2]);

	glDisable(GL_COLOR_MATERIAL);
	glEnable(GL_DEPTH_TEST);
	glDepthMask(0);

	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	glEnable(GL_TEXTURE_2D);
	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
	glBindTexture(GL_TEXTURE_2D, SnowTex);

	ParticleNode* np = Snow.head;
	glColor4f(1, 1, 1, 1);
	while (np) {
		glPushMatrix();
		Particle &par = np->par;

		Vector z = par.pos - eyepos;
		z.normalize();
		Vector x = up ^ z;
		x.normalize();
		Vector y = z ^ x;
		float rotate[16] = { x.x, x.y, x.z, 0,
							y.x, y.y, y.z, 0,
							z.x, z.y, z.z, 0,
							  0,   0,   0, 1 };
		glTranslatef(par.pos.x + par.spinmag*sin(par.spin), par.pos.y, par.pos.z + par.spinmag*cos(par.spin));

		glMultMatrixf(rotate);

		glBegin(GL_QUADS);
		glTexCoord2f(0.0, 0.0); glVertex3f(par.size, par.size, 0);
		glTexCoord2f(1.0, 0.0); glVertex3f(-par.size, par.size, 0);
		glTexCoord2f(1.0, 1.0); glVertex3f(-par.size, -par.size, 0);
		glTexCoord2f(0.0, 1.0); glVertex3f(par.size, -par.size, 0);
		glEnd();

		glPopMatrix();
		np = np->next;
	}

	glDisable(GL_BLEND);
	glDisable(GL_TEXTURE_2D);
	glEnable(GL_COLOR_MATERIAL);
	glEnable(GL_DEPTH_TEST);
	glDepthMask(1);
}

//---------- end SNOW Functions -----------------------



void initTrees() {
	for (int i = 0; i < TREE_NUM; i++) {
		float x, z, r;
		do {
			x = random(TREE_X_START, TREE_X_END);
			z = random(TREE_Z_START, TREE_Z_END);
			r = sqrt(x*x + z*z);
		} while (r < TREE_MIN_R || r > 100);

		Tree& t = tree[i];
		t.size = random(TREE_SIZE_MIN, TREE_SIZE_MAX);
		t.x = x;
		t.y = TREE_Y_PLANE + t.size;
		t.z = z;
		t.tex = TreeTex[(int)random(0, TreeTexNum - 0.01)];

	}
}

void drawTrees() {
	Vector eyepos(eye[0], 0, eye[2]);

	glDisable(GL_COLOR_MATERIAL);

	glEnable(GL_TEXTURE_2D);
	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);

	glAlphaFunc(GL_GREATER, 0.5);
	glEnable(GL_ALPHA_TEST);

	for (int i = 0; i < TREE_NUM; i++) {
		glPushMatrix();
		Tree &t = tree[i];
		Vector z = Vector(t.x, t.y, t.z) - eyepos;
		z.normalize();
		Vector x = up ^ z;
		x.normalize();
		Vector y = z ^ x;
		float rotate[16] = { x.x, x.y, x.z, 0,
							y.x, y.y, y.z, 0,
							z.x, z.y, z.z, 0,
							  0,   0,   0, 1 };
		glTranslatef(tree[i].x, tree[i].y, tree[i].z);
		glMultMatrixf(rotate);//facing viewer
		glBindTexture(GL_TEXTURE_2D, t.tex);
		glBegin(GL_QUADS);
		glColor4f(1, 1, 1, 1);
		glTexCoord2f(0.0, 0.0); glVertex3f(-t.size, -t.size, 0);
		glTexCoord2f(1.0, 0.0); glVertex3f(t.size, -t.size, 0);
		glTexCoord2f(1.0, 1.0); glVertex3f(t.size, t.size, 0);
		glTexCoord2f(0.0, 1.0); glVertex3f(-t.size, t.size, 0);
		glEnd();

		glPopMatrix();
	}

	glDisable(GL_ALPHA_TEST);
	glDisable(GL_TEXTURE_2D);
	glEnable(GL_COLOR_MATERIAL);
}