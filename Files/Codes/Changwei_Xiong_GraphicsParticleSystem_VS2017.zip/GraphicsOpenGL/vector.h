/*
*  Created on: Dec 02, 2004
*  Last modified on: Nov 18, 2009
*  Author: Changwei Xiong
*  
*  Copyright (C) 2009, Changwei Xiong, 
*  axcw@hotmail.com, <http://www.cs.utah.edu/~cxiong/>
*
*  Licence: Revised BSD License
*/
 
#ifndef vector_H
#define vector_H

#include <math.h>
#include <stdlib.h>
#include <assert.h>
#include <iostream>
using namespace std;

class Vector  {
public:

	Vector() {}
	Vector(float e0, float e1, float e2) {
		x=e0; y=e1; z=e2;
	}

	Vector(const Vector &v) {
		x = v.x; y = v.y; z = v.z;
	}

	const Vector& operator+() const { return *this; }
	Vector operator-() const { return Vector(-x, -y, -z); }

	Vector& operator+=(const Vector &v2);
	Vector& operator-=(const Vector &v2);
	Vector& operator*=(const float t);
	Vector& operator/=(const float t);

	//inner product
	inline float operator%(const Vector &v){return x *v.x + y *v.y  + z *v.z;}

	float length() const { return sqrt(x*x + y*y + z*z); }
	float squaredLength() const { return x*x + y*y + z*z; }

	void normalize();

	float x,y,z;
};

inline bool operator==(const Vector &t1, const Vector &t2) {
	return ((t1.x==t2.x)&&(t1.y==t2.y)&&(t1.z==t2.z));
}

inline bool operator!=(const Vector &t1, const Vector &t2) {
	return ((t1.x!=t2.x)||(t1.y!=t2.y)||(t1.z!=t2.z));
}

inline istream &operator>>(istream &is, Vector &t) {
	is >> t.x >> t.y >> t.z;
	return is;
}

inline ostream &operator<<(ostream &os, const Vector &t) {
	os << t.x << " " << t.y << " " <<  t.z;
	return os;
}

inline Vector unit_vector(const Vector& v) {
	float k = 1.0 / sqrt(v.x*v.x + v.y*v.y + v.z*v.z);
	return Vector(v.x*k, v.y*k, v.z*k);
}

inline void Vector::normalize() {
	float k = 1.0 / sqrt(x*x + y*y + z*z);
	x *= k; y *= k; z *= k;
}

inline Vector operator+(const Vector &v1, const Vector &v2) {
	return Vector( v1.x + v2.x, v1.y + v2.y, v1.z + v2.z);
}

inline Vector operator-(const Vector &v1, const Vector &v2) {
	return Vector( v1.x - v2.x, v1.y - v2.y, v1.z - v2.z);
}

inline Vector operator*(float t, const Vector &v) {
	return Vector(t*v.x, t*v.y, t*v.z);
}

inline Vector operator*(const Vector &v, float t) {
	return Vector(t*v.x, t*v.y, t*v.z);
}


inline Vector operator*(const Vector &v1, const Vector &v2) {
	return Vector(v1.x*v2.x, v1.y*v2.y, v1.z*v2.z);
}


inline Vector operator/(const Vector &v, float t) {
	return Vector(v.x/t, v.y/t, v.z/t);
}


inline float operator%(const Vector &v1, const Vector &v2) {
	return v1.x *v2.x + v1.y *v2.y  + v1.z *v2.z;
}

inline Vector operator^(const Vector &v1, const Vector &v2) {
	return Vector( (v1.y*v2.z - v1.z*v2.y),
		(-(v1.x*v2.z - v1.z*v2.x)),
		(v1.x*v2.y - v1.y*v2.x));
}


inline Vector& Vector::operator+=(const Vector &v){
	x  += v.x;
	y  += v.y;
	z  += v.z;
	return *this;
}

inline Vector& Vector::operator-=(const Vector& v) {
	x  -= v.x;
	y  -= v.y;
	z  -= v.z;
	return *this;
}

inline Vector& Vector::operator*=(const float t) {
	x  *= t;
	y  *= t;
	z  *= t;
	return *this;
}

inline Vector& Vector::operator/=(const float t) {
	x  /= t;
	y  /= t;
	z  /= t;
	return *this;
}


#endif
