/*
*  Created on: Dec 02, 2004
*  Last modified on: Nov 18, 2009
*  Author: Changwei Xiong
*  
*  Copyright (C) 2009, Changwei Xiong, 
*  axcw@hotmail.com, <http://www.cs.utah.edu/~cxiong/>
*
*  Licence: Revised BSD License
*/
 
#include "Vector.h"

float random(float a, float b){
	return a + rand()/(float)RAND_MAX * (b-a);
}

float random(){
	return rand()/(float)RAND_MAX;
}

class Particle{
public:
	Vector pos;
	Vector vel;
	float para[11];
	float size;
	float spin;
	float spinspd;
	float spinmag;
	float speed;
	float color;
	bool live;


	Particle(){}
	
	Particle(Particle &p) {
		pos = p.pos;
		vel = p.vel;
		for(int i =0; i<11; i++)
			para[i] = p.para[i];
		size = p.size;
		spin = p.spin;
		spinspd = p.spinspd;
		spinmag = p.spinmag;
		speed = p.speed;
		color = p.color;
		live = p.live;		
	}

	Particle& operator= (Particle& p){ 
		if(this != &p){ 
			pos = p.pos;
			vel = p.vel;
			for(int i =0; i<11; i++)
				para[i] = p.para[i];
			size = p.size;
			spin = p.spin;
			spinspd = p.spinspd;
			spinmag = p.spinmag;
			speed = p.speed;
			color = p.color;
			live = p.live;	
		}          
		return *this;
	}

};

struct ParticleNode{
	int num;
	Particle par;
	ParticleNode *next;
	
};

class ParticleList{
public:
	ParticleNode* head;

	ParticleList(){ head = 0;}
	ParticleList(ParticleList &l){head = l.head;}

	void push(Particle &p){ 
		ParticleNode* node = new ParticleNode;
		node->par = p;
		node->next = head;
		head = node;
	}

	void erase(ParticleNode** p){
		ParticleNode *tmp = *p;
		*p = (*p)->next;
		delete tmp;
	}

};