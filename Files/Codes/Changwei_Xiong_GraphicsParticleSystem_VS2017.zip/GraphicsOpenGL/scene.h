/*
*  Created on: Dec 02, 2004
*  Last modified on: Nov 18, 2009
*  Author: Changwei Xiong
*  
*  Copyright (C) 2009, Changwei Xiong, 
*  axcw@hotmail.com, <http://www.cs.utah.edu/~cxiong/>
*
*  Licence: Revised BSD License
*/
 
const float ROOM_HEIGHT = 5.0;
const float GROUND_SIZE = 100.0;
const float ROOF_SIZE = ROOM_HEIGHT+0.75;

void drawScene();
void initObjTextureMaps();
void initLights();
void initObjs();
void drawRoof();
void drawLightBulb();
void drawWalls();
void drawPicture();
void drawTable();
void drawTeapot();
void drawChairs();
void drawFirePlace();
void drawFloor();
void drawLogs();
void drawPlatform();
void drawGrass();
void drawQuad(int texScale);