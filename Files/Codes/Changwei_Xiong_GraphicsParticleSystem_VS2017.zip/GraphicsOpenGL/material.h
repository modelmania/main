/*
*  Created on: Dec 02, 2004
*  Last modified on: Nov 18, 2009
*  Author: Changwei Xiong
*  
*  Copyright (C) 2009, Changwei Xiong, 
*  axcw@hotmail.com, <http://www.cs.utah.edu/~cxiong/>
*
*  Licence: Revised BSD License
*/
 

#include <GL/glui.h>

void setMaterial(int mat){

	switch (mat){
		case 0:
			//Default
			{
				float mat_ambient [] = {0.2, 0.2, 0.2, 1.0};
				float mat_diffuse [] = {0.8, 0.8, 0.8, 1.0};
				float mat_specular[] = {0.0, 0.0, 0.0, 1.0};
				float mat_emission[] = {0.0, 0.0, 0.0, 1.0};
				float shinness = 0.0;
				glMaterialfv(GL_FRONT, GL_AMBIENT,  mat_ambient);
				glMaterialfv(GL_FRONT, GL_DIFFUSE,  mat_diffuse);
				glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
				glMaterialf(GL_FRONT, GL_SHININESS, shinness);
				glMaterialfv(GL_FRONT, GL_EMISSION, mat_emission);
				glColor4f(1,1,1,1);
			}
			break;

		case 1:
			//Turquoise	for Teapot
			{
				float mat_ambient [] = {0.1, 0.18725, 0.1745, 0.8};
				float mat_diffuse [] = {0.396, 0.74151, 0.69102, 0.8} ;
				float mat_specular[] = {0.297254, 0.30829, 0.306678, 0.8};
				float mat_emission[] = {0.0, 0.0, 0.0, 1.0};
				float shinness = 102.8;
				glMaterialfv(GL_FRONT, GL_AMBIENT,  mat_ambient);
				glMaterialfv(GL_FRONT, GL_DIFFUSE,  mat_diffuse);
				glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
				glMaterialf(GL_FRONT, GL_SHININESS, shinness);
				glMaterialfv(GL_FRONT, GL_EMISSION, mat_emission);
				glColor4fv(mat_diffuse);
			}
			break;

		case 2:
			//Material for Light
			{
				float mat_ambient [] = {1.0, 1.0, 1.0, 1.0};
				float mat_diffuse [] = {1.0, 1.0, 1.0, 1.0} ;
				float mat_specular[] = {1.0, 1.0, 1.0, 1.0};
				float mat_emission[] = {1.0, 1.0, 1.0, 1.0};
				float shinness =  12.8;
				glMaterialfv(GL_FRONT, GL_AMBIENT,  mat_ambient);
				glMaterialfv(GL_FRONT, GL_DIFFUSE,  mat_diffuse);
				glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
				glMaterialf(GL_FRONT, GL_SHININESS, shinness);
				glMaterialfv(GL_FRONT, GL_EMISSION, mat_emission);
				glColor4fv(mat_diffuse);
			}
			break;

		case 3:
			//Silver
			{
				float mat_ambient [] = {0.19225, 0.19225, 0.19225, 1.0};
				float mat_diffuse [] = {0.50754, 0.50754, 0.50754, 1.0} ;
				float mat_specular[] = {0.508273, 0.508273, 0.508273, 1.0};
				float mat_emission[] = {0.0, 0.0, 0.0, 1.0};
				float shinness =  51.2;
				glMaterialfv(GL_FRONT, GL_AMBIENT,  mat_ambient);
				glMaterialfv(GL_FRONT, GL_DIFFUSE,  mat_diffuse);
				glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
				glMaterialf(GL_FRONT, GL_SHININESS, shinness);
				glMaterialfv(GL_FRONT, GL_EMISSION, mat_emission);
				glColor4fv(mat_diffuse);
			}
			break;

		case 4:
			//Gold
			{
				float mat_ambient [] = {0.24725, 0.1995, 0.0745, 1.0};
				float mat_diffuse [] = {0.75164, 0.60648, 0.22648, 1.0} ;
				float mat_specular[] = {0.628281, 0.555802, 0.366065, 1.0};
				float mat_emission[] = {0.0, 0.0, 0.0, 1.0};
				float shinness =  51.2;
				glMaterialfv(GL_FRONT, GL_AMBIENT,  mat_ambient);
				glMaterialfv(GL_FRONT, GL_DIFFUSE,  mat_diffuse);
				glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
				glMaterialf(GL_FRONT, GL_SHININESS, shinness);
				glMaterialfv(GL_FRONT, GL_EMISSION, mat_emission);
				glColor4fv(mat_diffuse);
			}
			break;

		case 5:
			//Polished Bronze
			{
				float mat_ambient [] = {0.25, 0.148, 0.06475, 1.0};
				float mat_diffuse [] = {0.4, 0.2368, 0.1036, 1.0} ;
				float mat_specular[] = {0.774597, 0.458561, 0.200621, 1.0};
				float mat_emission[] = {0.0, 0.0, 0.0, 1.0};
				float shinness =  76.8;
				glMaterialfv(GL_FRONT, GL_AMBIENT,  mat_ambient);
				glMaterialfv(GL_FRONT, GL_DIFFUSE,  mat_diffuse);
				glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
				glMaterialf(GL_FRONT, GL_SHININESS, shinness);
				glMaterialfv(GL_FRONT, GL_EMISSION, mat_emission);
				glColor4fv(mat_diffuse);
			}
			break;

		case 6:
			//Emerald
			{
				float mat_ambient [] = {0.0215, 0.1745, 0.0215, 0.55};
				float mat_diffuse [] = {0.07568, 0.61424, 0.07568, 0.55};
				float mat_specular[] = {0.633, 0.727811, 0.633, 0.55};
				float mat_emission[] = {0.0, 0.0, 0.0, 1.0};
				float shinness =76.8;
				glMaterialfv(GL_FRONT, GL_AMBIENT,  mat_ambient);
				glMaterialfv(GL_FRONT, GL_DIFFUSE,  mat_diffuse);
				glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
				glMaterialf(GL_FRONT, GL_SHININESS, shinness);
				glMaterialfv(GL_FRONT, GL_EMISSION, mat_emission);
				glColor4fv(mat_diffuse);
			}
			break;
	}

	return;
}