/*
*  Created on: Apr 15, 2003
*  Last modified on: July 28, 2016
*  Author: Changwei Xiong
*
*  Copyright (C) 2009, Changwei Xiong,
*  axcw@hotmail.com, <http://www.cs.utah.edu/~cxiong/>
*
*  Licence: Revised BSD License
*/

#include "KeyManagerForms.h"

//*******************************************************************************
//*********** KeyGenForm class ***************************************************
//*******************************************************************************
KeyGenForm::KeyGenForm(RSA* p) :
    pRSA(p) {
    pGroupBox = gcnew GroupBox;
    pLabel1 = gcnew Label;
    pLabel2 = gcnew Label;
    pLabel3 = gcnew Label;
    pComboBox = gcnew ComboBox;
    pTextBox = gcnew TextBox;
    pButton1 = gcnew Button;
    pButton2 = gcnew Button;

    StartPosition = FormStartPosition::CenterParent;
    Size = System::Drawing::Size(320, 250);
    Text = "Key Pair Generation";
    FormBorderStyle = Forms::FormBorderStyle::FixedSingle;
    MaximizeBox = 0;
    MinimizeBox = 0;
    ShowInTaskbar = false;

    //---------------- GroupBox Controls ---------------------------------------

    pGroupBox->Location = Point(15, 15);
    pGroupBox->Size = System::Drawing::Size(270, 140);
    pGroupBox->TabStop = false;
    pGroupBox->Text = "Key Pair Generator";

    pLabel1->Location = Point(15, 20);
    pLabel1->Size = System::Drawing::Size(250, 32);
    pLabel1->TabStop = false;
    pLabel1->Text = "Generate RSA key pair";

    pLabel2->Location = Point(20, 60);
    pLabel2->Size = System::Drawing::Size(110, 20);
    pLabel2->TabStop = false;
    pLabel2->Text = "Key length (in bits):";
    pLabel2->TextAlign = System::Drawing::ContentAlignment::MiddleRight;

    pLabel3->Location = Point(20, 90);
    pLabel3->Size = System::Drawing::Size(110, 20);
    pLabel3->TabStop = false;
    pLabel3->Text = "Key ID:";
    pLabel3->TextAlign = System::Drawing::ContentAlignment::MiddleRight;

    pComboBox->Location = Point(130, 60);
    pComboBox->Size = System::Drawing::Size(100, 20);
    pComboBox->DropDownStyle = ComboBoxStyle::DropDown;
    cli::array<String^>^ arrStrgs = gcnew cli::array<String^>(4);
    arrStrgs[0] = "256";
    arrStrgs[1] = "512";
    arrStrgs[2] = "768";
    arrStrgs[3] = "1024";
    pComboBox->Text = arrStrgs[0];
    pComboBox->Items->AddRange(arrStrgs);

    pTextBox->Location = Point(130, 90);
    pTextBox->Size = System::Drawing::Size(100, 20);
    pTextBox->BorderStyle = BorderStyle::FixedSingle;

    pButton1->Location = Point(100, 170);
    pButton1->Size = System::Drawing::Size(80, 20);
    pButton1->Text = "Generate...";
    pButton1->Click += gcnew EventHandler(this, &KeyGenForm::GenButtonClicked);

    pButton2->Location = Point(200, 170);
    pButton2->Size = System::Drawing::Size(80, 20);
    pButton2->Text = "Cancel";
    pButton2->Click += gcnew EventHandler(this, &KeyGenForm::ExitButtonClicked);

    pGroupBox->Controls->Add(pLabel1);
    pGroupBox->Controls->Add(pLabel2);
    pGroupBox->Controls->Add(pLabel3);
    pGroupBox->Controls->Add(pComboBox);
    pGroupBox->Controls->Add(pTextBox);

    Controls->Add(pGroupBox);
    Controls->Add(pButton1);
    Controls->Add(pButton2);
}

void KeyGenForm::ExitButtonClicked(Object^ pSender, EventArgs^) {
    DialogResult = ::DialogResult::No;
}

void KeyGenForm::GenButtonClicked(Object^ pSender, EventArgs^ args) {
    int iBits = atoi((MString(pComboBox->Text)).c_str());
    if(iBits < 256 || iBits > 1024) {
        MessageBox::Show("Key length is invalid! The key length must be between 256 and 1024 bits.",
                         "Invalid key length...",
                         MessageBoxButtons::OK,
                         MessageBoxIcon::Exclamation);
        return;
    }
    if(!pTextBox->Text->Length) {
        MessageBox::Show("Invalid key ID! Please enter a valid ID.",
                         "Invalid key ID...",
                         MessageBoxButtons::OK,
                         MessageBoxIcon::Exclamation);
        return;
    }
    this->Text = "Generating! Please stand by...";
    pGroupBox->Enabled = 0;
    pButton1->Enabled = 0;
    pLabel1->Enabled = 0;
    pLabel2->Enabled = 0;
    pLabel3->Enabled = 0;
    pComboBox->Enabled = 0;
    pTextBox->Enabled = 0;
    KeyPair newKeyPair(pRSA->keyGen((unsigned)time(NULL), iBits));
    newKeyPair.Name = MString(pTextBox->Text);
    DialogResult = (gcnew KeySaveForm(newKeyPair, pRSA))->ShowDialog();
}

//*******************************************************************************
//*********** KeyIOForm class ***************************************************
//*******************************************************************************

KeyIOForm::KeyIOForm(cli::array<String^>^ specStrgs, const unsigned uJob, RSA* p) : uJob(uJob), pRSA(p) {
    pGroupBox = gcnew GroupBox;
    pLabel1 = gcnew Label;
    pLabel2 = gcnew Label;
    pLabel3 = gcnew Label;
    pTextBox1 = gcnew TextBox;
    pTextBox2 = gcnew TextBox;
    pButton3 = gcnew Button;
    pButton1 = gcnew Button;
    pButton2 = gcnew Button;

    StartPosition = FormStartPosition::CenterParent;
    Size = System::Drawing::Size(410, 260);
    Text = specStrgs[0];
    FormBorderStyle = Forms::FormBorderStyle::FixedSingle;
    MaximizeBox = 0;
    MinimizeBox = 0;
    ShowInTaskbar = false;

    //---------------- GroupBox Controls ---------------------------------------

    pGroupBox->Location = Point(12, 15);
    pGroupBox->Size = System::Drawing::Size(370, 150);
    pGroupBox->TabStop = false;
    pGroupBox->Text = specStrgs[0];

    pLabel1->Location = Point(25, 20);
    pLabel1->Size = System::Drawing::Size(320, 32);
    pLabel1->TabStop = false;
    pLabel1->Text = specStrgs[1];

    pLabel2->Location = Point(15, 70);
    pLabel2->Size = System::Drawing::Size(80, 20);
    pLabel2->TabStop = false;
    pLabel2->Text = specStrgs[2];
    pLabel2->TextAlign = System::Drawing::ContentAlignment::MiddleRight;

    pLabel3->Location = Point(15, 100);
    pLabel3->Size = System::Drawing::Size(80, 20);
    pLabel3->TabStop = false;
    pLabel3->Text = specStrgs[3];
    pLabel3->TextAlign = System::Drawing::ContentAlignment::MiddleRight;

    pTextBox1->Location = Point(105, 70);
    pTextBox1->Size = System::Drawing::Size(160, 20);
    pTextBox1->BorderStyle = BorderStyle::FixedSingle;

    pTextBox2->Location = Point(105, 100);
    pTextBox2->Size = System::Drawing::Size(160, 20);
    pTextBox2->PasswordChar = uJob > 1 ? 0 : 42;
    pTextBox2->BorderStyle = BorderStyle::FixedSingle;
    pTextBox2->Text = nullptr;

    pButton3->Location = Point(275, 70);
    pButton3->Size = System::Drawing::Size(60, 20);
    pButton3->Text = "Browse...";
    pButton3->Click += gcnew EventHandler(this, &KeyIOForm::BrsButtonClicked);

    pGroupBox->Controls->Add(pLabel1);
    pGroupBox->Controls->Add(pLabel2);
    pGroupBox->Controls->Add(pLabel3);
    pGroupBox->Controls->Add(pButton3);
    pGroupBox->Controls->Add(pTextBox1);
    pGroupBox->Controls->Add(pTextBox2);

    //--------------------------------------------

    pButton1->Location = Point(180, 180);
    pButton1->Size = System::Drawing::Size(80, 20);
    pButton1->Text = specStrgs[4];
    pButton1->Click += gcnew EventHandler(this, &KeyIOForm::DoButtonClicked);

    pButton2->Location = Point(285, 180);
    pButton2->Size = System::Drawing::Size(80, 20);
    pButton2->Text = "Cancel";
    pButton2->Click += gcnew EventHandler(this, &KeyIOForm::ExitButtonClicked);

    Controls->Add(pGroupBox);
    Controls->Add(pButton1);
    Controls->Add(pButton2);
}

void KeyIOForm::ExitButtonClicked(Object^ pSender, EventArgs^) {
    Close();
}

void KeyIOForm::BrsButtonClicked(Object^ pSender, EventArgs^) {
    if(uJob == 1) { // open key state file, ".ks"
        OpenFileDialog^ pOFDialog = gcnew OpenFileDialog;
        pOFDialog->InitialDirectory = System::Windows::Forms::Application::StartupPath;
        pOFDialog->Filter = "key-state file (*.ks)|*.ks|All files (*.*)|*.*";
        pOFDialog->ShowDialog();
        if(pOFDialog->FileName->Length)
            pTextBox1->Text = pOFDialog->FileName;
    }
    if(uJob == 2) { // open public key file, ".txt"
        OpenFileDialog^ pOFDialog = gcnew OpenFileDialog;
        pOFDialog->InitialDirectory = System::Windows::Forms::Application::StartupPath;
        pOFDialog->Filter = "key file (*.txt)|*.txt|All files (*.*)|*.*";
        pOFDialog->ShowDialog();
        if(pOFDialog->FileName->Length)
            pTextBox1->Text = pOFDialog->FileName;
    }
    if(uJob == 3) {  // save public key file, ".txt"
        SaveFileDialog^ pSFDialog = gcnew SaveFileDialog;
        pSFDialog->InitialDirectory = System::Windows::Forms::Application::StartupPath;
        pSFDialog->Filter = "key file (*.txt)|*.txt|All files (*.*)|*.*";
        pSFDialog->ShowDialog();
        if(pSFDialog->FileName->Length)
            pTextBox1->Text = pSFDialog->FileName;
    }
}

void KeyIOForm::DoButtonClicked(Object^ pSender, EventArgs^) {
    //---------- 1. Import key states -------------------------------------
    if(uJob == 1) {
        FileInfo^ pFileInfoInput;
        try {
            pFileInfoInput = gcnew FileInfo(pTextBox1->Text);
        } catch(...) {
            MessageBox::Show("Filename is invalid!",
                             "Invalid filename...",
                             MessageBoxButtons::OK,
                             MessageBoxIcon::Exclamation);
            return;
        }
        if(!pFileInfoInput->Exists) {
            MessageBox::Show("Filename is invalid!",
                             "Invalid filename...",
                             MessageBoxButtons::OK,
                             MessageBoxIcon::Exclamation);
            return;
        }
        if(!pTextBox2->Text->Length) {
            MessageBox::Show("Password is invalid!",
                             "Invalid password...",
                             MessageBoxButtons::OK,
                             MessageBoxIcon::Exclamation);
            return;
        }

        Enabled = 0;
        Text = "Please stand by...";
        Refresh();

        KeyPair masterKey = pRSA->keyGen(pRSA->hashString(MString(pTextBox2->Text)), 768);
        FileStream^ pFileStreamInput = gcnew FileStream(pTextBox1->Text, FileMode::Open);
        BinaryReader^ pBinaryReader = gcnew BinaryReader(pFileStreamInput);
        Key MDKey("", masterKey.D, masterKey.N);
        string sKeyPairInfo;
        int nLength = masterKey.N.bits();
        int eBytes = (nLength - 1) / 8;
        int dBytes = nLength % 8 ? (nLength / 8 + 1) : (nLength / 8);
        cli::array<unsigned char>^ In = gcnew cli::array<unsigned char>(eBytes);
        cli::array<unsigned char>^ Out = gcnew cli::array<unsigned char>(dBytes);
        while(1) {
            try {
                Out = pBinaryReader->ReadBytes(dBytes);
                if(Out->Length == 0)
                    break;
                pRSA->Cryptize(Out, In, MDKey);
                sKeyPairInfo += toStr(In);
            } catch(...) {
                break;
            }
        }
        pBinaryReader->Close();

        int g[5];
        for(int i = 0, p = 0, length = sKeyPairInfo.length(); i < length; i++) {
            if(sKeyPairInfo[i] == 5)
                g[p++] = i + 1;
            if(p > 4)
                break;
        }
        if(MString(pTextBox2->Text) != sKeyPairInfo.substr(0, g[0] - 1)) {
            MessageBox::Show("Invalid password!",
                             "Invalid Password...",
                             MessageBoxButtons::OK,
                             MessageBoxIcon::Exclamation);
            pTextBox1->Enabled = 1;
            pTextBox2->Enabled = 1;
            pButton1->Enabled = 1;
            pButton2->Enabled = 1;
            pButton3->Enabled = 1;
            Enabled = 1;
            return;
        }
        KeyPair tmpKP(sKeyPairInfo.substr(g[0], g[1] - g[0] - 1),
                      sKeyPairInfo.substr(g[1], g[2] - g[1] - 1),
                      sKeyPairInfo.substr(g[2], g[3] - g[2] - 1),
                      sKeyPairInfo.substr(g[3], g[4] - g[3] - 1));
        bool found = 0;
        for(int i = 0, size = pRSA->PubKey.size(); i < size; i++) {
            if(tmpKP.Name == pRSA->PubKey[i].Name) {
                found = 1;
                break;
            }
        }
        if(found == 0) {
            for(int i = 0, size = pRSA->SecKey.size(); i < size; i++)
                if(tmpKP.Name == pRSA->SecKey[i].Name) {
                    found = 1;
                    break;
                }
        }
        if(found == 0) {
            pRSA->PubKey.push_back(Key(tmpKP.Name, tmpKP.E, tmpKP.N));
            pRSA->SecKey.push_back(Key(tmpKP.Name, tmpKP.D, tmpKP.N));
            MessageBox::Show("Key pair loaded successfully!",
                             "Key pair loaded...",
                             MessageBoxButtons::OK,
                             MessageBoxIcon::Asterisk);
            DialogResult = ::DialogResult::Yes;
        } else {
            MessageBox::Show("Duplicate names found in key buffer! Loading skipped...",
                             "Name Conflict...",
                             MessageBoxButtons::OK,
                             MessageBoxIcon::Exclamation);
            DialogResult = ::DialogResult::No;
        }
    }
    //---------- 1. import public key --------------------------------------------
    if(uJob == 2) {
        FileInfo^ pFileInfoInput;
        try {
            pFileInfoInput = gcnew FileInfo(pTextBox1->Text);
        } catch(...) {
            MessageBox::Show("Filename is invalid!",
                             "Invalid filename...",
                             MessageBoxButtons::OK,
                             MessageBoxIcon::Exclamation);
            return;
        }

        if(!pFileInfoInput->Exists) {
            MessageBox::Show("Filename is invalid!",
                             "Invalid filename...",
                             MessageBoxButtons::OK,
                             MessageBoxIcon::Exclamation);
            return;
        }

        if(!pTextBox2->Text->Length) {
            MessageBox::Show("Key ID is invalid!",
                             "Invalid key ID...",
                             MessageBoxButtons::OK,
                             MessageBoxIcon::Exclamation);
            return;
        }

        Enabled = 0;
        Text = "Please stand by...";
        Refresh();

        FileStream^ pFileStreamInput = gcnew FileStream(pTextBox1->Text, FileMode::Open);
        BinaryReader^ pBinaryReader = gcnew BinaryReader(pFileStreamInput);
        unsigned char ch = 0;
        string strE, strN;
        bool tag = 1;
        while(1) {
            try {
                ch = pBinaryReader->ReadByte();
                if(33 == ch) {
                    tag = 0;
                    continue;
                }
                if(tag)
                    strE += ch;
                else
                    strN += ch;
            } catch(EndOfStreamException^ e) {
                (e);
                break;
            } catch(...) {
                break;
            }
        }

        pBinaryReader->Close();
        Key tmpKey(MString(pTextBox2->Text), BI(strE), BI(strN));
        if(tmpKey.N == 0) {
            MessageBox::Show("Invalid key file!",
                             "Key importing failed...",
                             MessageBoxButtons::OK,
                             MessageBoxIcon::Information);
            Enabled = 1;
            return;
        }

        for(int i = 0, size = pRSA->PubKey.size(); i < size; i++) {
            if(tmpKey.Name == pRSA->PubKey[i].Name) {
                MessageBox::Show("Duplicated key ID! The key ID must be unique in buffer.",
                                 "Duplicated key ID...",
                                 MessageBoxButtons::OK,
                                 MessageBoxIcon::Exclamation);
                Enabled = 1;
                return;
            }
        }

        pRSA->PubKey.push_back(tmpKey);
        MessageBox::Show("Key imported successfully!",
                         "Key Imported...",
                         MessageBoxButtons::OK,
                         MessageBoxIcon::Asterisk);
        DialogResult = ::DialogResult::Yes;
    }
    //------------ 3. export public key -------------------------------------------
    if(uJob == 3) {
        FileInfo^ pFileInfoOutput;
        try {
            pFileInfoOutput = gcnew FileInfo(pTextBox1->Text);
        } catch(...) {
            MessageBox::Show("Filename is invalid!",
                             "Invalid filename...",
                             MessageBoxButtons::OK,
                             MessageBoxIcon::Exclamation);
            return;
        }
        if(!pTextBox2->Text->Length) {
            MessageBox::Show("Key ID is invalid!",
                             "Invalid Key ID...",
                             MessageBoxButtons::OK,
                             MessageBoxIcon::Exclamation);
            return;
        }

        Key EKey;
        string keyName = MString(pTextBox2->Text);
        for(int i = 0, size = pRSA->PubKey.size(); i < size; i++)
            if((pRSA->PubKey[i]).Name == keyName)
                EKey = pRSA->PubKey[i];
        if(EKey.N == 0) {
            MessageBox::Show("Could not find the key in the buffer!",
                             "Export public key failed...",
                             MessageBoxButtons::OK,
                             MessageBoxIcon::Exclamation);
            return;
        }

        Enabled = 0;
        Text = "Please stand by...";
        Refresh();

        FileStream^ pFileStreamOutput;
        if(pFileInfoOutput->Exists)
            pFileStreamOutput = gcnew FileStream(pTextBox1->Text, FileMode::Truncate);
        else
            pFileStreamOutput = gcnew FileStream(pTextBox1->Text, FileMode::CreateNew);
        BinaryWriter^ pBinaryWriter = gcnew BinaryWriter(pFileStreamOutput);

        pBinaryWriter->Write(toArr(EKey.ED.toString()));
        pBinaryWriter->Write(unsigned char(33));
        pBinaryWriter->Write(toArr(EKey.N.toString()));
        pBinaryWriter->Close();
        pButton1->Enabled = true;
        MessageBox::Show("Key exported successfully!",
                         "Key exported...",
                         MessageBoxButtons::OK,
                         MessageBoxIcon::Asterisk);
        Close();
    }
}

//*******************************************************************************
//*********** KeySaveForm class *************************************************
//*******************************************************************************

KeySaveForm::KeySaveForm(const KeyPair& tmpkey, RSA* p) :
    rKeyPair(tmpkey), pRSA(p) {
    pGroupBox = gcnew GroupBox;
    pLabel1 = gcnew Label;
    pLabel2 = gcnew Label;
    pLabel3 = gcnew Label;
    pLabel4 = gcnew Label;
    pTextBox1 = gcnew TextBox;
    pTextBox2 = gcnew TextBox;
    pTextBox3 = gcnew TextBox;
    pCheckBox = gcnew CheckBox;
    pButton3 = gcnew Button;
    pButton1 = gcnew Button;
    pButton2 = gcnew Button;

    StartPosition = FormStartPosition::CenterParent;
    Size = System::Drawing::Size(430, 280);
    Text = "Save Key Pair";
    FormBorderStyle = Forms::FormBorderStyle::FixedSingle;
    MaximizeBox = 0;
    MinimizeBox = 0;
    ShowInTaskbar = false;

    //---------------- GroupBox Controls ---------------------------------------

    pGroupBox->Location = Point(12, 15);
    pGroupBox->Size = System::Drawing::Size(400, 165);
    pGroupBox->TabStop = false;
    pGroupBox->Text = "Save Key Pair";

    pLabel4->Location = Point(30, 20);
    pLabel4->Size = System::Drawing::Size(320, 32);
    pLabel4->TabStop = false;
    pLabel4->Text = "Save key pair in an encrypted key-state (.ks) file";

    pLabel1->Location = Point(5, 60);
    pLabel1->Size = System::Drawing::Size(70, 20);
    pLabel1->TabStop = false;
    pLabel1->Text = "Save As:";
    pLabel1->TextAlign = System::Drawing::ContentAlignment::MiddleRight;

    pLabel2->Location = Point(5, 90);
    pLabel2->Size = System::Drawing::Size(120, 20);
    pLabel2->TabStop = false;
    pLabel2->Text = "Password:";
    pLabel2->TextAlign = System::Drawing::ContentAlignment::MiddleRight;

    pLabel3->Location = Point(5, 120);
    pLabel3->Size = System::Drawing::Size(120, 20);
    pLabel3->TabStop = false;
    pLabel3->Text = "Retype Password:";
    pLabel3->TextAlign = System::Drawing::ContentAlignment::MiddleRight;

    pTextBox1->Location = Point(75, 60);
    pTextBox1->Size = System::Drawing::Size(240, 20);
    pTextBox1->BorderStyle = BorderStyle::FixedSingle;
    pTextBox1->Text = gcnew System::String(tmpkey.Name.c_str()) + ".ks";

    pTextBox2->Location = Point(125, 90);
    pTextBox2->Size = System::Drawing::Size(150, 20);
    pTextBox2->PasswordChar = 42;
    pTextBox2->BorderStyle = BorderStyle::FixedSingle;
    pTextBox2->Text = "";

    pTextBox3->Location = Point(125, 120);
    pTextBox3->Size = System::Drawing::Size(150, 20);
    pTextBox3->PasswordChar = 42;
    pTextBox3->BorderStyle = BorderStyle::FixedSingle;
    pTextBox3->Text = "";

    pButton3->Location = Point(325, 60);
    pButton3->Size = System::Drawing::Size(60, 20);
    pButton3->Text = "Browse...";
    pButton3->Click += gcnew EventHandler(this, &KeySaveForm::BrsButtonClicked);

    pGroupBox->Controls->Add(pLabel4);
    pGroupBox->Controls->Add(pLabel1);
    pGroupBox->Controls->Add(pLabel2);
    pGroupBox->Controls->Add(pLabel3);
    pGroupBox->Controls->Add(pButton3);
    pGroupBox->Controls->Add(pTextBox1);
    pGroupBox->Controls->Add(pTextBox2);
    pGroupBox->Controls->Add(pTextBox3);

    //--------------------------------------------
    pCheckBox->Location = Point(30, 185);
    pCheckBox->Size = System::Drawing::Size(370, 20);
    pCheckBox->Text = "Import a key pair into buffer";
    pCheckBox->AutoCheck = true;
    pCheckBox->Checked = true;

    pButton1->Location = Point(210, 215);
    pButton1->Size = System::Drawing::Size(90, 20);
    pButton1->Text = "Save";
    pButton1->Click += gcnew EventHandler(this, &KeySaveForm::SaveButtonClicked);

    pButton2->Location = Point(310, 215);
    pButton2->Size = System::Drawing::Size(90, 20);
    pButton2->Text = "Cancel";
    pButton2->Click += gcnew EventHandler(this, &KeySaveForm::ExitButtonClicked);

    Controls->Add(pGroupBox);
    Controls->Add(pCheckBox);
    Controls->Add(pButton1);
    Controls->Add(pButton2);
}

void KeySaveForm::BrsButtonClicked(Object^ pSender, EventArgs^) {
    SaveFileDialog^ pSFDialog = gcnew SaveFileDialog;
    pSFDialog->InitialDirectory = System::Windows::Forms::Application::StartupPath;
    pSFDialog->Filter = "Key-state file (*.ks)|*.ks|All files (*.*)|*.*";
    pSFDialog->ShowDialog();
    if(pSFDialog->FileName->Length)
        pTextBox1->Text = pSFDialog->FileName;
}

void KeySaveForm::SaveButtonClicked(Object^ pSender, EventArgs^) {
    FileInfo^ pFileInfoOutput;
    try {
        pFileInfoOutput = gcnew FileInfo(pTextBox1->Text);
    } catch(...) {
        MessageBox::Show("Filename is invalid!",
                         "Invalid filename...",
                         MessageBoxButtons::OK,
                         MessageBoxIcon::Exclamation);
        return;
    }

    if(!pTextBox2->Text->Length) {
        MessageBox::Show("Password is invalid! Please enter a valid Password.",
                         "Invalid Password...",
                         MessageBoxButtons::OK,
                         MessageBoxIcon::Exclamation);
        return;
    }
    if(pTextBox3->Text->CompareTo(pTextBox2->Text)) {
        pTextBox2->Text = "";
        pTextBox3->Text = "";
        MessageBox::Show("Entries do not match! Try again...",
                         "Invalid Password...",
                         MessageBoxButtons::OK,
                         MessageBoxIcon::Exclamation);
        return;
    }

    Enabled = 0;
    Refresh();

    Text = "Please stand by...";
    string sKeyPairInfo = MString(pTextBox2->Text) + char(5)
                          + rKeyPair.Name + char(5)
                          + rKeyPair.E.toString() + char(5)
                          + rKeyPair.D.toString() + char(5)
                          + rKeyPair.N.toString() + char(5);
    KeyPair masterKey = pRSA->keyGen(pRSA->hashString(MString(pTextBox2->Text)), 768);
    int nLength = masterKey.N.bits();
    int eBytes = (nLength - 1) / 8;
    int dBytes = nLength % 8 ? (nLength / 8 + 1) : (nLength / 8);
    cli::array<unsigned char>^ In = gcnew cli::array<unsigned char>(eBytes);
    cli::array<unsigned char>^ Out = gcnew cli::array<unsigned char>(dBytes);

    FileStream^ pFileStreamOutput;
    if(pFileInfoOutput->Exists)
        pFileStreamOutput = gcnew FileStream(pTextBox1->Text, FileMode::Truncate);
    else
        pFileStreamOutput = gcnew FileStream(pTextBox1->Text, FileMode::CreateNew);
    BinaryWriter^ pBinaryWriter = gcnew BinaryWriter(pFileStreamOutput);

    Key MEKey("", masterKey.E, masterKey.N);
    int m = sKeyPairInfo.length() / eBytes;
    for(int i = 0; i < m; i++) {
        for(int j = 0; j < eBytes; j++) In[j] = sKeyPairInfo[i * eBytes + j];
        pRSA->Cryptize(In, Out, MEKey);
        pBinaryWriter->Write(Out);
    }
    int r = sKeyPairInfo.length() % eBytes;
    for(int j = 0; j < r; j++)
        In[j] = sKeyPairInfo[m * eBytes + j];
    pRSA->Cryptize(In, Out, MEKey);
    pBinaryWriter->Write(Out);
    pBinaryWriter->Flush();
    pBinaryWriter->Close();
    MessageBox::Show("Key pair saved successfully!",
                     "Key Pair Saved...",
                     MessageBoxButtons::OK,
                     MessageBoxIcon::Asterisk);
    if(1 == pCheckBox->Checked) {
        bool found = 0;
        for(int i = 0, size = pRSA->PubKey.size(); i < size; i++) {
            if(rKeyPair.Name == pRSA->PubKey[i].Name) {
                found = 1;
                break;
            }
        }
        if(found == 0) {
            for(int i = 0, size = pRSA->SecKey.size(); i < size; i++)
                if(rKeyPair.Name == pRSA->SecKey[i].Name) {
                    found = 1;
                    break;
                }
        }
        if(found == 0) {
            pRSA->PubKey.push_back(Key(rKeyPair.Name, rKeyPair.E, rKeyPair.N));
            pRSA->SecKey.push_back(Key(rKeyPair.Name, rKeyPair.D, rKeyPair.N));
            DialogResult = ::DialogResult::Yes;
        } else {
            MessageBox::Show("Duplicate names found in key buffer! Loading skipped...",
                             "Name Conflict...",
                             MessageBoxButtons::OK,
                             MessageBoxIcon::Exclamation);
            DialogResult = ::DialogResult::No;
        }
    } else DialogResult = ::DialogResult::No;
}

void KeySaveForm::ExitButtonClicked(Object^ pSender, EventArgs^) {
    DialogResult = ::DialogResult::No;
}

