/*
*  Created on: Apr 15, 2003
*  Last modified on: July 28, 2016
*  Author: Changwei Xiong
*
*  Copyright (C) 2009, Changwei Xiong,
*  axcw@hotmail.com, <http://www.cs.utah.edu/~cxiong/>
*
*  Licence: Revised BSD License
*/

#ifndef KEYMANAGERFORMS_H_
#define KEYMANAGERFORMS_H_

#include "rsa.h" 
//*********** KeyGenForm class ***************************************************

ref class KeyGenForm : public Form {
public:
	KeyGenForm(RSA*);

private:
	RSA* pRSA;

	void ExitButtonClicked(Object^, EventArgs^);
	void GenButtonClicked(Object^, EventArgs^);

	GroupBox
		^pGroupBox;
	Label
		^pLabel1,
		^pLabel2,
		^pLabel3;
	ComboBox
		^pComboBox;
	TextBox
		^pTextBox;
	Button
		^pButton1,
		^pButton2;
};

//*********** KeyIOForm class *****************************************

ref class KeyIOForm : public Form {
public:
	KeyIOForm(cli::array<String^>^, const unsigned, RSA*);

private:
	RSA* pRSA;
	unsigned uJob;

	void BrsButtonClicked(Object^, EventArgs^);
	void DoButtonClicked(Object^, EventArgs^);
	void ExitButtonClicked(Object^, EventArgs^);

	GroupBox
		^pGroupBox;
	Label
		^pLabel1,
		^pLabel2,
		^pLabel3;
	TextBox
		^pTextBox1,
		^pTextBox2;
	Button
		^pButton1,
		^pButton2,
		^pButton3;
};

//*********** KeySaveForm class **************************************

ref class KeySaveForm : public Form {
public:
	KeySaveForm(const KeyPair&, RSA*);

private:
	RSA* pRSA;
	const KeyPair& rKeyPair;

	void BrsButtonClicked(Object^, EventArgs^);
	void ExitButtonClicked(Object^, EventArgs^);
	void SaveButtonClicked(Object^, EventArgs^);

	GroupBox
		^pGroupBox;
	Label
		^pLabel1,
		^pLabel2,
		^pLabel3,
		^pLabel4;
	TextBox
		^pTextBox1,
		^pTextBox2,
		^pTextBox3;
	CheckBox
		^pCheckBox;
	Button
		^pButton1,
		^pButton2,
		^pButton3;
};

#endif KEYMANAGERFORMS_H_