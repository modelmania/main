/*
*  Created on: Apr 15, 2003
*  Last modified on: July 28, 2016
*  Author: Changwei Xiong
*
*  Copyright (C) 2009, Changwei Xiong,
*  axcw@hotmail.com, <http://www.cs.utah.edu/~cxiong/>
*
*  Licence: Revised BSD License
*/

#ifndef MAINFORM_H_
#define MAINFORM_H_

#include "FileHandlerDlg.h"
#include "KeyManagerForms.h"

public ref class MainForm : public Form {
public:
	MainForm();
	~MainForm();

private:
	RSA* pRSA;
	TabControl
		^pTabControl;
	TabPage
		^pTabPage1,
		^pTabPage2;
	GroupBox
		^pGroupBox11,
		^pGroupBox12,
		^pGroupBox13,
		^pGroupBox21,
		^pGroupBox22,
		^pGroupBox;
	Label
		^pLabel11,
		^pLabel12,
		^pLabel13,
		^pLabel21,
		^pLabel22,
		^pLabel1,
		^pLabel2,
		^pLabel3,
		^pLabel4;
	Button
		^pButton11,
		^pButton12,
		^pButton13,
		^pButton14;
	Button
		^pButton21,
		^pButton22,
		^pButton23,
		^pButton24;
	Button
		^pButton;

	void RefreshStatusBar();
	void ExitBtnClicked(Object^, EventArgs^);
	void FileMgrClicked(Object^, EventArgs^);
	void KeyMgrClicked(Object^, EventArgs^);
};


#endif MAINFORM_H_