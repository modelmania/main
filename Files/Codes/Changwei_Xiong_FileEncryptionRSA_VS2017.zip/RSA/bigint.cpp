// Written by Joe Zachary, February 2003.

// Change log:

// Feb 26, 22:28: Fixed bug in >> operator
#include "bigint.h"
using namespace std;


////////////////////////////////////////////////////////////
// These are helper functions that deal with the arrays   //
// that represent the base 2^32 numbers that are used to  //
// represent BigInts.                                     //
////////////////////////////////////////////////////////////

// Min

inline int min(int a, int b) {
    return (a < b) ? a : b;
}


// Max

inline int max(int a, int b) {
    return (a > b) ? a : b;
}


// Absolute value

inline int absval(int n) {
    if(n < 0) return -n;
    return n;
}


// Sign of n*m.  Both must be non-zero.

inline int sign(int n, int m) {
    if(n > 0) {
        if(m > 0) return 1;
        else return -1;
    } else {
        if(m > 0) return -1;
        else return 1;
    }
}



// Returns a newly-allocated zero with room for the specified
// number of limbs.

mp_limb_t* newLimbs(size_t limbs) {
    mp_limb_t* N = new mp_limb_t[limbs];
    for(size_t i = 0; i < limbs; i++) {
        N[i] = 0;
    }
    return N;
}



// Returns a copy.  The number of limbs is specified.

mp_limb_t* copyLimbs(mp_limb_t* N, int limbs) {
    mp_limb_t* copy = new mp_limb_t[limbs];
    for(int i = 0; i < limbs; i++) {
        copy[i] = N[i];
    }
    return copy;
}


// Returns the number of limbs, not containing any leading zeroes.

int strip(mp_limb_t* N, int limbs) {
    while(limbs > 0) {
        if(N[limbs - 1] != 0) break;
        limbs--;
    }
    return limbs;
}



// Returns the number of bits that follow the highest-order "1"
// (including that high-order bit).  The limbs parameter is the number
// of limbs in the number.

int getBits(mp_limb_t* N, int limbs) {
    if(limbs == 0) return 0;
    int nbits = limbs * 32;
    mp_limb_t highOrder = N[limbs - 1];
    while((highOrder & 0x80000000) == 0) {
        nbits--;
        highOrder <<= 1;
    }
    return nbits;
}


// Does an unsigned comparison.  -1 means lhs is smaller, +1 means lhs
// is bigger, 0 means lhs and rhs are equal.  The limb lengths must
// be non-negative.

int comp(mp_limb_t* lhs, int lhsLimbs, mp_limb_t* rhs, int rhsLimbs) {
    if(lhsLimbs < rhsLimbs) return -1;
    if(lhsLimbs > rhsLimbs) return 1;
    if(lhsLimbs == 0) return 0;
    return mpn_cmp(lhs, rhs, lhsLimbs);
}


////////////////////////////////////////////////////////////
// Constructors.                                          //
////////////////////////////////////////////////////////////


// Zero

BigInt::BigInt() {
    N = newLimbs(0);
    limbs = 0;
    refcount = new unsigned int;
    *refcount = 1;
}



// Convert from long

BigInt::BigInt(long n) {
    if(n == 0) {
        N = newLimbs(0);
        limbs = 0;
    } else if(n > 0) {
        N = newLimbs(1);
        N[0] = n;
        limbs = 1;
    } else {
        N = newLimbs(1);
        N[0] = -n;
        limbs = -1;
    }
    refcount = new unsigned int;
    *refcount = 1;
}


// Convert to long.

long BigInt::toLong() const {
    if(limbs == 0) {
        return 0;
    } else if(limbs > 0) {
        return N[0];
    } else {
        return -long(N[0]);
    }
}


// Convert from string.  If there's a mistake in the string,
// constructs zero.

BigInt::BigInt(const string &s) {

    // Determine the sign
    int index = 0;
    int sign = 1;
    if(s.size() > 0) {
        if(s[index] == '+') {
            index++;
        } else if(s[index] == '-') {
            sign = -1;
            index++;
        }
    }

    // Build up the number.  If there's a mistake, construct zero.

    // Determine, at most, how many 32-bit limbs are needed to hold
    // all the digits.  9 digits per limb is a conservative estimate.
    size_t size = (s.size() - index) / 9 + 1;
    N = newLimbs(size);
    refcount = new unsigned int;
    *refcount = 1;

    // Build up the number one digit at a time.  If there's a mistake
    // along the way, construct zero instead.
    limbs = 0;
    for(size_t i = index; i < s.size(); i++) {

        // Deal only with valid digits
        if(s[i] >= '0' && s[i] <= '9') {

            // Deal with the first digit as a special case.  The mpn methods
            // below don't like limb sizes of zero.
            if(limbs == 0) {
                if(s[i] != '0') N[limbs++] = s[i] - '0';
            }

            // Deal with successive digits by multplying by 10 and adding
            // the digit in.  Only if there is a carry out does the limb
            // size increase.
            else {
                mp_limb_t carry = mpn_mul_1(N, N, limbs, 10);
                if(carry != 0) N[limbs++] = carry;
                carry = mpn_add_1(N, N, limbs, s[i] - '0');
                if(carry != 0) N[limbs++] = carry;
            }
        }

        // If a non-digit is encountered, construct zero.
        else {
            delete N;
            N = newLimbs(0);
            limbs = 0;
            return;
        }
    }

    // Finish construction
    limbs = sign * limbs;

}


////////////////////////////////////////////////////////////
// Non-operator member functions.                         //
////////////////////////////////////////////////////////////


int BigInt::bits() const {
    return getBits(N, absval(limbs));
}


int BigInt::compare(const BigInt &num) const {
    if(limbs < num.limbs) return -1;
    if(limbs > num.limbs) return 1;
    if(limbs > 0) return mpn_cmp(N, num.N, limbs);
    if(limbs < 0) return mpn_cmp(num.N, N, -limbs);
    return 0;
}


string BigInt::toString() const {

    // Deal with zero
    int limbs = absval(this->limbs);
    if(limbs == 0) return "0";

    // Generate digits by repeated division.
    mp_limb_t* quotient = copyLimbs(N, limbs);
    string result = "";
    do {
        mp_limb_t remainder = mpn_divmod_1(quotient, quotient, limbs, 10);
        result = char('0' + remainder) + result;
        limbs = strip(quotient, limbs);
    } while(limbs != 0);

    // Generate a sign if necessary and we're done.
    if(this->limbs < 0) result = "-" + result;
    delete quotient;
    return result;

}


////////////////////////////////////////////////////////////
// Operator member functions.                             //
////////////////////////////////////////////////////////////

// Bit extraction

bool BigInt::operator [](int index) const {
    if(index < 0 || index / 32 >= absval(limbs)) return false;
    mp_limb_t num = N[index / 32];
    index = index % 32;
    while(index-- > 0) num = num >> 1;
    return (num & 1) != 0;
}



// Bit shifting with assignment.

const BigInt &BigInt::operator <<= (int bits) {
    return *this = *this << bits;
}

const BigInt &BigInt::operator >>= (int bits) {
    return *this = *this >> bits;
}


// Bit shifting without assignment.

BigInt BigInt::operator << (int bits) const {

    // Deal with zero or negative shifts.
    if(bits == 0) return *this;
    if(bits < 0) return *this >> -bits;

    // If the number is zero, return *this.
    int limbs = absval(this->limbs);
    if(limbs == 0) return *this;

    // Otherwise, shift by a combination of full limbs and bits.
    int limbsToShift = bits / 32;
    int bitsToShift = bits % 32;

    mp_limb_t* shifted;
    if(bitsToShift > 0) {
        shifted = newLimbs(limbs + limbsToShift + 1);
        mpn_lshift(shifted + limbsToShift, N, limbs, bitsToShift);
        mp_limb_t carry = N[limbs - 1] >> (32 - bits);
        if(carry > 0) {
            shifted[limbs + limbsToShift] = carry;
            limbs++;
        }
    }

    else {
        shifted = newLimbs(limbs + limbsToShift);
        for(int i = 0; i < limbs; i++) {
            shifted[limbsToShift + i] = N[i];
        }
    }

    limbs += limbsToShift;
    if(this->limbs > 0) {
        return BigInt(shifted, limbs);
    } else {
        return BigInt(shifted, -limbs);
    }

}


BigInt BigInt::operator >> (int bits) const {

    // Deal with zero or negative shifts.
    if(bits == 0) return *this;
    if(bits < 0) return *this << -bits;

    // If the number is zero; return *this;
    int limbs = absval(this->limbs);
    if(limbs == 0) return *this;

    // If all the limbs are being shifted away, return zero.
    int limbsToShift = bits / 32;
    int bitsToShift = bits % 32;
    if(limbsToShift >= limbs) {
        return BigInt();
    }

    // Otherwise, shift by a combination of full limbs and bits.
    mp_limb_t* shifted;
    if(bitsToShift > 0) {
        shifted = newLimbs(limbs - limbsToShift);
        mpn_rshift(shifted, N + limbsToShift, limbs - limbsToShift, bitsToShift);
    }

    else {
        shifted = newLimbs(limbs - limbsToShift);
        for(int i = 0; i < limbs - limbsToShift; i++) {
            shifted[i] = N[i + limbsToShift];
        }
    }

    limbs = strip(shifted, limbs - limbsToShift);
    if(this->limbs > 0) {
        return BigInt(shifted, limbs);
    } else {
        return BigInt(shifted, -limbs);
    }

}


// Binary arithmetic with assignment.

const BigInt &BigInt::operator += (const BigInt &num) {
    return *this = *this + num;
}



const BigInt &BigInt::operator -= (const BigInt &num) {
    return *this = *this - num;
}


const BigInt &BigInt::operator *= (const BigInt &num) {
    return *this = *this * num;
}



const BigInt &BigInt::operator /= (const BigInt &divisor) {
    return *this = *this / divisor;
}


const BigInt &BigInt::operator %= (const BigInt &divisor) {
    return *this = *this % divisor;
}



const BigInt &BigInt::operator |= (const BigInt &bits) {
    return *this = *this | bits;
}


const BigInt &BigInt::operator &= (const BigInt &bits) {
    return *this = *this & bits;
}


const BigInt &BigInt::operator ^= (const BigInt &bits) {
    return *this = *this ^ bits;
}



// Unary arithmetic and logic

BigInt BigInt::operator + () const {
    return *this;
}


BigInt BigInt::operator - () const {
    return BigInt(copyLimbs(N, absval(limbs)), -limbs);
}


BigInt BigInt::operator ~() const {
    int limbs = absval(this->limbs);
    if(limbs == 0) return *this;

    mp_limb_t* comp = newLimbs(limbs);
    for(int i = 0; i < limbs; i++) {
        comp[i] = ~N[i];
    }
    if(this->limbs > 0) {
        return BigInt(comp, strip(comp, limbs));
    } else {
        return BigInt(comp, -strip(comp, limbs));
    }
}



// Increment and decrement

const BigInt &BigInt::operator ++ () {
    *this += 1;
    return *this;
}

const BigInt &BigInt::operator -- () {
    *this -= 1;
    return *this;
}

BigInt BigInt::operator ++ (int) {
    BigInt result = *this;
    *this += 1;
    return result;
}

BigInt BigInt::operator -- (int) {
    BigInt result = *this;
    *this -= 1;
    return result;
}



////////////////////////////////////////////////////////////
// Operator friends.                                      //
////////////////////////////////////////////////////////////


// Input/output

ostream &operator << (ostream &out, const BigInt &bi) {
    out << bi.toString();
    return out;
}



istream &operator >> (istream &in, BigInt &bi) {

    // Strip white space
    char c;
    do {
        c = (char)cin.get();
    } while(c == ' ' || c == '\n' || c == '\t' || c == '\r');

    // Read an optional sign.
    string result;
    if(c == '+' || c == '-') {
        result += c;
        c = (char)cin.get();
    }

    // Now read an arbitrary number of digits.
    while(c >= '0' && c <= '9') {
        result += c;
        c = (char)cin.get();
    }

    // Put back the last character read and construct the BigInt.
    cin.putback(c);
    bi = BigInt(result);
    return cin;

}


// Binary arithmetic

BigInt operator + (const BigInt &lhs, const BigInt &rhs) {

    // Extract the information we need
    int lhsLimbs = lhs.limbs;
    int rhsLimbs = rhs.limbs;
    mp_limb_t* lhsN = lhs.N;
    mp_limb_t* rhsN = rhs.N;

    // lhs is zero
    if(lhsLimbs == 0) return rhs;

    // rhs is zero
    if(rhsLimbs == 0) return lhs;

    // Both are positive
    if(lhsLimbs > 0 && rhsLimbs > 0) {
        mp_limb_t* N = newLimbs(lhsLimbs + rhsLimbs + 1);
        if(lhsLimbs >= rhsLimbs) {
            mp_limb_t carry = mpn_add(N, lhsN, lhsLimbs, rhsN, rhsLimbs);
            if(carry) N[lhsLimbs++] = carry;
            return BigInt(N, lhsLimbs);
        } else {
            mp_limb_t carry = mpn_add(N, rhsN, rhsLimbs, lhsN, lhsLimbs);
            if(carry) N[rhsLimbs++] = carry;
            return BigInt(N, rhsLimbs);
        }
    }

    // Both are negative
    if(lhsLimbs < 0 && rhsLimbs < 0) {
        lhsLimbs = absval(lhsLimbs);
        rhsLimbs = absval(rhsLimbs);
        mp_limb_t* N = newLimbs(lhsLimbs + rhsLimbs + 1);
        if(lhsLimbs >= rhsLimbs) {
            mp_limb_t carry = mpn_add(N, lhsN, lhsLimbs, rhsN, rhsLimbs);
            if(carry) N[lhsLimbs++] = carry;
            return BigInt(N, -lhsLimbs);
        } else {
            mp_limb_t carry = mpn_add(N, rhsN, rhsLimbs, lhsN, lhsLimbs);
            if(carry) N[rhsLimbs++] = carry;
            return BigInt(N, -rhsLimbs);
        }
    }

    // LHS is positive, RHS is negative
    if(lhsLimbs > 0) {
        rhsLimbs = absval(rhsLimbs);
        if(comp(lhsN, lhsLimbs, rhsN, rhsLimbs) >= 0) {
            mp_limb_t* N = newLimbs(lhsLimbs);
            mpn_sub(N, lhsN, lhsLimbs, rhsN, rhsLimbs);
            return BigInt(N, strip(N, lhsLimbs));
        } else {
            mp_limb_t* N = newLimbs(rhsLimbs);
            mpn_sub(N, rhsN, rhsLimbs, lhsN, lhsLimbs);
            return BigInt(N, -strip(N, rhsLimbs));
        }
    }

    // LHS is negative, RHS is positive
    else {
        lhsLimbs = absval(lhsLimbs);
        if(comp(rhsN, rhsLimbs, lhsN, lhsLimbs) >= 0) {
            mp_limb_t* N = newLimbs(rhsLimbs);
            mpn_sub(N, rhsN, rhsLimbs, lhsN, lhsLimbs);
            return BigInt(N, strip(N, rhsLimbs));
        } else {
            mp_limb_t* N = newLimbs(lhsLimbs);
            mpn_sub(N, lhsN, lhsLimbs, rhsN, rhsLimbs);
            return BigInt(N, -strip(N, lhsLimbs));
        }
    }

}


BigInt operator - (const BigInt &lhs, const BigInt &rhs) {

    // Extract the information we need
    int lhsLimbs = lhs.limbs;
    int rhsLimbs = rhs.limbs;
    mp_limb_t* lhsN = lhs.N;
    mp_limb_t* rhsN = rhs.N;

    // lhs is zero
    if(lhsLimbs == 0) return -rhs;

    // rhs is zero
    if(rhsLimbs == 0) return lhs;

    // Both are positive
    if(lhsLimbs > 0 && rhsLimbs > 0) {
        if(comp(lhsN, lhsLimbs, rhsN, rhsLimbs) >= 0) {
            mp_limb_t* N = newLimbs(lhsLimbs);
            mpn_sub(N, lhsN, lhsLimbs, rhsN, rhsLimbs);
            return BigInt(N, strip(N, lhsLimbs));
        } else {
            mp_limb_t* N = newLimbs(rhsLimbs);
            mpn_sub(N, rhsN, rhsLimbs, lhsN, lhsLimbs);
            return BigInt(N, -strip(N, rhsLimbs));
        }
    }

    // Both are negative
    if(lhsLimbs < 0 && rhsLimbs < 0) {
        lhsLimbs = absval(lhsLimbs);
        rhsLimbs = absval(rhsLimbs);
        if(comp(lhsN, lhsLimbs, rhsN, rhsLimbs) >= 0) {
            mp_limb_t* N = newLimbs(lhsLimbs);
            mpn_sub(N, lhsN, lhsLimbs, rhsN, rhsLimbs);
            return BigInt(N, -strip(N, lhsLimbs));
        } else {
            mp_limb_t* N = newLimbs(rhsLimbs);
            mpn_sub(N, rhsN, rhsLimbs, lhsN, lhsLimbs);
            return BigInt(N, strip(N, rhsLimbs));
        }
    }

    // LHS is positive, RHS is negative
    if(lhsLimbs > 0) {
        rhsLimbs = absval(rhsLimbs);
        mp_limb_t* N = newLimbs(lhsLimbs + rhsLimbs + 1);
        if(lhsLimbs >= rhsLimbs) {
            mp_limb_t carry = mpn_add(N, lhsN, lhsLimbs, rhsN, rhsLimbs);
            if(carry) N[lhsLimbs++] = carry;
            return BigInt(N, lhsLimbs);
        } else {
            mp_limb_t carry = mpn_add(N, rhsN, rhsLimbs, lhsN, lhsLimbs);
            if(carry) N[rhsLimbs++] = carry;
            return BigInt(N, rhsLimbs);
        }
    }

    // LHS is negative, RHS is positive
    else {
        lhsLimbs = absval(lhsLimbs);
        mp_limb_t* N = newLimbs(lhsLimbs + rhsLimbs + 1);
        if(lhsLimbs >= rhsLimbs) {
            mp_limb_t carry = mpn_add(N, lhsN, lhsLimbs, rhsN, rhsLimbs);
            if(carry) N[lhsLimbs++] = carry;
            return BigInt(N, -lhsLimbs);
        } else {
            mp_limb_t carry = mpn_add(N, rhsN, rhsLimbs, lhsN, lhsLimbs);
            if(carry) N[rhsLimbs++] = carry;
            return BigInt(N, -rhsLimbs);
        }
    }

}


BigInt operator * (const BigInt &lhs, const BigInt &rhs) {

    // Extract the information we need
    int lhsLimbs = absval(lhs.limbs);
    int rhsLimbs = absval(rhs.limbs);

    // One of the operands is zero.
    if(lhsLimbs == 0 || rhsLimbs == 0) return BigInt();

    // Do an unsigned multiplication and then adjust the sign.
    mp_limb_t* N = newLimbs(lhsLimbs + rhsLimbs);
    if(lhsLimbs >= rhsLimbs) {
        mpn_mul(N, lhs.N, lhsLimbs, rhs.N, rhsLimbs);
    } else {
        mpn_mul(N, rhs.N, rhsLimbs, lhs.N, lhsLimbs);
    }
    int limbs = strip(N, lhsLimbs + rhsLimbs);
    return BigInt(N, limbs * sign(lhs.limbs, rhs.limbs));

}


BigInt operator / (const BigInt &lhs, const BigInt &rhs) {

    // Extract the information we need
    int lhsLimbs = absval(lhs.limbs);
    int rhsLimbs = absval(rhs.limbs);

    // Generate an error for a zero divisor
    if(rhsLimbs == 0) {
        int n = lhs.limbs / rhs.limbs;
    }

    // Return zero for a smaller dividend.
    else if(lhsLimbs < rhsLimbs) {
        return BigInt();
    }

    // Do an unsigned division and then adjust the sign.
    mp_limb_t* quotient = newLimbs(lhsLimbs);
    mp_limb_t* remainder = newLimbs(rhsLimbs);
    mpn_tdiv_qr(quotient, remainder, 0, lhs.N, lhsLimbs, rhs.N, rhsLimbs);
    delete remainder;
    int limbs = strip(quotient, lhsLimbs - rhsLimbs + 1);
    return BigInt(quotient, limbs * sign(lhs.limbs, rhs.limbs));

}



BigInt operator % (const BigInt &lhs, const BigInt &rhs) {

    // Extract the information we need
    int lhsLimbs = absval(lhs.limbs);
    int rhsLimbs = absval(rhs.limbs);

    // Generate an error for a zero divisor
    if(rhsLimbs == 0) {
        int n = lhs.limbs / rhs.limbs;
    }

    // Return the dividend for a smaller dividend.
    else if(lhsLimbs < rhsLimbs) {
        return lhs;
    }

    // Do an unsigned division and then adjust the sign.
    mp_limb_t* quotient = newLimbs(lhsLimbs);
    mp_limb_t* remainder = newLimbs(rhsLimbs);
    mpn_tdiv_qr(quotient, remainder, 0, lhs.N, lhsLimbs, rhs.N, rhsLimbs);
    delete quotient;
    int limbs = strip(remainder, rhsLimbs);
    return BigInt(remainder, limbs * sign(lhs.limbs, rhs.limbs));

}



BigInt operator | (const BigInt &num1, const BigInt &num2) {

    // Test for zero.
    int num1Limbs = absval(num1.limbs);
    int num2Limbs = absval(num2.limbs);
    if(num1.limbs == 0) return num2;
    if(num2.limbs == 0) return num1;
    mp_limb_t* num1N = num1.N;
    mp_limb_t* num2N = num2.N;

    // Do bitwise or-ing.
    mp_limb_t* result = newLimbs(max(num1Limbs, num2Limbs));
    int i = 0;
    for(i = 0; i < min(num1Limbs, num2Limbs); i++) {
        result[i] = num1N[i] | num2N[i];
    }
    while(i < num1Limbs) {
        result[i] = num1N[i];
        i++;
    }
    while(i < num2Limbs) {
        result[i] = num2N[i];
        i++;
    }

    // Use the sign of the first number.
    if(num1.limbs > 0) {
        return BigInt(result, max(num1Limbs, num2Limbs));
    } else {
        return BigInt(result, -max(num1Limbs, num2Limbs));
    }


}


BigInt operator & (const BigInt &num1, const BigInt &num2) {

    // Test for zero.
    int num1Limbs = absval(num1.limbs);
    int num2Limbs = absval(num2.limbs);
    if(num1.limbs == 0) return BigInt();
    if(num2.limbs == 0) return BigInt();
    mp_limb_t* num1N = num1.N;
    mp_limb_t* num2N = num2.N;

    // Do bitwise and-ing.
    mp_limb_t* result = newLimbs(min(num1Limbs, num2Limbs));
    int i = 0;
    for(i = 0; i < min(num1Limbs, num2Limbs); i++) {
        result[i] = num1N[i] & num2N[i];
    }

    // Use the sign of the first number.
    if(num1.limbs > 0) {
        return BigInt(result, strip(result, i));
    } else {
        return BigInt(result, -strip(result, i));
    }

}


BigInt operator ^ (const BigInt &num1, const BigInt &num2) {

    // Test for zero.
    int num1Limbs = absval(num1.limbs);
    int num2Limbs = absval(num2.limbs);
    if(num1.limbs == 0) return num2;
    if(num2.limbs == 0) return num1;
    mp_limb_t* num1N = num1.N;
    mp_limb_t* num2N = num2.N;


    // Do bitwise or-ing.
    mp_limb_t* result = newLimbs(max(num1Limbs, num2Limbs));
    int i = 0;
    for(i = 0; i < min(num1Limbs, num2Limbs); i++) {
        result[i] = num1N[i] ^ num2N[i];
    }
    while(i < num1Limbs) {
        result[i] = num1N[i];
        i++;
    }
    while(i < num2Limbs) {
        result[i] = num2N[i];
        i++;
    }

    // Use the sign of the first number.
    if(num1.limbs > 0) {
        return BigInt(result, strip(result, i));
    } else {
        return BigInt(result, -strip(result, i));
    }

}


// Binary comparison

bool operator == (const BigInt &lhs, const BigInt &rhs) {
    return lhs.compare(rhs) == 0;
}


bool operator < (const BigInt &lhs, const BigInt &rhs) {
    return lhs.compare(rhs) < 0;
}


bool operator > (const BigInt &lhs, const BigInt &rhs) {
    return lhs.compare(rhs) > 0;
}


bool operator != (const BigInt &lhs, const BigInt &rhs) {
    return lhs.compare(rhs) != 0;
}


bool operator >= (const BigInt &lhs, const BigInt &rhs) {
    return lhs.compare(rhs) >= 0;
}


bool operator <= (const BigInt &lhs, const BigInt &rhs) {
    return lhs.compare(rhs) <= 0;
}




/*
BigInt fact (BigInt n) {
  BigInt product = 1;
  while (n > 0) {
    product *= n--;
  }
  return product;
}

int main () {
  BigInt n;
  cin >> n;
  cout << fact(n) << endl;
  cin.ignore();
  return 0;
}
*/



