// Written by Joe Zachary, February 2003.
#ifndef BIGINT_H_
#define BIGINT_H_

#include "gmp.h"
#include <iostream>
#include <string>
using namespace std;


// Arbitrary precision integers, using a sign/magnitude
// representation.  Except for this difference, which will be apparent
// only when doing bit manipulations, you can use BigInts exactly as
// you use regular ints.

class BigInt {

  public:

    // Zero
    BigInt();

    // Convert from long.
    BigInt(long);

    // Convert from string.  If the string is ill-formatted, the
    // constructed number is zero.
    BigInt(const string &);

    // Destructor
    ~BigInt() {
        (*refcount)--;
        if(*refcount == 0) {
            delete refcount;
            delete N;
        }
    }

    // Copy constructor
    BigInt(const BigInt &bi) {
        N = bi.N;
        limbs = bi.limbs;
        refcount = bi.refcount;
        (*refcount)++;
    }


    // Assignment operator
    BigInt &operator = (const BigInt &bi) {
        if(this == &bi) return *this;
        (*refcount)--;
        if(*refcount == 0) {
            delete refcount;
            delete N;
        }
        N = bi.N;
        limbs = bi.limbs;
        refcount = bi.refcount;
        (*refcount)++;
        return *this;
    }

    // Number of bits.
    int bits() const;

    // Comparison (-1 less than, 0 equal, 1 greater than)
    int compare(const BigInt &num) const;

    // Converts to string form
    string toString() const;

    // Converts to long if the BigInt is small enough
    long toLong() const;

    // True if the specified bit is 1, false otherwise.  Bits are
    // indexed from zero, beginning with the least significant bit.
    // An index out of range always returns false.
    bool operator [](int index) const;

    // Unary operators
    BigInt operator + () const;
    BigInt operator - () const;
    BigInt operator ~() const;

    // Integer-valued binary operators with assignment
    const BigInt &operator += (const BigInt &);
    const BigInt &operator -= (const BigInt &);
    const BigInt &operator *= (const BigInt &);
    const BigInt &operator /= (const BigInt &);
    const BigInt &operator %= (const BigInt &);
    const BigInt &operator |= (const BigInt &);
    const BigInt &operator &= (const BigInt &);
    const BigInt &operator ^= (const BigInt &);

    // Increment/decrement operators
    const BigInt &operator ++ ();
    BigInt operator ++ (int);
    const BigInt &operator -- ();
    BigInt operator -- (int);

    // Bit shifting, with and without assignment.
    BigInt operator << (int bits) const;
    BigInt operator >> (int bits) const;
    const BigInt &operator <<= (int bits);
    const BigInt &operator >>= (int bits);

    // Integer-valued binary operators
    friend BigInt operator + (const BigInt &, const BigInt &);
    friend BigInt operator - (const BigInt &, const BigInt &);
    friend BigInt operator * (const BigInt &, const BigInt &);
    friend BigInt operator / (const BigInt &, const BigInt &);
    friend BigInt operator % (const BigInt &, const BigInt &);
    friend BigInt operator | (const BigInt &, const BigInt &);
    friend BigInt operator & (const BigInt &, const BigInt &);
    friend BigInt operator ^ (const BigInt &, const BigInt &);

  private:

    unsigned int* refcount;  // Reference count for N

    int limbs;      // Number of limbs (base 2^32 digits).  If the
    // number is negative, the negative of the number
    // digits is stored.

    mp_limb_t* N;   // The limbs, beginning with the low-order ones


    BigInt(mp_limb_t* N, int limbs) {
        this->N = N;
        this->limbs = limbs;
        refcount = new unsigned int;
        *refcount = 1;
    }

};






// Comparisons
bool operator == (const BigInt & lhs, const BigInt & rhs);
bool operator < (const BigInt & lhs, const BigInt & rhs);
bool operator != (const BigInt & lhs, const BigInt & rhs);
bool operator > (const BigInt & lhs, const BigInt & rhs);
bool operator >= (const BigInt & lhs, const BigInt & rhs);
bool operator <= (const BigInt & lhs, const BigInt & rhs);


// I/O operators
ostream &operator << (ostream &, const BigInt &);
istream &operator >> (istream &, BigInt &);

#endif BIGINT_H_

