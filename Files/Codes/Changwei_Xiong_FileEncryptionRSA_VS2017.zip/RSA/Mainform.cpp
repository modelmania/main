/*
*  Created on: Apr 15, 2003
*  Last modified on: July 28, 2016
*  Author: Changwei Xiong
*
*  Copyright (C) 2009, Changwei Xiong,
*  axcw@hotmail.com, <http://www.cs.utah.edu/~cxiong/>
*
*  Licence: Revised BSD License
*/

#include "MainForm.h"


MainForm::~MainForm() {
    delete pRSA;
}

MainForm::MainForm() {
    pRSA = new RSA;

    pTabControl = gcnew TabControl();
    pTabPage1 = gcnew TabPage();
    pGroupBox11 = gcnew GroupBox;
    pGroupBox12 = gcnew GroupBox;
    pGroupBox13 = gcnew GroupBox;
    pLabel11 = gcnew Label;
    pLabel12 = gcnew Label;
    pLabel13 = gcnew Label;
    pButton11 = gcnew Button;
    pButton12 = gcnew Button;
    pButton13 = gcnew Button;
    pButton14 = gcnew Button;
    pTabPage2 = gcnew TabPage;
    pGroupBox21 = gcnew GroupBox;
    pGroupBox22 = gcnew GroupBox;
    pLabel21 = gcnew Label;
    pLabel22 = gcnew Label;
    pButton21 = gcnew Button;
    pButton22 = gcnew Button;
    pButton23 = gcnew Button;
    pButton24 = gcnew Button;
    pButton = gcnew Button;
    pGroupBox = gcnew GroupBox;
    pLabel1 = gcnew Label;
    pLabel2 = gcnew Label;
    pLabel3 = gcnew Label;
    pLabel4 = gcnew Label;

    FormBorderStyle = ::FormBorderStyle::FixedSingle;
    Size = ::Size::Size(440, 510);
    MaximizeBox = 0;
    StartPosition = FormStartPosition::CenterScreen;
    Text = "RSA File Encryption/Decryption";

    //this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
    this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Dpi;

    //----------- Form Controls -------------------------------------------
    pButton->Location = Point(290, 432);
    pButton->Size = System::Drawing::Size(100, 22);
    pButton->Text = "Exit";
    pButton->Click += gcnew EventHandler(this, &MainForm::ExitBtnClicked);

    pGroupBox->Location = Point(19, 365);
    pGroupBox->Size = System::Drawing::Size(380, 60);
    pGroupBox->FlatStyle = FlatStyle::Standard;
    pGroupBox->Text = "Key Buffer";

    pLabel1->Location = Point(3, 15);
    pLabel1->Size = System::Drawing::Size(47, 16);
    pLabel1->TextAlign = System::Drawing::ContentAlignment::MiddleRight;
    pLabel1->Text = "Public:";

    pLabel2->Location = Point(3, 33);
    pLabel2->Size = System::Drawing::Size(47, 16);
    pLabel2->TextAlign = System::Drawing::ContentAlignment::MiddleRight;
    pLabel2->Text = "Private:";

    pLabel3->Location = Point(50, 15);
    pLabel3->Size = System::Drawing::Size(320, 16);
    pLabel4->TextAlign = System::Drawing::ContentAlignment::MiddleLeft;
    pLabel3->Text = "(N/A)";

    pLabel4->Location = Point(50, 33);
    pLabel4->Size = System::Drawing::Size(320, 16);
    pLabel4->TextAlign = System::Drawing::ContentAlignment::MiddleLeft;
    pLabel4->Text = "(N/A)";

    pGroupBox->Controls->Add(pLabel1);
    pGroupBox->Controls->Add(pLabel2);
    pGroupBox->Controls->Add(pLabel3);
    pGroupBox->Controls->Add(pLabel4);

    pTabControl->Location = Point(10, 6);
    pTabControl->Size = System::Drawing::Size(400, 352);
    pTabControl->Multiline = true;
    pTabControl->Padding = Point(15, 6);
    pTabControl->SizeMode = TabSizeMode::Fixed;
    pTabPage1->TabIndex = 1;
    pTabPage2->TabIndex = 2;
    pTabControl->Controls->Add(pTabPage1);
    pTabControl->Controls->Add(pTabPage2);

    Controls->Add(pGroupBox);
    Controls->Add(pButton);
    Controls->Add(pTabControl);

    //------------------  TapPage1 Controls  ----------------------------
    pTabPage1->Text = "Key Management";

    //-------------GroupBox1------------------
    pGroupBox11->Location = Point(15, 8);
    pGroupBox11->Size = System::Drawing::Size(360, 95);
    pGroupBox11->FlatStyle = FlatStyle::Standard;
    pGroupBox11->Text = "RSA Key Generation";

    pButton11->Location = Point(220, 60);
    pButton11->Size = System::Drawing::Size(120, 22);
    pButton11->Text = "RSA Key";
    pButton11->Click += gcnew EventHandler(this, &MainForm::KeyMgrClicked);

    pLabel11->Location = Point(20, 20);
    pLabel11->Size = System::Drawing::Size(320, 32);
    pLabel11->TextAlign = System::Drawing::ContentAlignment::MiddleLeft;
    pLabel11->Text = "Generate RSA public/private key pair, and export it as a key state (.ks) file";

    //pLabel11->BorderStyle = Forms::BorderStyle::Fixed3D;

    pGroupBox11->Controls->Add(pButton11);
    pGroupBox11->Controls->Add(pLabel11);

    //-------------GroupBox2------------------
    pGroupBox12->Location = Point(15, 111);
    pGroupBox12->Size = System::Drawing::Size(360, 95);
    pGroupBox12->FlatStyle = FlatStyle::Standard;
    pGroupBox12->Text = "Key State Loading";

    pButton12->Location = Point(220, 60);
    pButton12->Size = System::Drawing::Size(120, 22);
    pButton12->Text = "Import Key State";
    pButton12->Click += gcnew EventHandler(this, &MainForm::KeyMgrClicked);

    pLabel12->Location = Point(20, 20);
    pLabel12->Size = System::Drawing::Size(320, 32);
    pLabel12->TextAlign = System::Drawing::ContentAlignment::MiddleLeft;
    pLabel12->Text = "Import a key pair from a key-state file into buffer";

    pGroupBox12->Controls->Add(pLabel12);
    pGroupBox12->Controls->Add(pButton12);

    //-------------GroupBox3------------------
    pGroupBox13->Location = Point(15, 214);
    pGroupBox13->Size = System::Drawing::Size(360, 95);
    pGroupBox13->FlatStyle = FlatStyle::Standard;
    pGroupBox13->Text = "Public Key Import and Export";

    pButton13->Location = Point(80, 60);
    pButton13->Size = System::Drawing::Size(120, 22);
    pButton13->Text = "Import Public Key";
    pButton13->Click += gcnew EventHandler(this, &MainForm::KeyMgrClicked);

    pButton14->Location = Point(220, 60);
    pButton14->Size = System::Drawing::Size(120, 22);
    pButton14->Text = "Export Public Key";
    pButton14->Click += gcnew EventHandler(this, &MainForm::KeyMgrClicked);

    pLabel13->Location = Point(20, 20);
    pLabel13->Size = System::Drawing::Size(320, 32);
    pLabel13->TextAlign = System::Drawing::ContentAlignment::MiddleLeft;
    pLabel13->Text = "Import a public key to key buffer from a text file \nExport a public key from key buffer to a text file";

    pGroupBox13->Controls->Add(pButton13);
    pGroupBox13->Controls->Add(pButton14);
    pGroupBox13->Controls->Add(pLabel13);

    //------------------------------------------
    pTabPage1->Controls->Add(pGroupBox11);
    pTabPage1->Controls->Add(pGroupBox12);
    pTabPage1->Controls->Add(pGroupBox13);

    //------------------  TapPage 2 Controls---------------------------------

    pTabPage2->Text = "File Processing";

    //-------------GroupBox1------------------
    pGroupBox21->Location = Point(15, 20);
    pGroupBox21->Size = System::Drawing::Size(360, 130);
    ;
    pGroupBox21->FlatStyle = FlatStyle::Standard;
    pGroupBox21->Text = "File Encrypting and Decrypting";

    pButton21->Location = Point(120, 90);
    pButton21->Size = System::Drawing::Size(100, 25);
    pButton21->Text = "Encrypt File";
    pButton21->Click += gcnew EventHandler(this, &MainForm::FileMgrClicked);

    pButton22->Location = Point(240, 90);
    pButton22->Size = System::Drawing::Size(100, 25);
    pButton22->Text = "Decrypt File";
    pButton22->Click += gcnew EventHandler(this, &MainForm::FileMgrClicked);

    pLabel21->Location = Point(20, 20);
    pLabel21->Size = System::Drawing::Size(330, 64);
    pLabel21->TextAlign = System::Drawing::ContentAlignment::TopLeft;
    pLabel21->Text = "Encrypt a file by a public key in key buffer\nDecrypt a file by a private key in key buffer";

    pGroupBox21->Controls->Add(pButton21);
    pGroupBox21->Controls->Add(pButton22);
    pGroupBox21->Controls->Add(pLabel21);
    //-------------GroupBox2------------------
    pGroupBox22->Location = Point(15, 170);
    pGroupBox22->Size = System::Drawing::Size(360, 130);
    ;
    pGroupBox22->FlatStyle = FlatStyle::Standard;
    pGroupBox22->Text = "File Signing and Verifying";

    pLabel22->Location = Point(20, 20);
    pLabel22->Size = System::Drawing::Size(330, 64);
    pLabel22->TextAlign = System::Drawing::ContentAlignment::TopLeft;
    pLabel22->Text = "Sign a file by a private key in key buffer\nVerify a signed file by a public key in key buffer";

    pButton23->Location = Point(120, 90);
    pButton23->Size = System::Drawing::Size(100, 25);
    pButton23->Text = "Sign File";
    pButton23->Click += gcnew EventHandler(this, &MainForm::FileMgrClicked);

    pButton24->Location = Point(240, 90);
    pButton24->Size = System::Drawing::Size(100, 25);
    pButton24->Text = "Verify File";
    pButton24->Click += gcnew EventHandler(this, &MainForm::FileMgrClicked);

    pGroupBox22->Controls->Add(pButton23);
    pGroupBox22->Controls->Add(pButton24);
    pGroupBox22->Controls->Add(pLabel22);
    //--------------------------------------
    pTabPage2->Controls->Add(pGroupBox21);
    pTabPage2->Controls->Add(pGroupBox22);
}

void MainForm::KeyMgrClicked(Object^ pSender, EventArgs^) {
    if(pSender == pButton11)
        if(::DialogResult::Yes == (gcnew KeyGenForm(pRSA))->ShowDialog())
            RefreshStatusBar();
    if(pSender == pButton12) {
        cli::array<String^>^ specStrgs = gcnew cli::array<String^>(5);
        specStrgs[0] = "Import Key State";
        specStrgs[1] = "Import a key pair into key buffer.\nPlease provide a key-state (.ks) file and the password.";
        specStrgs[2] = "Filename:";
        specStrgs[3] = "Password:";
        specStrgs[4] = "Import";
        KeyIOForm^ kioform = gcnew KeyIOForm(specStrgs, 1, pRSA);
        if(::DialogResult::Yes == kioform->ShowDialog())
            RefreshStatusBar();
    }
    if(pSender == pButton13) {
        cli::array<String^>^ specStrgs = gcnew cli::array<String^>(5);
        specStrgs[0] = "Import Public Key";
        specStrgs[1] = "Import a public key to key buffer from a key file.\nPlease provide a public key file and a name as the key ID.";
        specStrgs[2] = "Filename:";
        specStrgs[3] = "Public Key ID:";
        specStrgs[4] = "Import";
        KeyIOForm^ kioform = gcnew KeyIOForm(specStrgs, 2, pRSA);
        if(::DialogResult::Yes == kioform->ShowDialog())
            RefreshStatusBar();
    }
    if(pSender == pButton14) {
        cli::array<String^>^ specStrgs = gcnew cli::array<String^>(5);
        specStrgs[0] = "Export Public Key";
        specStrgs[1] = "Export a public key to a file from key buffer.\nPlease provide the key ID and the filename.";
        specStrgs[2] = "Filename:";
        specStrgs[3] = "Public Key ID:";
        specStrgs[4] = "Export";
        KeyIOForm^ kioform = gcnew KeyIOForm(specStrgs, 3, pRSA);
        kioform->ShowDialog();
    }
}

//------------------  Events  ---------------------------------
void MainForm::FileMgrClicked(Object^ pSender, EventArgs^ args) {
    if(pSender == pButton21) {
        cli::array<String^>^ specStrgs = gcnew cli::array<String^>(5);
        specStrgs[0] = "Encrypting File";
        specStrgs[1] = "Please provide a source file, a destination file and a public key ID:";
        specStrgs[2] = "Public Key ID:";
        specStrgs[3] = "Encrypting File";
        specStrgs[4] = "Encrypt...";
        (gcnew FileHandlerDlg(specStrgs, 1, pRSA))->ShowDialog();
    }
    if(pSender == pButton22) {
        cli::array<String^>^ specStrgs = gcnew cli::array<String^>(5);
        specStrgs[0] = "Decrypting File";
        specStrgs[1] = "Please provide an encrypted source file, a destination file and a private key ID:";
        specStrgs[2] = "Private Key ID:";
        specStrgs[3] = "Decrypting File";
        specStrgs[4] = "Decrypt...";
        (gcnew FileHandlerDlg(specStrgs, 2, pRSA))->ShowDialog();
    }
    if(pSender == pButton23) {
        cli::array<String^>^ specStrgs = gcnew cli::array<String^>(5);
        specStrgs[0] = "Signing File";
        specStrgs[1] = "Please provide a source file, a destination file and a private key ID:";
        specStrgs[2] = "Private Key ID:";
        specStrgs[3] = "Signing File";
        specStrgs[4] = "Sign...";
        (gcnew FileHandlerDlg(specStrgs, 3, pRSA))->ShowDialog();
    }
    if(pSender == pButton24) {
        cli::array<String^>^ specStrgs = gcnew cli::array<String^>(5);
        specStrgs[0] = "Verifying File";
        specStrgs[1] = "Please provide a signed source file, a destination file and a public key ID:";
        specStrgs[2] = "Public Key ID:";
        specStrgs[3] = "Verifying File";
        specStrgs[4] = "Verify...";
        (gcnew FileHandlerDlg(specStrgs, 4, pRSA))->ShowDialog();
    }
}

void MainForm::ExitBtnClicked(Object^, EventArgs^) {
    if(::DialogResult::Yes == MessageBox::Show("Exit the program?", "Exit...", MessageBoxButtons::YesNo, MessageBoxIcon::Question))
        Close();
}
void MainForm::RefreshStatusBar() {
    string Names;
    int size;
    if(size = pRSA->PubKey.size()) {
        for(int i = 0, size = pRSA->PubKey.size(); i < size; i++)
            Names += pRSA->PubKey[i].Name + ", ";
        Names.resize(Names.length() - 1);
        Names[Names.length() - 1] = '.';
        pLabel3->Text = gcnew System::String(Names.c_str());
    }
    Names = "";
    if(size = pRSA->SecKey.size()) {
        for(int i = 0, size = pRSA->SecKey.size(); i < size; i++) Names += pRSA->SecKey[i].Name + ", ";
        Names.resize(Names.length() - 1);
        Names[Names.length() - 1] = '.';
        pLabel4->Text = gcnew System::String(Names.c_str());
    }

    pLabel3->Refresh();
    pLabel4->Refresh();
}