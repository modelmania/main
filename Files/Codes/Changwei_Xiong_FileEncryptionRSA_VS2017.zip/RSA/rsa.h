/*
*  Created on: Apr 15, 2003
*  Last modified on: July 28, 2016
*  Author: Changwei Xiong
*
*  Copyright (C) 2009, Changwei Xiong,
*  axcw@hotmail.com, <http://www.cs.utah.edu/~cxiong/>
*
*  Licence: Revised BSD License
*/

//#pragma once
#ifndef RSA_H_
#define RSA_H_

#include <vector>
#include <algorithm>
#include <iostream>
#include <stdlib.h>
#include <time.h>
#include "bigint.h"
typedef BigInt BI;

using namespace System;
using namespace System::Drawing;
using namespace System::Windows;
using namespace System::Windows::Forms;
using namespace System::ComponentModel;
using namespace System::Threading;
using namespace System::IO;

static string toStr(cli::array<unsigned char>^ ch) {
	int length = ch->Length;
	string strg;
	strg.resize(length);
	for (int i = 0; i < length; i++) strg[i] = ch[i];
	return strg;
}

static cli::array<unsigned char>^ toArr(const string& strg) {
	int length = strg.length();
	cli::array<unsigned char>^ ch = gcnew cli::array<unsigned char>(length);
	for (int i = 0; i < length; i++) ch[i] = strg[i];
	return ch;
}

static string MString(System::String^ s) {
	using namespace System::Runtime::InteropServices;
	const char* chars = (const char*)(Marshal::StringToHGlobalAnsi(s)).ToPointer();
	string strg = chars;
	Marshal::FreeHGlobal(IntPtr((void*)chars));
	return strg;
}

struct Key {
	Key() {}
	Key(string name, BI ed, BI n) :Name(name), ED(ed), N(n) {}
	string Name;
	BI ED;
	BI N;
};

struct KeyPair {
	KeyPair() {}
	KeyPair(string name, BI e, BI d, BI n) :Name(name), E(e), D(d), N(n) {}
	KeyPair(const KeyPair& tmpKey) {
		Name = tmpKey.Name;
		E = tmpKey.E;
		D = tmpKey.D;
		N = tmpKey.N;
	}

	string Name;
	BI E;
	BI D;
	BI N;
};

struct DXY {
	DXY(BI d, BI x, BI y) :D(d), X(x), Y(y) {}
	BI D, X, Y;
};


class RSA {
public:
	RSA();
	unsigned hashString(const string&);
	KeyPair keyGen(unsigned, int);
	void Cryptize(cli::array<unsigned char>^ In, cli::array<unsigned char>^ Out, const Key& enKey);
	//static string MarshalString(System::String*);
	vector<Key>	PubKey;
	vector<Key>	SecKey;
private:
	BI gcd(BI&, BI&);
	DXY EE(BI&, BI&);
	BI modExp(const BI&, const BI&, const BI&);
	bool primeTest(const BI &);
};

#endif RSA_H_