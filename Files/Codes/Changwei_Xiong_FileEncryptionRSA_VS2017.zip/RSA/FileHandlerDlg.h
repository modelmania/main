/*
*  Created on: Apr 15, 2003
*  Last modified on: July 28, 2016
*  Author: Changwei Xiong
*
*  Copyright (C) 2009, Changwei Xiong,
*  axcw@hotmail.com, <http://www.cs.utah.edu/~cxiong/>
*
*  Licence: Revised BSD License
*/


#ifndef FILEHANDLERDLG_H_
#define FILEHANDLERDLG_H_
#include "rsa.h"


ref class FileHandlerDlg : public Form {
public:
	FileHandlerDlg(cli::array<String^>^, unsigned, RSA*);

private:
	RSA* pRSA;
	const unsigned uJob;
	void BrsButtonClicked(Object^, EventArgs^);
	void DoButtonClicked(Object^, EventArgs^);
	void ExitButtonClicked(Object^, EventArgs^);

	OpenFileDialog
		^pOFDialog;
	SaveFileDialog
		^pSFDialog;

	ProgressBar
		^pProgressBar;
	GroupBox
		^pGroupBox1,
		^pGroupBox2;
	Button
		^pButton1,
		^pButton2,
		^pButton3,
		^pButton4;
	TextBox
		^pTextBox1,
		^pTextBox2,
		^pTextBox3;
	Label
		^pLabel1,
		^pLabel2,
		^pLabel3,
		^pLabel4,
		^pLabel5,
		^pLabel6,
		^pLabel7,
		^pLabel8,
		^pLabel9,
		^pLabel10;
};

#endif FILEHANDLERDLG_H_