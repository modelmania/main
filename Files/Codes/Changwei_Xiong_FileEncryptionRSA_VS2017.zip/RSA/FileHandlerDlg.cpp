/*
*  Created on: Apr 15, 2003
*  Last modified on: July 28, 2016
*  Author: Changwei Xiong
*
*  Copyright (C) 2009, Changwei Xiong,
*  axcw@hotmail.com, <http://www.cs.utah.edu/~cxiong/>
*
*  Licence: Revised BSD License
*/



#include "FileHandlerDlg.h"

using namespace System;

FileHandlerDlg::FileHandlerDlg(cli::array<String^>^ specStrgs, unsigned uJob, RSA* rsa) : uJob(uJob), pRSA(rsa) {
    pGroupBox1 = gcnew GroupBox;
    pGroupBox2 = gcnew GroupBox;
    pLabel1 = gcnew Label;
    pLabel2 = gcnew Label;
    pLabel3 = gcnew Label;
    pLabel4 = gcnew Label;
    pLabel5 = gcnew Label;
    pLabel6 = gcnew Label;
    pLabel7 = gcnew Label;
    pLabel8 = gcnew Label;
    pLabel9 = gcnew Label;
    pLabel10 = gcnew Label;
    pTextBox1 = gcnew TextBox;
    pTextBox2 = gcnew TextBox;
    pTextBox3 = gcnew TextBox;
    pButton1 = gcnew Button;
    pButton2 = gcnew Button;
    pButton3 = gcnew Button;
    pButton4 = gcnew Button;
    pProgressBar = gcnew ProgressBar();

    pOFDialog = gcnew OpenFileDialog;
    pSFDialog = gcnew SaveFileDialog;

    StartPosition = FormStartPosition::CenterParent;
    Size = System::Drawing::Size(510, 380);
    Text = "File Processing";
    FormBorderStyle = Forms::FormBorderStyle::FixedSingle;
    MaximizeBox = 0;
    MinimizeBox = 0;
    ShowInTaskbar = false;

    //---------------- GroupBox1 Contr--------------------------------------

    pGroupBox1->Location = Point(21, 10);
    pGroupBox1->Size = System::Drawing::Size(450, 170);
    pGroupBox1->TabStop = false;
    pGroupBox1->Text = specStrgs[0];

    pLabel4->Location = Point(40, 30);
    pLabel4->Size = System::Drawing::Size(320, 32);
    pLabel4->TabStop = false;
    pLabel4->Text = specStrgs[1];

    pLabel1->Location = Point(6, 80);
    pLabel1->Size = System::Drawing::Size(90, 16);
    pLabel1->TabStop = false;
    pLabel1->Text = "Source File:";
    pLabel1->TextAlign = System::Drawing::ContentAlignment::MiddleRight;

    pLabel2->Location = Point(6, 104);
    pLabel2->Size = System::Drawing::Size(90, 16);
    pLabel2->TabStop = false;
    pLabel2->Text = "Destination File:";
    pLabel2->TextAlign = System::Drawing::ContentAlignment::MiddleRight;

    pLabel3->Location = Point(6, 128);
    pLabel3->Size = System::Drawing::Size(90, 16);
    pLabel3->TabStop = false;
    pLabel3->Text = specStrgs[2];
    pLabel3->TextAlign = System::Drawing::ContentAlignment::MiddleRight;

    pTextBox1->Location = Point(96, 80);
    pTextBox1->Size = System::Drawing::Size(265, 20);
    pTextBox1->BorderStyle = BorderStyle::FixedSingle;
    //pTextBox1->Text = "C:\\"; //System::Windows::Forms::Application::StartupPath

    pTextBox2->Location = Point(96, 104);
    pTextBox2->Size = System::Drawing::Size(265, 20);
    pTextBox2->BorderStyle = BorderStyle::FixedSingle;
    //pTextBox2->Text = "C:\\"; //System::Windows::Forms::Application::StartupPath

    pTextBox3->Location = Point(96, 128);
    pTextBox3->Size = System::Drawing::Size(265, 20);
    pTextBox3->BorderStyle = BorderStyle::FixedSingle;
    pTextBox3->Text = "";

    pButton1->Location = Point(375, 80);
    pButton1->Size = System::Drawing::Size(60, 20);
    pButton1->Text = "Browse...";
    pButton1->Click += gcnew EventHandler(this, &FileHandlerDlg::BrsButtonClicked);

    pButton2->Location = Point(375, 104);
    pButton2->Size = System::Drawing::Size(60, 20);
    pButton2->Text = "Browse...";
    pButton2->Click += gcnew EventHandler(this, &FileHandlerDlg::BrsButtonClicked);

    pGroupBox1->Controls->Add(pLabel1);
    pGroupBox1->Controls->Add(pLabel2);
    pGroupBox1->Controls->Add(pLabel3);
    pGroupBox1->Controls->Add(pLabel4);
    pGroupBox1->Controls->Add(pTextBox1);
    pGroupBox1->Controls->Add(pTextBox2);
    pGroupBox1->Controls->Add(pTextBox3);
    pGroupBox1->Controls->Add(pButton1);
    pGroupBox1->Controls->Add(pButton2);

    //---------------- GroupBox2 Controls ---------------------------------------

    pGroupBox2->Location = Point(21, 190);
    pGroupBox2->Size = System::Drawing::Size(450, 95);
    pGroupBox2->TabStop = false;
    pGroupBox2->Text = specStrgs[3];

    pProgressBar->Location = Point(60, 20);
    pProgressBar->Size = System::Drawing::Size(330, 16);
    pProgressBar->Step = 1;
    pProgressBar->Minimum = 0;
    pProgressBar->Maximum = 100;

    pLabel5->Location = Point(60, 45);
    pLabel5->Size = System::Drawing::Size(150, 16);
    pLabel5->TabStop = false;
    pLabel5->Text = "Progress in percentage:";
    pLabel5->TextAlign = System::Drawing::ContentAlignment::MiddleRight;

    pLabel6->Location = Point(60, 65);
    pLabel6->Size = System::Drawing::Size(150, 16);
    pLabel6->TabStop = false;
    pLabel6->Text = "Progress      in      bytes:";
    pLabel6->TextAlign = System::Drawing::ContentAlignment::MiddleRight;

    pLabel7->Location = Point(210, 45);
    pLabel7->Size = System::Drawing::Size(80, 16);
    pLabel7->TabStop = false;
    pLabel7->Text = "";
    pLabel7->TextAlign = System::Drawing::ContentAlignment::MiddleCenter;

    pLabel8->Location = Point(210, 65);
    pLabel8->Size = System::Drawing::Size(80, 16);
    pLabel8->TabStop = false;
    pLabel8->Text = "";
    pLabel8->TextAlign = System::Drawing::ContentAlignment::MiddleCenter;

    pLabel9->Location = Point(290, 45);
    pLabel9->Size = System::Drawing::Size(85, 16);
    pLabel9->TabStop = false;
    pLabel9->Text = "%       finished!";
    pLabel9->TextAlign = System::Drawing::ContentAlignment::MiddleLeft;

    pLabel10->Location = Point(290, 65);
    pLabel10->Size = System::Drawing::Size(85, 16);
    pLabel10->TabStop = false;
    pLabel10->Text = "bytes finished!";
    pLabel10->TextAlign = System::Drawing::ContentAlignment::MiddleLeft;

    pGroupBox2->Controls->Add(pProgressBar);
    pGroupBox2->Controls->Add(pLabel5);
    pGroupBox2->Controls->Add(pLabel6);
    pGroupBox2->Controls->Add(pLabel7);
    pGroupBox2->Controls->Add(pLabel8);
    pGroupBox2->Controls->Add(pLabel9);
    pGroupBox2->Controls->Add(pLabel10);

    //---------------- Form Controls ---------------------------------------
    pButton3->Location = Point(280, 300);
    pButton3->Size = System::Drawing::Size(80, 20);
    pButton3->Text = specStrgs[4];
    pButton3->Click += gcnew EventHandler(this, &FileHandlerDlg::DoButtonClicked);

    pButton4->Location = Point(380, 300);
    pButton4->Size = System::Drawing::Size(80, 20);
    pButton4->Text = "Cancel";
    pButton4->Click += gcnew EventHandler(this, &FileHandlerDlg::ExitButtonClicked);

    Controls->Add(pGroupBox1);
    Controls->Add(pGroupBox2);
    Controls->Add(pButton3);
    Controls->Add(pButton4);
}

//------------------   EVENT HANDLER   -------------------------------------
void FileHandlerDlg::BrsButtonClicked(Object^ pSender, EventArgs^) {
    if(pSender == pButton1) {
        pOFDialog->Filter = "All files (*.*)|*.*";
        if(uJob == 2)
            pOFDialog->Filter = "Encrypted file (*.enc)|*.enc|All files (*.*)|*.*";
        if(uJob == 4)
            pOFDialog->Filter = "Signed file (*.sgn;*.enc)|*.sgn;*.enc|All files (*.*)|*.*";

        pOFDialog->ShowDialog();
        if(pOFDialog->FileName->Length)
            pTextBox1->Text = pOFDialog->FileName;
        pOFDialog->FileName = "";
    }
    if(pSender == pButton2) {
        pSFDialog->Filter = "All files (*.*)|*.*";
        if(uJob == 1)
            pSFDialog->Filter = "Encrypted file (*.enc)|*.enc|All files (*.*)|*.*";
        if(uJob == 3)
            pSFDialog->Filter = "Signed file (*.sgn)|*.sgn|All files (*.*)|*.*";

        pSFDialog->ShowDialog();
        if(pSFDialog->FileName->Length)
            pTextBox2->Text = pSFDialog->FileName;
        pSFDialog->FileName = "";
    }
}


void FileHandlerDlg::DoButtonClicked(Object^ pSender, EventArgs^) {
    if(!pTextBox1->Text->Length) {
        MessageBox::Show("Source filename is invalid!",
                         "Invalid Filename...",
                         MessageBoxButtons::OK,
                         MessageBoxIcon::Exclamation);
        return;
    }
    if(!pTextBox2->Text->Length) {
        MessageBox::Show("Destination filename is invalid!",
                         "Invalid Filename...",
                         MessageBoxButtons::OK,
                         MessageBoxIcon::Exclamation);
        return;
    }
    if(!pTextBox2->Text->CompareTo(pTextBox1->Text)) {
        MessageBox::Show("Source and destination filename must differ!",
                         "Invalid Filename...",
                         MessageBoxButtons::OK,
                         MessageBoxIcon::Exclamation);
        return;
    }

    FileStream^ pFileStreamInput, ^pFileStreamOutput;
    FileInfo^ pFileInfoInput, ^pFileInfoOutput;

    try {
        pFileInfoInput = gcnew FileInfo(pTextBox1->Text);
    } catch(...) {
        MessageBox::Show("Source filename is invalid!",
                         "Invalid Filename...",
                         MessageBoxButtons::OK,
                         MessageBoxIcon::Exclamation);
        return;
    }

    try {
        pFileInfoOutput = gcnew FileInfo(pTextBox2->Text);
    } catch(...) {
        MessageBox::Show("Destination filename is invalid!",
                         "Invalid Filename...",
                         MessageBoxButtons::OK,
                         MessageBoxIcon::Exclamation);
        return;
    }
    if(pFileInfoOutput->Exists) {
        pFileStreamOutput = gcnew FileStream(pTextBox2->Text, FileMode::Truncate);
    } else
        pFileStreamOutput = gcnew FileStream(pTextBox2->Text, FileMode::CreateNew);

    if(!pFileInfoInput->Exists) {
        MessageBox::Show("Source filename is invalid!",
                         "Invalid Filename...",
                         MessageBoxButtons::OK,
                         MessageBoxIcon::Exclamation);
        return;
    }

    unsigned int iCount = 0, iValue = 0, iPreValue = 0;
    unsigned fileLength = static_cast<unsigned>(pFileInfoInput->Length);
    pFileStreamInput = gcnew FileStream(pTextBox1->Text, FileMode::Open);
    BinaryReader^ pBinaryReader = gcnew BinaryReader(pFileStreamInput);
    BinaryWriter^ pBinaryWriter = gcnew BinaryWriter(pFileStreamOutput);

    if(uJob == 1 || uJob == 3) {
        vector<Key>& KeySrc = uJob == 1 ? pRSA->PubKey : pRSA->SecKey;
        Key EKey;
        string keyName = MString(pTextBox3->Text);
        for(int i = 0, size = KeySrc.size(); i < size; i++)
            if((KeySrc[i]).Name == keyName)
                EKey = KeySrc[i];
        if(EKey.N == 0) {
            MessageBox::Show("Could not find the key in the buffer!",
                             "Invalid Key ID...",
                             MessageBoxButtons::OK,
                             MessageBoxIcon::Exclamation);
            return;
        }
        pTextBox1->Enabled = false;
        pTextBox2->Enabled = false;
        pTextBox3->Enabled = false;
        pButton1->Enabled = false;
        pButton2->Enabled = false;
        pButton3->Enabled = false;
        pButton4->Enabled = false;
        Refresh();
        int nLength = EKey.N.bits();
        int eBytes = (nLength - 1) / 8;
        int dBytes = nLength % 8 ? (nLength / 8 + 1) : (nLength / 8);
        cli::array<unsigned char>^ In = gcnew cli::array<unsigned char>(eBytes);
        cli::array<unsigned char>^ Out = gcnew cli::array<unsigned char>(dBytes);
        while(1) {
            try {
                In = pBinaryReader->ReadBytes(eBytes);
                iCount += In->Length;
                iPreValue = iValue;
                iValue = iCount * 100 / fileLength;
                if(iValue > iPreValue) {
                    pProgressBar->Value = iValue;
                    pLabel7->Text = iValue.ToString();
                    pLabel8->Text = iCount.ToString();
                    pLabel7->Refresh();
                    pLabel8->Refresh();
                    iPreValue = iValue;
                }
                if(In->Length < eBytes) {
                    if(In->Length == 0) {
                        pBinaryWriter->Write(unsigned char(0));
                        break;
                    }
                    cli::array<unsigned char>^ Last = gcnew cli::array<unsigned char>(eBytes);
                    System::Array::Copy(In, Last, In->Length);
                    pRSA->Cryptize(Last, Out, EKey);
                    pBinaryWriter->Write(Out);
                    pBinaryWriter->Write(unsigned char(eBytes - In->Length));
                    break;
                }
                pRSA->Cryptize(In, Out, EKey);
                pBinaryWriter->Write(Out);
            } catch(...) { break; }
        }
        pBinaryReader->Close();
        pBinaryWriter->Flush();
        pBinaryWriter->Close();
    }

    if(uJob == 2 || uJob == 4) {
        vector<Key>& KeySrc = uJob == 2 ? pRSA->SecKey : pRSA->PubKey;
        Key DKey;
        string keyName = MString(pTextBox3->Text);
        for(int i = 0, size = KeySrc.size(); i < size; i++)
            if((KeySrc[i]).Name == keyName)
                DKey = KeySrc[i];
        if(DKey.N == 0) {
            MessageBox::Show("Could not find the key in the buffer!",
                             "Invalid Key ID...",
                             MessageBoxButtons::OK,
                             MessageBoxIcon::Exclamation);
            return;
        }
        int nLength = DKey.N.bits();
        int eBytes = (nLength - 1) / 8;
        int dBytes = nLength % 8 ? (nLength / 8 + 1) : (nLength / 8);
        if(pFileInfoInput->Length % dBytes != 1) {
            MessageBox::Show("The key does not match the file!",
                             "Invalid Key or File...",
                             MessageBoxButtons::OK,
                             MessageBoxIcon::Exclamation);
            return;
        }
        if(pFileInfoInput->Length == 1) {
            MessageBox::Show("Cannot be an empty file!", "Invalid File...", MessageBoxButtons::OK, MessageBoxIcon::Exclamation);
            return;
        }
        pTextBox1->Enabled = false;
        pTextBox2->Enabled = false;
        pTextBox3->Enabled = false;
        pButton1->Enabled = false;
        pButton2->Enabled = false;
        pButton3->Enabled = false;
        pButton4->Enabled = false;
        Refresh();

        cli::array<unsigned char>^ In = gcnew cli::array<unsigned char>(eBytes);
        cli::array<unsigned char>^ Out;
        cli::array<unsigned char>^ postOut;
        postOut = pBinaryReader->ReadBytes(dBytes);
        iCount += postOut->Length;
        while(1) {
            try {
                Out = postOut;
                postOut = pBinaryReader->ReadBytes(dBytes);
                iCount += postOut->Length;
                iPreValue = iValue;
                iValue = iCount * 100 / fileLength;
                if(iValue > iPreValue) {
                    pProgressBar->Value = iValue;
                    pLabel7->Text = iValue.ToString();
                    pLabel8->Text = iCount.ToString();
                    pLabel7->Refresh();
                    pLabel8->Refresh();
                    iPreValue = iValue;
                }
                if(Out->Length == 1)
                    break;
                if(postOut->Length == 1) {
                    pRSA->Cryptize(Out, In, DKey);
                    cli::array<unsigned char>^ Last = gcnew cli::array<unsigned char>(eBytes - postOut[0]);
                    System::Array::Copy(In, Last, Last->Length);
                    pBinaryWriter->Write(Last);
                    break;
                }
                pRSA->Cryptize(Out, In, DKey);
                pBinaryWriter->Write(In);
            } catch(...) { break; }
        }
        pBinaryReader->Close();
        pBinaryWriter->Flush();
        pBinaryWriter->Close();
    }
    MessageBox::Show("Finished!", "Finished...", MessageBoxButtons::OK, MessageBoxIcon::Information);
    Close();
}

void FileHandlerDlg::ExitButtonClicked(Object^ pSender, EventArgs^) {
    Close();
}