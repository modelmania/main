/*
*  Created on: Apr 15, 2003
*  Last modified on: July 28, 2016
*  Author: Changwei Xiong
*
*  Copyright (C) 2009, Changwei Xiong,
*  axcw@hotmail.com, <http://www.cs.utah.edu/~cxiong/>
*
*  Licence: Revised BSD License
*/

#include "rsa.h"

RSA::RSA() {
}

//hash a string to a number which will be the seed number for pseudonumber generator.
unsigned RSA::hashString(const string& strg) {
    unsigned hash = 0;
    int size = strg.length();
    for(int i = 0; i < size; i++)
        hash = (hash << 6) + (hash >> 25) + strg[i];
    return hash;
}

//Key generatior function, return a Key-pair structure contains the key pair
KeyPair RSA::keyGen(unsigned seed, int iBits) {
    srand(seed);
    int k = iBits >> 1;
    BI P = 0, Q = 0;

    int iCount = k / 15;
    for(int i = 0; i < iCount; i++)
        P = P << 15 | rand();
    P = (P << (k % 15)) + (rand() >> (15 - k % 15));
    iCount = (iBits - k) / 15;
    for(int i = 0; i < iCount; i++)
        Q = Q << 15 | rand();
    Q = (Q << ((iBits - k) % 15)) + (rand() >> (15 - (iBits - k) % 15));

    if(P % 2 == 0)
        P++;
    if(Q % 2 == 0)
        Q++;
    while(!primeTest(P))
        P += 2;
    while(!primeTest(Q))
        Q += 2;

    BI M = (P - 1) * (Q - 1);
    BI E = 3;
    while(gcd(E, M) != 1)
        E += 2;
    return KeyPair("", E, (EE(E, M).X + M) % M, P * Q);
}
// Fermat primality test, return true if a number passes the test
bool RSA::primeTest(const BI &n) {
    BI a, x, tmp;
    BI m = n - 1;
    for(int k = 0; k < 30; k++) {
        a = rand();
        tmp = m;
        int i = 0;
        for(; tmp % 2 == 0; i++)
            tmp >>= 1;
        x = modExp(a, tmp, n);
        for(int j = 1; j <= i; j++) {
            tmp = x;
            x = (x * x) % n;
            if(x == 1 && tmp != 1 && tmp != m)
                return false;
        }
        if(x != 1)
            return false;
    }
    return true;
}

//gcd function: greatest common divisor
BI RSA::gcd(BI &a, BI &b) {
    if(b == 0)
        return a;
    else
        return gcd(b, a % b);
}
//Extended Euclid function
DXY RSA::EE(BI &a, BI &b) {
    if(b == 0)
        return DXY(a, 1, 0);
    else {
        DXY result = EE(b, a % b);
        BI tp = result.X;
        result.X = result.Y;
        result.Y = tp - (a / b) * result.Y;
        return result;
    }
}

// exponentiation-modulus function
BI RSA::modExp(const BI &a, const BI &u, const BI &n) {
    BI result = 1;
    int iLength = n.bits();
    int iLen = iLength - 1;
    BI k;
    for(int i = 0; i < iLength; i++) {
        k = u >> (iLen - i);
        if(k > 0) {
            result = (result * result) % n;
            if(k % 2 == 1)
                result = (result * a) % n;
        }
    }
    return result;
}

// Basic function for encrypting and decrypting
void RSA::Cryptize(cli::array<unsigned char>^ In, cli::array<unsigned char>^ Out, const Key& enKey) {
    BI biIn = 0;
    int n = In->Length;
    for(int i = 0; i < n; i++) {
        biIn <<= 8;
        biIn |= BI(In[i]);
    }
    BI biOut = modExp(biIn, enKey.ED, enKey.N);
    unsigned char ch = 0xff;
    n = Out->Length - 1;
    for(int i = 0; i <= n; i++) {
        Out[n - i] = unsigned char((biOut & ch).toLong());
        biOut >>= 8;
    }
}