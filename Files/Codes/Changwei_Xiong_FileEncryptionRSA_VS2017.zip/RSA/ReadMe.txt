*********************************************************
*  Created on: Apr 15, 2003                             *   
*  Last update on: June 5, 2016                        *
*  Author: Changwei Xiong                               *
*                                                       *
*  Copyright (C) 2003, Changwei Xiong,                  *
*  axcw@hotmail.com, <http://www.cs.utah.edu/~cxiong/>  *
*                                                       *
*  Licence: Revised BSD License                         *
*********************************************************


This is a GUI-based file encryption and decryption program based on the RSA algorithm. (Rivest, Shamir and Adleman, http://en.wikipedia.org/wiki/RSA) 

It implements the following features: 

    1. Key generation 
        Generate new RSA public/private key pairs up to 1024 bits 
    2. Key management 
        Manage the public/private key pairs that are either generated or imported 
    3. File Encryption 
        Encrypt (or sign) arbitrary data files using the public (or private) key it manages 
    4. File Decryption 
        Decrypt (or verify) the encryped (or signed) files using the private (or public) key it manages 


You must have Microsoft .Net Framework installed to run it. The application was originally written in Visual C++ .Net in Visual Studio 2003 and has been recently recoded using Windows Forms API in Visual Studio 2008. The source code package has included an executable in the "release\" directory. 

Updated (5 Nov 2015) : Successfully migrated to Visual Studio 2013, but failed in Visual Studio 2015.
Updated (5 June 2016): Successfully migrated to Visual Studio 2015