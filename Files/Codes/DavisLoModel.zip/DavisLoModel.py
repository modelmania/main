# This program is written in Python v2.6, libraries required are:
# numpy, scipy, matplotlib, xlrd, xlwt
#
# This program demostrates the Davis-Lo model and calibrates the model to market data
#
# It reads in the data from 2 sources: 
#     'Inputs_for_model_calibration.xls' : 
#         contains all the market data necessary for model calibration. The program reads in and 
#         preprocess the data.
#     'Inputs.xls' : 
#         contains some extra constants for the program to run, such as parameters for Monte Carlo 
#         simulation, etc.
#     
# Optimal solution mu and a are output to an excel file called 'Outputs.xls' 
# 
# (C) Copyright 2009, Changwei Xiong (axcw@hotmail.com)
# Date:   12/09/2009

import numpy as np
from scipy import optimize as spopt, linalg as spla
import matplotlib.pyplot as mp
from matplotlib import cm
from mpl_toolkits.mplot3d import Axes3D
from random import random as rand
from math import log, log10, ceil, floor, modf, exp, sqrt
import time
import datetime as dt
from xlrd import open_workbook, cellname, xldate_as_tuple
from xlwt import Workbook

class DavisLo(object):
    
    # constructor, reads from input files and initializes the constants 
    def __init__(self):
        ret = self.read_xls('Inputs.xls', 'Inputs_for_model_calibration.xls')
        
        self.M = int(ret['M'])      # timesteps
        self.P = int(ret['P'])      # Monte Carlo trials
        self.r = float(ret['rf'])   # risk free rate        
        T = float(ret['T'])         # time period
        delta = float(ret['delta']) # coupon payment day fraction
        
        self.lmd = float(ret['lambda'])  # lambda
        self.R = float(ret['recovery'])  # recovery rate
        self.mkt_tr = ret['market_tranches'] # market tranche quotes
        self.N = int(ret['total_names']) # number of total names
        self.ix = float(ret['ix'])       # initial guess for x : mu = x*x
        self.iy = float(ret['iy'])       # initial guess for y : a = y*y+1
 
        self.Di = [x*delta for x in [modf(T/delta)[0]]+[1]*int(modf(T/delta)[1])] # time slices
        self.Ti = [sum(self.Di[:i]) for i in xrange(len(self.Di)+1)] # times
        self.Bi = [exp(-self.r*t) for t in self.Ti]   # discounts
        
    # main program, everything is done here!!!
    # please comment/uncomment to toggle the features
    def final(self): 
        mp.close()
        
        # optimization routine for finding optimal solution
        (x, y) = spopt.fmin(self.residue_xy, (self.ix, self.iy))
        mu = max(x**2, 1e-8) # mu > 0
        a = y**2 + 1   # a >= 1    
    
        print '\nOptimal Solution: mu = %.6f, a = %.6f'%(mu, a)
        self.write_xls('Outputs.xls', mu, a)
        
        ### plot default distribution function at optimal solution
        ### takes 1-2 minutes to run,  uncomment it to run
        #self.plot_LossFunction(mu=mu, a=a)
        
        ### make residue plot as a function of mu and a
        ### takes 20 minutes to run, uncomment it to run
        #self.plot_residue(1e-3, 1e3, 1, 10)
    
    # make a 3-D plot of residue as a function of mu an a
    def plot_residue(self, mu_d, mu_u, a_d, a_u):
        # meshgrid of 30X30
        MU = np.linspace(log10(mu_d), log10(mu_u), 30)
        A = np.linspace(a_d, a_u, 30)
        res = np.zeros((len(MU),len(A)))
        for i, mu in enumerate(MU):
            for j, a in enumerate(A):
                res[i,j] = self.residue(10.0**mu, a, method='MC')
        MUg, Ag = np.meshgrid(MU, A)
        ax = Axes3D(mp.figure())
        ax.plot_surface(MUg, Ag, res.T, rstride=1, cstride=1, cmap=cm.jet)
        ax.set_xlabel('log(mu)', fontsize=16)
        ax.set_ylabel('a', fontsize=16)
        ax.set_zlabel('residue', fontsize=16)        
        mp.suptitle('Residue Plot for %.3f < mu < %.3f and %.3f < a < %.3f'\
                    %(mu_d, mu_u, a_d, a_u),\
                    fontsize=16)
        mp.show()
     
    # loss function (i.e. default probability function)
    def plot_LossFunction(self, mu, a):
        width = 0.4
        st = 0
        ed = self.N+1
        index = -1
        Pr = self.MonCar(mu, a)# monte carlo method        
        mp.bar(np.arange(st,ed)-width, Pr[index][st:ed], width, color='r')
        Pr = self.MatExp(mu, a)# matrix exponentiation     
        mp.bar(np.arange(st,ed), Pr[index][st:ed], width, color='b')
        mp.xlim(st,ed)
        mp.xlabel('# defaults')
        mp.ylabel('Probability')
        mp.title('Default Dist. Function with mu = %.4f and a = %.4f' % (mu,a))
        
        #plot 3-D default distribution function
        Nt = np.arange(self.N+1)
        Ti = np.array(self.Ti)
        Ti, Nt = np.meshgrid(Ti, Nt)
        Pr = np.array(Pr).T
        Pr[Pr>0.3] = 0.3 # clamp the steep peak for visualization 
        ax = Axes3D(mp.figure())
        ax.plot_surface(Ti, Nt, Pr, rstride=1, cstride=1, cmap=cm.jet)
        ax.set_zlim3d(0, 0.3)
        ax.set_xlabel('Ti', fontsize=16)
        ax.set_ylabel('Nt', fontsize=16)
        ax.set_zlabel('Probability', fontsize=16)        
        mp.suptitle('3-D Default Dist. Function', fontsize=16)
        
        mp.show()
     
    # expected tranche loss function
    def ELoss(self, P, Kd, Ku):
        v = (1-self.R)/self.N
        return sum(p*(max(i*v-Kd,0)-max(i*v-Ku,0))/(Ku-Kd) for i, p in enumerate(P))
    
    # compute tranche spread or upfront payment from model
    def Model_SP_UP(self, Pr, tr):
        Kd = tr['Kd']
        Ku = tr['Ku']
        B = np.array(self.Bi)
        D = np.array(self.Di)
        EL = np.array([self.ELoss(P, Kd, Ku) for P in Pr])
        DL = np.dot(0.5*(B[:-1]+B[1:]), EL[1:]-EL[:-1])
        RA = np.dot(D*B[1:], 1-0.5*(EL[:-1]+EL[1:]))
        #print DL, RA
        return DL-0.05*RA if tr['UP']>0 else DL/RA
    
    # change of variables
    def residue_xy(self, param):
        mu = max(param[0]**2, 1e-8) # mu > 0
        a = param[1]**2 + 1         # a > 1
        return self.residue(mu, a)
    
    #residual calculation, primarily use matrix exponentiation
    def residue(self, mu, a, method='ME'):        
        st = time.time()
        if method == 'ME':         
            Pr = self.MatExp(mu=mu, a=a)     
        else:
            Pr = self.MonCar(mu=mu, a=a)  
        
        resid = 0.0
        print ('%s\t\t'*5)%('Kd', 'Ku', 'market', 'model', 'residue')
        for i, tr in enumerate(self.mkt_tr):
            if 1 or i in (0, 5):
                mkt = tr['UP'] if tr['UP'] > 0 else tr['SP']
                spup = self.Model_SP_UP(Pr,tr)
                resid += (1-spup/mkt)**2.0
                print ('%.5f\t\t'*5)%(tr['Kd'], tr['Ku'], mkt, spup, abs(1-spup/mkt))
        resid = sqrt(resid)
        self.mu = mu
        self.a = a
        print 'Total residue = %.4f, mu = %.6f, a = %.6f' % (resid, mu, a)
        print 'time elapsed :%.4f seconds' % (time.time()-st)
        print
        
        return resid   
    
    # write the outputs to an excel file
    def write_xls(self, filename, mu, a):
        wb = Workbook()
        ws = wb.add_sheet('Outputs')
        
        # for your reference, output some of the constants
        # used in the models to the output file
        ws.write(0,0,'Some of the constants used:'); 
        ws.write(1,0,'lambda'); 
        ws.write(1,1,self.lmd)
        ws.write(2,0,'recovery rate'); 
        ws.write(2,1,self.R)
        ws.write(3,0,'T'); 
        ws.write(3,1,self.Ti[-1])
        ws.write(4,0,'# names'); 
        ws.write(4,1,self.N)
        ws.write(5,0,'risk free rate'); 
        ws.write(5,1,self.r)
        
        # save solution to the output file
        ws.write(7,0,'Optimal Solution:'); 
        ws.write(8,0,'mu'); 
        ws.write(8,1,mu)
        ws.write(9,0,'a'); 
        ws.write(9,1,a)
        
        wb.save(filename)
        
    # inputs parser
    def read_xls(self, inputfile, datafile):
        # read in input data 
        book = open_workbook(filename=inputfile)
        for sheetid in xrange(book.nsheets):
            sheet = book.sheet_by_index(sheetid)
            if sheet.name == 'Input':
                ncol = 0
                dcol = 2
                stcl = sheet.cell
                for row in xrange(sheet.nrows):
                    if stcl(row, ncol).value == 'Monte Carlo timesteps':
                        MCsteps = stcl(row,dcol).value
                    if stcl(row, ncol).value == 'Monte Carlo trials':
                        MCpaths = stcl(row,dcol).value
                    if stcl(row, ncol).value == 'risk free rate':
                        rf = stcl(row,dcol).value
                    if stcl(row, ncol).value == 'tranche time period':
                        timeperiod = stcl(row,dcol).value
                    if stcl(row, ncol).value == 'coupon day fraction':
                        dayfrac = stcl(row,dcol).value
                    if stcl(row, ncol).value == 'initial guess for x':
                        ix = stcl(row,dcol).value
                    if stcl(row, ncol).value == 'initial guess for y':
                        iy = stcl(row,dcol).value
     
        # read in credit portfolio tranche data        
        book = open_workbook(filename=datafile)
        for sheetid in xrange(book.nsheets):
            sheet = book.sheet_by_index(sheetid)
            if sheet.name == 'CDX IG11 single name data':
                hdrow = 0
                col5y = 0
                colR = 0
                names = sheet.nrows-1
                stcl = sheet.cell
                for col in xrange(sheet.ncols):
                    if stcl(hdrow, col).value == '5Y clean':
                        col5y = col
                    if stcl(hdrow, col).value == 'recovery':
                        colR = col
                lmd = sum(stcl(row,col5y).value/(1-stcl(row,colR).value) \
                          for row in xrange(1,sheet.nrows))\
                        /names/10000.0
                R = sum(stcl(row, colR).value for row in xrange(1,sheet.nrows))/names
            if sheet.name == 'CDX IG11 tranche quotes':
                hdrow = 0
                colup = 0
                colsprd = 0
                colk1 = 0
                colk2 = 0
                coldt = 0
                stcl = sheet.cell
                for col in xrange(sheet.ncols):
                    if stcl(hdrow, col).value == 'Lower':
                        colk1 = col
                    if stcl(hdrow, col).value == 'Upper':
                        colk2 = col
                    if stcl(hdrow+1, col).value == 'Maturity':
                        coldt = col
                    if stcl(hdrow+1, col).value == 'Payment (%)':
                        colup = col
                    if stcl(hdrow+1, col).value == 'Fee (bps)':
                        colsp = col
                mkt_tr = []
                for row in xrange(hdrow+2, sheet.nrows):
                    if dt.date(*xldate_as_tuple(stcl(row, coldt).value, 0)[:3]).year == 2013:
                        mkt_tr.append({'Kd':float(stcl(row, colk1).value),
                                       'Ku':float(stcl(row, colk2).value),
                                       'UP':float(stcl(row, colup).value),
                                       'SP':float(stcl(row, colsp).value)/10000.0})
                mkt_tr.sort(cmp=lambda x,y:cmp(x['Kd'], y['Kd']))
                
        return {'M':MCsteps,
                'P':MCpaths,
                'rf':rf,
                'T':timeperiod,
                'delta':dayfrac,
                'ix':ix,
                'iy':iy,
                'lambda':lmd, 
                'total_names':names, 
                'market_tranches':mkt_tr, 
                'recovery': R}
    
    # Monte Carlo Simulation
    def MonCar(self, mu, a):
        mu = float(mu)
        a = float(a)
        N = self.N
        M = self.M
        P = self.P
        lmd = self.lmd        
        dt = self.Ti[-1]/M
        idx = [int(round(t/dt)) for t in self.Ti]+[-1]
        pr = [[0.0]*(N+1) for t in self.Ti]
        
        lmd_dt = lmd*dt
        a_lmd_dt = a*lmd_dt
        for p in xrange(P):
            n = 0
            x = 0
            h = 0
            ii = idx[h]
            for i in xrange(M+1):
                if i == ii:# ii = premium payment time index
                    pr[h][n] += 1
                    h += 1
                    ii = idx[h]
                t = dt * i
                def_pr = (N-n) * (a_lmd_dt if t < x else lmd_dt) 
                if def_pr > rand() and n < N: # default occurs
                    n += 1
                    x  = t - log(1.0-rand())/mu # exp. dist. y = 1-exp(-mu*x)
        return (np.array(pr)/P).tolist()             
    
    # Matrix Exponentiation Method
    def MatExp(self, mu, a):
        N = self.N
        lmd = self.lmd
        A = np.zeros((2*(N+1), 2*(N+1)))
        for i in xrange(N):
            j = 2*i
            A[j  , j  ] = -lmd*(N-i)
            A[j+1, j  ] = mu
            A[j+1, j+1] = -mu - a*lmd*(N-i)
            A[j  , j+3] = lmd*(N-i)
            A[j+1, j+3] = a*lmd*(N-i)
    
        pr = []
        #for t in self.Ti:    
        #    pm = spla.expm(A*t); 
        #    pr.append((pm[0,::2]+pm[0,1::2]).tolist())

        pm0 = np.eye(2*(N+1))
        pr.append((pm0[0,::2]+pm0[0,1::2]).tolist())    
        pm1 = spla.expm(A*self.Di[0])
        pr.append((pm1[0,::2]+pm1[0,1::2]).tolist())       
        pm2 = spla.expm(A*self.Di[1])        
        pm = pm1
        for t in self.Ti[2:]:
            pm = np.dot(pm, pm2)
            pr.append((pm[0,::2]+pm[0,1::2]).tolist())
        return pr

    
if __name__ == '__main__':
    try:
        import psyco        
        psyco.full()
        print 'Running psyco to speed up...'
    except:
        pass

    DavisLo().final()
